import { db } from '../src/lib/db';
import bcrypt from 'bcryptjs';

async function ensureAdmin() {
  try {
    // Check if admin user already exists
    const existingAdmin = await db.user.findFirst({
      where: { role: 'ADMIN' }
    });

    if (existingAdmin) {
      console.log('Admin user already exists:', existingAdmin.email);
      return;
    }

    // Create default admin user
    const hashedPassword = await bcrypt.hash('admin123', 10);
    
    const admin = await db.user.create({
      data: {
        email: 'admin@eduplatform.com',
        name: 'System Administrator',
        password: hashedPassword,
        role: 'ADMIN',
      }
    });

    console.log('Default admin user created:', admin.email);
    console.log('Email: admin@eduplatform.com');
    console.log('Password: admin123');
  } catch (error) {
    console.error('Error ensuring admin user:', error);
  } finally {
    await db.$disconnect();
  }
}

ensureAdmin();