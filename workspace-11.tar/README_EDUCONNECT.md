# EduConnect - Global Online Learning Platform

A comprehensive online educational platform that integrates Learning Management System (LMS) and Enterprise Resource Planning (ERP) functionality for students and teachers worldwide.

## 🌟 Features

### Core Platform Features
- **User Authentication**: Secure login system for students and teachers
- **Role-Based Access**: Different dashboards and functionalities for students and teachers
- **Responsive Design**: Mobile-first design that works on all devices
- **Real-Time Updates**: Live notifications and progress tracking

### Student Features (LMS)
- **Course Management**: Browse, enroll, and track course progress
- **Online Testing**: Take tests with multiple question types (Multiple Choice, True/False, Short Answer, Essay)
- **Grade Tracking**: View grades, feedback, and performance analytics
- **Progress Monitoring**: Real-time progress tracking for enrolled courses
- **Interactive Dashboard**: Personalized learning dashboard with statistics

### Teacher Features (ERP)
- **Course Creation**: Create and manage courses with multimedia content
- **Test Management**: Create comprehensive tests with automated grading
- **Student Management**: Track student enrollment, progress, and performance
- **Grade Management**: Automated grade calculations and report generation
- **Analytics Dashboard**: Comprehensive analytics on student performance
- **Attendance Tracking**: Monitor student attendance and engagement

### Technical Features
- **Database**: SQLite with Prisma ORM for efficient data management
- **API**: RESTful APIs for all platform functionalities
- **Authentication**: JWT-based secure authentication
- **Real-Time**: Socket.io integration for real-time features
- **Modern Stack**: Next.js 15, TypeScript, Tailwind CSS, shadcn/ui

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up the database:
   ```bash
   npm run db:push
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

### Sample Data

To populate the database with sample data for testing:

1. Send a POST request to `/api/seed` or use curl:
   ```bash
   curl -X POST http://localhost:3000/api/seed
   ```

This will create:
- **Teacher Account**: `teacher@educonnect.com` / `teacher123`
- **Student Account**: `student@educonnect.com` / `student123`
- Sample course, test, questions, and grades

## 📁 Project Structure

```
src/
├── app/                    # Next.js App Router
│   ├── api/               # API routes
│   │   ├── auth/          # Authentication endpoints
│   │   ├── courses/       # Course management
│   │   ├── tests/         # Test management
│   │   ├── questions/     # Question management
│   │   ├── submissions/   # Test submissions
│   │   ├── grades/        # Grade management
│   │   ├── users/         # User management
│   │   └── seed/          # Sample data seeding
│   ├── globals.css        # Global styles
│   ├── layout.tsx         # Root layout
│   └── page.tsx           # Main landing page
├── components/            # React components
│   ├── ui/               # shadcn/ui components
│   ├── student-dashboard.tsx
│   ├── teacher-dashboard.tsx
│   └── test-interface.tsx
├── contexts/             # React contexts
│   └── auth-context.tsx  # Authentication context
└── lib/                  # Utility libraries
    ├── db.ts            # Database client
    ├── utils.ts         # Utility functions
    └── socket.ts        # Socket.io configuration
```

## 🎯 User Roles & Permissions

### Students
- View and enroll in available courses
- Take tests and submit assignments
- Track grades and progress
- View personal analytics

### Teachers
- Create and manage courses
- Create and grade tests
- Monitor student progress
- Manage attendance and grades
- View comprehensive analytics

### Admin
- User management
- System configuration
- Platform analytics
- Content moderation

## 🧪 Testing System

The platform supports multiple question types:

1. **Multiple Choice**: Single correct answer with options
2. **True/False**: Binary choice questions
3. **Short Answer**: Text-based answers with automatic grading
4. **Essay**: Long-form answers requiring manual grading

### Test Features
- Timed tests with automatic submission
- Real-time progress tracking
- Question navigation
- Automatic grading for objective questions
- Grade calculation and feedback

## 📊 Database Schema

The platform uses a comprehensive database schema with the following main entities:

- **Users**: Authentication and role management
- **Student/Teacher Profiles**: Role-specific information
- **Courses**: Course creation and management
- **Enrollments**: Student-course relationships
- **Tests**: Test creation and configuration
- **Questions**: Individual test questions
- **Submissions**: Student test submissions
- **Grades**: Grade records and analytics
- **Attendance**: Student attendance tracking

## 🔧 Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run lint` - Run ESLint
- `npm run db:push` - Push database schema changes

### Environment Variables

Create a `.env` file with:

```env
DATABASE_URL="file:./dev.db"
JWT_SECRET="your-secret-key"
```

## 🎨 UI Components

The platform uses shadcn/ui components for a consistent, modern design:

- Cards, buttons, forms, and inputs
- Navigation and layout components
- Data display components (tables, badges, progress bars)
- Interactive components (dialogs, tabs, selects)

## 🔐 Security Features

- Password hashing with bcryptjs
- JWT-based authentication
- Role-based access control
- Input validation and sanitization
- Secure API endpoints

## 🌍 Global Accessibility

The platform is designed for global accessibility:

- Multi-language support ready
- Responsive design for all devices
- Accessibility features (ARIA labels, semantic HTML)
- Cloud-based architecture for worldwide access

## 📈 Analytics & Reporting

### Student Analytics
- Course progress tracking
- Test performance analysis
- Grade trends and insights
- Learning path recommendations

### Teacher Analytics
- Class performance overview
- Individual student progress
- Test effectiveness analysis
- Engagement metrics

## 🚀 Future Enhancements

- Video conferencing integration
- Advanced analytics dashboard
- Mobile app development
- AI-powered learning recommendations
- Multi-language support
- Advanced reporting features

## 📝 License

This project is part of the EduConnect educational platform initiative.

## 🤝 Contributing

Contributions are welcome! Please follow the established coding standards and submit pull requests for review.

---

**EduConnect** - Empowering education worldwide through technology 🌍📚