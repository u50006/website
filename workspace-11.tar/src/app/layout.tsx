import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/contexts/auth-context";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "EduConnect - Global Online Learning Platform",
  description: "Comprehensive online educational platform with LMS and ERP functionality for students and teachers worldwide.",
  keywords: ["Education", "Online Learning", "LMS", "ERP", "E-learning", "Students", "Teachers", "Courses"],
  authors: [{ name: "EduConnect Team" }],
  openGraph: {
    title: "EduConnect - Global Online Learning Platform",
    description: "Connect, learn, and grow with our comprehensive educational platform",
    url: "https://educonnect.com",
    siteName: "EduConnect",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "EduConnect - Global Online Learning Platform",
    description: "Comprehensive online educational platform for students and teachers",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <AuthProvider>
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  );
}
