'use client';

import { useState, useEffect } from 'react';
import { CourseCard } from '@/components/courses/course-card';
import { CourseFilters, CourseFilters as FiltersType } from '@/components/courses/course-filters';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Search, 
  Grid, 
  List, 
  SlidersHorizontal, 
  BookOpen,
  Users,
  Star,
  Filter
} from 'lucide-react';

interface Course {
  id: string;
  title: string;
  description: string;
  code: string;
  credits: number;
  duration: number;
  level: string;
  price: number;
  language: string;
  thumbnail?: string;
  averageRating: number;
  totalStudents: number;
  totalTests: number;
  totalReviews: number;
  teacher: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
    teacherProfile?: {
      department: string;
      experience: number;
      rating: number;
    };
  };
  category?: {
    id: string;
    name: string;
    color?: string;
  };
}

interface CourseCategory {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  color?: string;
  _count: {
    courses: number;
  };
}

const defaultFilters: FiltersType = {
  search: '',
  category: '',
  level: '',
  priceRange: [0, 500],
  duration: '',
  rating: 0,
  teacher: '',
  sortBy: 'newest',
};

export default function CoursesPage() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<CourseCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<FiltersType>({
    search: '',
    category: '',
    level: '',
    priceRange: [0, 500],
    duration: '',
    rating: 0,
    teacher: '',
    sortBy: 'newest',
  });
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 12,
    total: 0,
    pages: 0,
  });

  const fetchCourses = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: pagination.page.toString(),
        limit: pagination.limit.toString(),
        ...(filters.search && { search: filters.search }),
        ...(filters.category && { category: filters.category }),
        ...(filters.level && { level: filters.level }),
        ...(filters.teacher && { teacherId: filters.teacher }),
        ...(filters.sortBy && { 
          sort: filters.sortBy === 'newest' ? 'createdAt-desc' :
                filters.sortBy === 'oldest' ? 'createdAt-asc' :
                filters.sortBy === 'popular' ? 'enrollments-desc' :
                filters.sortBy === 'rating' ? 'rating-desc' :
                filters.sortBy === 'price-low' ? 'price-asc' :
                filters.sortBy === 'price-high' ? 'price-desc' : 'createdAt-desc'
        }),
      });

      // Add price range filter
      if (filters.priceRange[0] > 0 || filters.priceRange[1] < 500) {
        params.append('minPrice', filters.priceRange[0].toString());
        params.append('maxPrice', filters.priceRange[1].toString());
      }

      // Add duration filter
      if (filters.duration) {
        const [min, max] = filters.duration.split('-').map(d => d.replace('+', ''));
        params.append('minDuration', min);
        if (max) params.append('maxDuration', max);
      }

      // Add rating filter
      if (filters.rating > 0) {
        params.append('minRating', filters.rating.toString());
      }

      const response = await fetch(`/api/courses?${params}`);
      const data = await response.json();

      if (response.ok) {
        setCourses(data.courses);
        setPagination(data.pagination);
      } else {
        console.error('Failed to fetch courses:', data.error);
      }
    } catch (error) {
      console.error('Error fetching courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/courses/categories?isActive=true');
      const data = await response.json();

      if (response.ok) {
        setCategories(data);
      } else {
        console.error('Failed to fetch categories:', data.error);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, [pagination.page, filters]);

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleFiltersChange = (newFilters: FiltersType) => {
    setFilters(newFilters);
    setPagination(prev => ({ ...prev, page: 1 })); // Reset to first page
  };

  const handlePageChange = (page: number) => {
    setPagination(prev => ({ ...prev, page }));
  };

  const featuredCategories = categories.slice(0, 6);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Discover Your Learning Journey
            </h1>
            <p className="text-xl mb-8 text-blue-100">
              Explore our comprehensive catalog of courses taught by expert instructors
            </p>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search for courses, topics, or instructors..."
                  value={filters.search}
                  onChange={(e) => handleFiltersChange({ ...filters, search: e.target.value })}
                  className="pl-12 pr-4 py-3 text-lg bg-white/10 backdrop-blur-sm border-white/20 text-white placeholder-white/70 focus:bg-white/20"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Featured Categories */}
        {featuredCategories.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Popular Categories</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {featuredCategories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => handleFiltersChange({ ...filters, category: category.id })}
                  className="p-4 rounded-lg border hover:border-blue-500 hover:bg-blue-50 transition-colors text-center"
                >
                  <div 
                    className="w-12 h-12 rounded-lg mx-auto mb-2 flex items-center justify-center"
                    style={{ backgroundColor: category.color ? `${category.color}20` : '#f3f4f6' }}
                  >
                    <BookOpen 
                      className="w-6 h-6" 
                      style={{ color: category.color || '#6b7280' }}
                    />
                  </div>
                  <h3 className="font-medium text-sm">{category.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {category._count.courses} courses
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-80 flex-shrink-0">
            <div className="lg:hidden mb-4">
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="w-full"
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>
            </div>
            
            <div className={`${showFilters ? 'block' : 'hidden lg:block'}`}>
              <CourseFilters
                onFiltersChange={handleFiltersChange}
                categories={categories}
              />
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Results Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <div>
                <h2 className="text-2xl font-bold">
                  {courses.length > 0 ? `${pagination.total} Courses` : 'No Courses Found'}
                </h2>
                {filters.search && (
                  <p className="text-muted-foreground">
                    Search results for "{filters.search}"
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-2 bg-muted rounded-lg p-1">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>

                <Select
                  value={filters.sortBy}
                  onValueChange={(value) => handleFiltersChange({ ...filters, sortBy: value })}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="popular">Most Popular</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Loading State */}
            {loading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <div className="h-48 bg-muted rounded-t-lg"></div>
                    <CardHeader>
                      <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="h-3 bg-muted rounded"></div>
                        <div className="h-3 bg-muted rounded w-5/6"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Courses Grid/List */}
            {!loading && courses.length > 0 && (
              <div className={
                viewMode === 'grid' 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                  : 'space-y-4'
              }>
                {courses.map((course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                    showEnrollButton={true}
                  />
                ))}
              </div>
            )}

            {/* No Results */}
            {!loading && courses.length === 0 && (
              <div className="text-center py-12">
                <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No courses found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your filters or search terms
                </p>
                <Button onClick={() => handleFiltersChange(defaultFilters)}>
                  Clear Filters
                </Button>
              </div>
            )}

            {/* Pagination */}
            {!loading && pagination.pages > 1 && (
              <div className="flex justify-center items-center gap-2 mt-8">
                <Button
                  variant="outline"
                  onClick={() => handlePageChange(pagination.page - 1)}
                  disabled={pagination.page === 1}
                >
                  Previous
                </Button>
                
                <div className="flex items-center gap-1">
                  {Array.from({ length: Math.min(5, pagination.pages) }).map((_, i) => {
                    const page = i + 1;
                    const isActive = page === pagination.page;
                    
                    return (
                      <Button
                        key={page}
                        variant={isActive ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => handlePageChange(page)}
                      >
                        {page}
                      </Button>
                    );
                  })}
                </div>

                <Button
                  variant="outline"
                  onClick={() => handlePageChange(pagination.page + 1)}
                  disabled={pagination.page === pagination.pages}
                >
                  Next
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}