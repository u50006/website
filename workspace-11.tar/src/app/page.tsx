'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Users, Award, Globe, Clock, CheckCircle, ArrowRight, GraduationCap, BrainCircuit } from 'lucide-react';
import { StudentDashboard } from '@/components/student-dashboard';
import { TeacherDashboard } from '@/components/teacher-dashboard';
import { CoursesBrowse } from '@/components/courses-browse';

export default function Home() {
  const { login, register, user, isLoading, logout } = useAuth();
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({
    email: '',
    password: '',
    name: '',
    role: 'STUDENT',
    profileData: {
      employeeId: '',
      studentId: '',
      grade: '',
      section: '',
      rollNumber: '',
      parentName: '',
      parentPhone: '',
      parentEmail: ''
    }
  });
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');
  const [showDashboard, setShowDashboard] = useState(false);
  const [showCourses, setShowCourses] = useState(false);
  const [componentError, setComponentError] = useState<string | null>(null);

  // Error boundary for component errors
  useEffect(() => {
    const handleError = (error: ErrorEvent) => {
      console.error('Page component error:', error);
      setComponentError(error.message);
    };
    
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (componentError) {
    return (
      <div className="flex items-center justify-center min-h-screen flex-col">
        <div className="text-red-500 text-center">
          <h2 className="text-2xl font-bold mb-4">Something went wrong</h2>
          <p className="mb-4">{componentError}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-4 py-2 bg-blue-500 text-white rounded"
          >
            Reload Page
          </button>
        </div>
      </div>
    );
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError('');
    
    const result = await login(loginForm.email, loginForm.password);
    if (!result.success) {
      setAuthError(result.error || 'Login failed');
    } else {
      setShowDashboard(true);
    }
    setAuthLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError('');
    
    const result = await register(registerForm);
    if (!result.success) {
      setAuthError(result.error || 'Registration failed');
    } else {
      // Auto-login after successful registration
      await login(registerForm.email, registerForm.password);
      setShowDashboard(true);
    }
    setAuthLoading(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen flex-col">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        <p className="mt-4 text-gray-600">Loading application...</p>
        <p className="text-xs text-gray-500 mt-2">Debug: isLoading={isLoading.toString()}</p>
      </div>
    );
  }

  console.log('Page render - user:', user ? 'exists' : 'none', 'showDashboard:', showDashboard);

  // Temporarily disable dashboard to isolate the loading issue
  if (user && false && showDashboard) {
    // Redirect to appropriate dashboard
    if (user.role === 'TEACHER') {
      return <TeacherDashboard />;
    } else {
      return <StudentDashboard />;
    }
  }

  if (false && showCourses) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="container mx-auto px-4 py-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Browse Courses
          </h1>
          <p>Courses temporarily disabled for debugging</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Navigation Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <GraduationCap className="w-8 h-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">EduConnect</span>
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              {user ? (
                <>
                  <a href="#features" className="text-gray-600 hover:text-gray-900">Features</a>
                  <button onClick={() => setShowCourses(true)} className="text-gray-600 hover:text-gray-900">Courses</button>
                  <a href="#about" className="text-gray-600 hover:text-gray-900">About</a>
                  <Button onClick={() => setShowDashboard(true)}>
                    Dashboard
                  </Button>
                  <Button variant="outline" onClick={logout}>
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <a href="#features" className="text-gray-600 hover:text-gray-900">Features</a>
                  <button onClick={() => setShowCourses(true)} className="text-gray-600 hover:text-gray-900">Courses</button>
                  <a href="#about" className="text-gray-600 hover:text-gray-900">About</a>
                  <Button>Get Started</Button>
                </>
              )}
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="mb-4 bg-blue-100 text-blue-800">🌍 Global Learning Platform</Badge>
            {user ? (
              <>
                <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                  Welcome back,
                  <span className="text-blue-600"> {user.name}!</span>
                </h1>
                <p className="text-xl text-gray-600 mb-8">
                  Continue your learning journey or explore new courses. Access your dashboard to manage your courses, tests, and track your progress.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="text-lg px-8 py-6" onClick={() => setShowDashboard(true)}>
                    Go to Dashboard <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                  <Button variant="outline" size="lg" className="text-lg px-8 py-6" onClick={() => setShowCourses(true)}>
                    Browse Courses
                  </Button>
                </div>
              </>
            ) : (
              <>
                <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                  Learn Without
                  <span className="text-blue-600"> Boundaries</span>
                </h1>
                <p className="text-xl text-gray-600 mb-8">
                  Connect with students and teachers worldwide. Experience comprehensive LMS and ERP functionality 
                  with online testing, real-time progress tracking, and personalized learning paths.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="text-lg px-8 py-6">
                    Start Learning <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                  <Button variant="outline" size="lg" className="text-lg px-8 py-6" onClick={() => setShowCourses(true)}>
                    Browse Courses
                  </Button>
                </div>
              </>
            )}
          </div>
          {!user && (
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-400 rounded-3xl transform rotate-3"></div>
              <Card className="relative bg-white p-8 rounded-3xl shadow-2xl">
                <Tabs defaultValue="login" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="login">Login</TabsTrigger>
                    <TabsTrigger value="register">Register</TabsTrigger>
                  </TabsList>
                
                <TabsContent value="login">
                  <form onSubmit={handleLogin} className="space-y-4 mt-6">
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={loginForm.email}
                        onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        value={loginForm.password}
                        onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                        required
                      />
                    </div>
                    {authError && (
                      <div className="text-red-500 text-sm">{authError}</div>
                    )}
                    <Button type="submit" className="w-full" disabled={authLoading}>
                      {authLoading ? 'Logging in...' : 'Login'}
                    </Button>
                  </form>
                  
                  <div className="mt-6 text-center">
                    <p className="text-sm text-gray-600 mb-2">
                      Administrator?
                    </p>
                    <Button 
                      variant="link" 
                      className="text-xs text-blue-600 hover:text-blue-800"
                      onClick={() => window.location.href = '/admin'}
                    >
                      Access Admin Panel
                    </Button>
                  </div>
                </TabsContent>
                
                <TabsContent value="register">
                  <form onSubmit={handleRegister} className="space-y-4 mt-6">
                    <div>
                      <Label htmlFor="reg-name">Full Name</Label>
                      <Input
                        id="reg-name"
                        value={registerForm.name}
                        onChange={(e) => setRegisterForm({...registerForm, name: e.target.value})}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="reg-email">Email</Label>
                      <Input
                        id="reg-email"
                        type="email"
                        value={registerForm.email}
                        onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="reg-password">Password</Label>
                      <Input
                        id="reg-password"
                        type="password"
                        value={registerForm.password}
                        onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="role">I am a</Label>
                      <select
                        id="role"
                        className="w-full p-2 border rounded-md"
                        value={registerForm.role}
                        onChange={(e) => setRegisterForm({...registerForm, role: e.target.value})}
                      >
                        <option value="STUDENT">Student</option>
                        <option value="TEACHER">Teacher</option>
                      </select>
                    </div>
                    
                    {/* Teacher specific fields */}
                    {registerForm.role === 'TEACHER' && (
                      <div>
                        <Label htmlFor="employeeId">Employee ID</Label>
                        <Input
                          id="employeeId"
                          value={registerForm.profileData.employeeId}
                          onChange={(e) => setRegisterForm({
                            ...registerForm, 
                            profileData: {...registerForm.profileData, employeeId: e.target.value}
                          })}
                          required
                        />
                      </div>
                    )}
                    
                    {/* Student specific fields */}
                    {registerForm.role === 'STUDENT' && (
                      <>
                        <div>
                          <Label htmlFor="studentId">Student ID</Label>
                          <Input
                            id="studentId"
                            value={registerForm.profileData.studentId}
                            onChange={(e) => setRegisterForm({
                              ...registerForm, 
                              profileData: {...registerForm.profileData, studentId: e.target.value}
                            })}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="grade">Grade</Label>
                          <Input
                            id="grade"
                            value={registerForm.profileData.grade}
                            onChange={(e) => setRegisterForm({
                              ...registerForm, 
                              profileData: {...registerForm.profileData, grade: e.target.value}
                            })}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="section">Section</Label>
                          <Input
                            id="section"
                            value={registerForm.profileData.section}
                            onChange={(e) => setRegisterForm({
                              ...registerForm, 
                              profileData: {...registerForm.profileData, section: e.target.value}
                            })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="rollNumber">Roll Number</Label>
                          <Input
                            id="rollNumber"
                            value={registerForm.profileData.rollNumber}
                            onChange={(e) => setRegisterForm({
                              ...registerForm, 
                              profileData: {...registerForm.profileData, rollNumber: e.target.value}
                            })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="parentName">Parent Name</Label>
                          <Input
                            id="parentName"
                            value={registerForm.profileData.parentName}
                            onChange={(e) => setRegisterForm({
                              ...registerForm, 
                              profileData: {...registerForm.profileData, parentName: e.target.value}
                            })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="parentPhone">Parent Phone</Label>
                          <Input
                            id="parentPhone"
                            value={registerForm.profileData.parentPhone}
                            onChange={(e) => setRegisterForm({
                              ...registerForm, 
                              profileData: {...registerForm.profileData, parentPhone: e.target.value}
                            })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="parentEmail">Parent Email</Label>
                          <Input
                            id="parentEmail"
                            type="email"
                            value={registerForm.profileData.parentEmail}
                            onChange={(e) => setRegisterForm({
                              ...registerForm, 
                              profileData: {...registerForm.profileData, parentEmail: e.target.value}
                            })}
                          />
                        </div>
                      </>
                    )}
                    
                    {authError && (
                      <div className="text-red-500 text-sm">{authError}</div>
                    )}
                    <Button type="submit" className="w-full" disabled={authLoading}>
                      {authLoading ? 'Creating Account...' : 'Create Account'}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </Card>
          </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need for Online Education
            </h2>
            <p className="text-xl text-gray-600">
              Comprehensive platform for students and teachers worldwide
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Course Management</h3>
              <p className="text-gray-600">
                Create, manage, and deliver courses with multimedia content and interactive materials.
              </p>
            </Card>
            
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <BrainCircuit className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Online Testing</h3>
              <p className="text-gray-600">
                Create comprehensive tests with multiple question types and automated grading.
              </p>
            </Card>
            
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Student Tracking</h3>
              <p className="text-gray-600">
                Monitor student progress, attendance, and performance with detailed analytics.
              </p>
            </Card>
            
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-yellow-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Grade Management</h3>
              <p className="text-gray-600">
                Comprehensive grading system with automated calculations and report generation.
              </p>
            </Card>
            
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                <Globe className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Global Access</h3>
              <p className="text-gray-600">
                Learn and teach from anywhere in the world with our cloud-based platform.
              </p>
            </Card>
            
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Real-time Updates</h3>
              <p className="text-gray-600">
                Get instant notifications for assignments, tests, and important announcements.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">10,000+</div>
              <div className="text-blue-100">Active Students</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">500+</div>
              <div className="text-blue-100">Expert Teachers</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">1,000+</div>
              <div className="text-blue-100">Courses Available</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-blue-100">Countries</div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              About EduConnect
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're revolutionizing education by connecting teachers and students worldwide through innovative technology and comprehensive learning management.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Our Mission</h3>
              <p className="text-gray-600 mb-6">
                EduConnect is dedicated to breaking down educational barriers by providing a unified platform that combines powerful Learning Management System (LMS) capabilities with comprehensive Enterprise Resource Planning (ERP) functionality.
              </p>
              <p className="text-gray-600 mb-6">
                We believe that quality education should be accessible to everyone, regardless of geographical location or economic background. Our platform enables seamless online learning, real-time collaboration, and comprehensive academic management.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-gray-700">Global Access</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-gray-700">24/7 Learning</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-gray-700">Expert Teachers</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-gray-700">Interactive Learning</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-blue-400 to-purple-600 rounded-3xl flex items-center justify-center">
                <div className="text-white text-center p-8">
                  <GraduationCap className="w-24 h-24 mx-auto mb-6" />
                  <h4 className="text-2xl font-bold mb-2">Learn Without Boundaries</h4>
                  <p className="text-blue-100">Connecting minds across the globe</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Comprehensive Learning</h3>
              <p className="text-gray-600">
                Access a wide range of courses with multimedia content, interactive assignments, and personalized learning paths tailored to your needs.
              </p>
            </Card>

            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Expert Instructors</h3>
              <p className="text-gray-600">
                Learn from qualified teachers and industry experts who are passionate about sharing their knowledge and helping you succeed.
              </p>
            </Card>

            <Card className="text-center p-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Certified Achievement</h3>
              <p className="text-gray-600">
                Earn certificates and badges upon course completion, showcasing your skills and achievements to potential employers.
              </p>
            </Card>
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-3xl p-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Why Choose EduConnect?</h3>
              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">500+</div>
                  <p className="text-gray-600">Expert Teachers</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">1,000+</div>
                  <p className="text-gray-600">Courses Available</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-purple-600 mb-2">50+</div>
                  <p className="text-gray-600">Countries Reached</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-orange-600 mb-2">100K+</div>
                  <p className="text-gray-600">Active Students</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <GraduationCap className="w-6 h-6" />
                <span className="text-xl font-bold">EduConnect</span>
              </div>
              <p className="text-gray-400">
                Empowering education worldwide through technology.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Features</a></li>
                <li><a href="#" className="hover:text-white">Pricing</a></li>
                <li><a href="#" className="hover:text-white">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Help Center</a></li>
                <li><a href="#" className="hover:text-white">Contact Us</a></li>
                <li><a href="#" className="hover:text-white">Status</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-white">Terms</a></li>
                <li><a href="#" className="hover:text-white">Security</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 EduConnect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}