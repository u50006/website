import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const testId = searchParams.get('testId');

    if (!testId) {
      return NextResponse.json(
        { error: 'Test ID is required' },
        { status: 400 }
      );
    }

    const questions = await db.question.findMany({
      where: { testId },
      orderBy: { order: 'asc' }
    });

    return NextResponse.json(questions);

  } catch (error) {
    console.error('Error fetching questions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { testId, questions } = await request.json();

    if (!testId || !questions || !Array.isArray(questions)) {
      return NextResponse.json(
        { error: 'Test ID and questions array are required' },
        { status: 400 }
      );
    }

    const createdQuestions = await db.question.createMany({
      data: questions.map((q: any) => ({
        testId,
        question: q.question,
        type: q.type,
        options: q.options ? JSON.stringify(q.options) : null,
        correctAnswer: q.correctAnswer,
        marks: q.marks || 1,
        explanation: q.explanation,
        order: q.order || 0,
      }))
    });

    return NextResponse.json({
      message: 'Questions created successfully',
      count: createdQuestions.count
    });

  } catch (error) {
    console.error('Error creating questions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}