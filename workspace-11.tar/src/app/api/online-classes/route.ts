import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const teacherId = searchParams.get('teacherId');
    const studentId = searchParams.get('studentId');
    const courseId = searchParams.get('courseId');
    const status = searchParams.get('status');

    let classes;

    if (teacherId) {
      // Get classes taught by a specific teacher
      classes = await db.onlineClass.findMany({
        where: { 
          teacherId,
          ...(status && { status })
        },
        include: {
          course: {
            select: {
              id: true,
              title: true,
              code: true,
            }
          },
          teacher: {
            select: {
              id: true,
              name: true,
              email: true,
            }
          },
          participants: {
            include: {
              student: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                }
              }
            }
          },
          _count: {
            select: {
              participants: true,
            }
          }
        },
        orderBy: { startTime: 'asc' }
      });
    } else if (studentId) {
      // Get classes for a specific student (through enrollments)
      const enrollments = await db.enrollment.findMany({
        where: { studentId, status: 'ACTIVE' },
        select: { courseId: true }
      });
      
      const courseIds = enrollments.map(e => e.courseId);
      
      classes = await db.onlineClass.findMany({
        where: { 
          courseId: { in: courseIds },
          ...(status && { status })
        },
        include: {
          course: {
            select: {
              id: true,
              title: true,
              code: true,
            }
          },
          teacher: {
            select: {
              id: true,
              name: true,
              email: true,
            }
          },
          participants: {
            where: { studentId },
            include: {
              student: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                }
              }
            }
          },
          _count: {
            select: {
              participants: true,
            }
          }
        },
        orderBy: { startTime: 'asc' }
      });
    } else if (courseId) {
      // Get classes for a specific course
      classes = await db.onlineClass.findMany({
        where: { 
          courseId,
          ...(status && { status })
        },
        include: {
          course: {
            select: {
              id: true,
              title: true,
              code: true,
            }
          },
          teacher: {
            select: {
              id: true,
              name: true,
              email: true,
            }
          },
          participants: {
            include: {
              student: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                }
              }
            }
          },
          _count: {
            select: {
              participants: true,
            }
          }
        },
        orderBy: { startTime: 'asc' }
      });
    } else {
      // Get all upcoming classes
      classes = await db.onlineClass.findMany({
        where: { 
          startTime: { gte: new Date() },
          ...(status && { status })
        },
        include: {
          course: {
            select: {
              id: true,
              title: true,
              code: true,
            }
          },
          teacher: {
            select: {
              id: true,
              name: true,
              email: true,
            }
          },
          _count: {
            select: {
              participants: true,
            }
          }
        },
        orderBy: { startTime: 'asc' },
        take: 50
      });
    }

    return NextResponse.json(classes);

  } catch (error) {
    console.error('Error fetching online classes:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const {
      title,
      description,
      courseId,
      teacherId,
      startTime,
      endTime,
      platform,
      isRecurring,
      recurringPattern,
      maxParticipants,
      isRecorded
    } = await request.json();

    // Validate required fields
    if (!title || !courseId || !teacherId || !startTime || !endTime) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Validate that the end time is after start time
    const start = new Date(startTime);
    const end = new Date(endTime);
    if (end <= start) {
      return NextResponse.json(
        { error: 'End time must be after start time' },
        { status: 400 }
      );
    }

    // Generate meeting details based on platform
    let meetingLink = null;
    let meetingId = null;
    let meetingPassword = null;

    if (platform) {
      switch (platform) {
        case 'ZOOM':
          meetingId = Math.random().toString(36).substring(2, 12).toUpperCase();
          meetingPassword = Math.random().toString(36).substring(2, 8);
          meetingLink = `https://zoom.us/j/${meetingId}`;
          break;
        case 'GOOGLE_MEET':
          meetingId = Math.random().toString(36).substring(2, 15);
          meetingLink = `https://meet.google.com/${meetingId}`;
          break;
        case 'TEAMS':
          meetingId = Math.random().toString(36).substring(2, 20);
          meetingLink = `https://teams.microsoft.com/l/meetup-join/${meetingId}`;
          break;
        default:
          meetingLink = `https://meeting.example.com/${Math.random().toString(36).substring(2, 15)}`;
      }
    }

    const onlineClass = await db.onlineClass.create({
      data: {
        title,
        description,
        courseId,
        teacherId,
        startTime: new Date(startTime),
        endTime: new Date(endTime),
        meetingLink,
        meetingId,
        meetingPassword,
        platform,
        isRecurring: isRecurring || false,
        recurringPattern,
        maxParticipants: maxParticipants || 100,
        isRecorded: isRecorded || false,
      },
      include: {
        course: {
          select: {
            id: true,
            title: true,
            code: true,
          }
        },
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Online class created successfully',
      class: onlineClass
    });

  } catch (error) {
    console.error('Error creating online class:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}