import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const classId = params.id;
    const { studentId } = await request.json();

    if (!studentId) {
      return NextResponse.json(
        { error: 'Student ID is required' },
        { status: 400 }
      );
    }

    // Check if the class exists and is live or scheduled
    const onlineClass = await db.onlineClass.findUnique({
      where: { id: classId },
      include: {
        course: true,
        participants: {
          where: { studentId },
        }
      }
    });

    if (!onlineClass) {
      return NextResponse.json(
        { error: 'Class not found' },
        { status: 404 }
      );
    }

    // Check if student is enrolled in the course
    const enrollment = await db.enrollment.findUnique({
      where: {
        studentId_courseId: {
          studentId,
          courseId: onlineClass.courseId
        }
      }
    });

    if (!enrollment) {
      return NextResponse.json(
        { error: 'Student is not enrolled in this course' },
        { status: 403 }
      );
    }

    // Check if class has started or is about to start (within 15 minutes)
    const now = new Date();
    const classStartTime = new Date(onlineClass.startTime);
    const timeDiff = classStartTime.getTime() - now.getTime();
    const minutesDiff = timeDiff / (1000 * 60);

    if (minutesDiff > 15) {
      return NextResponse.json(
        { error: 'Class has not started yet. You can join 15 minutes before the scheduled time.' },
        { status: 400 }
      );
    }

    // Check if class has ended
    if (now > new Date(onlineClass.endTime)) {
      return NextResponse.json(
        { error: 'Class has already ended' },
        { status: 400 }
      );
    }

    // Create or update participant record
    let participant = onlineClass.participants[0];
    
    if (participant) {
      // Update existing participant
      participant = await db.onlineClassParticipant.update({
        where: {
          id: participant.id
        },
        data: {
          joinedAt: participant.joinedAt || new Date(),
          status: 'JOINED'
        }
      });
    } else {
      // Create new participant record
      participant = await db.onlineClassParticipant.create({
        data: {
          classId,
          studentId,
          joinedAt: new Date(),
          status: 'JOINED'
        }
      });
    }

    // Update class status to LIVE if it's time
    if (minutesDiff <= 0 && onlineClass.status === 'SCHEDULED') {
      await db.onlineClass.update({
        where: { id: classId },
        data: { status: 'LIVE' }
      });
    }

    return NextResponse.json({
      message: 'Successfully joined the class',
      class: {
        id: onlineClass.id,
        title: onlineClass.title,
        meetingLink: onlineClass.meetingLink,
        meetingId: onlineClass.meetingId,
        meetingPassword: onlineClass.meetingPassword,
        platform: onlineClass.platform,
        startTime: onlineClass.startTime,
        endTime: onlineClass.endTime,
        status: onlineClass.status
      },
      participant
    });

  } catch (error) {
    console.error('Error joining online class:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}