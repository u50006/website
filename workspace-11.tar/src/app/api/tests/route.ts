import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const createTestSchema = z.object({
  title: z.string().min(1, 'Test title is required'),
  description: z.string().optional(),
  courseId: z.string().min(1, 'Course ID is required'),
  teacherId: z.string().min(1, 'Teacher ID is required'),
  duration: z.number().min(1, 'Duration must be at least 1 minute'),
  totalMarks: z.number().min(1, 'Total marks must be at least 1'),
  passingMarks: z.number().min(0, 'Passing marks must be at least 0'),
  startTime: z.string().datetime().optional(),
  endTime: z.string().datetime().optional(),
  isPublished: z.boolean().default(false),
  questions: z.array(z.object({
    question: z.string().min(1, 'Question text is required'),
    type: z.enum(['MULTIPLE_CHOICE', 'TRUE_FALSE', 'SHORT_ANSWER', 'ESSAY']),
    options: z.array(z.string()).optional(),
    correctAnswer: z.string().optional(),
    marks: z.number().min(1).default(1),
    explanation: z.string().optional(),
    order: z.number().min(0).default(0),
  })).optional(),
});

// GET /api/tests - Get all tests with filtering and pagination
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const courseId = searchParams.get('courseId');
    const teacherId = searchParams.get('teacherId');
    const isPublished = searchParams.get('isPublished');
    const search = searchParams.get('search');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (courseId) {
      where.courseId = courseId;
    }

    if (teacherId) {
      where.teacherId = teacherId;
    }

    if (isPublished !== null) {
      where.isPublished = isPublished === 'true';
    }

    if (search) {
      where.OR = [
        {
          title: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          description: {
            contains: search,
            mode: 'insensitive',
          },
        },
      ];
    }

    const [tests, total] = await Promise.all([
      db.test.findMany({
        where,
        include: {
          course: {
            select: {
              id: true,
              title: true,
              code: true,
            },
          },
          teacher: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
          questions: {
            select: {
              id: true,
              question: true,
              type: true,
              marks: true,
              order: true,
            },
            orderBy: {
              order: 'asc',
            },
          },
          submissions: {
            select: {
              id: true,
              status: true,
              marks: true,
              submittedAt: true,
            },
          },
          _count: {
            select: {
              questions: true,
              submissions: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),
      db.test.count({ where }),
    ]);

    // Calculate test statistics
    const testsWithStats = tests.map((test) => {
      const completedSubmissions = test.submissions.filter(s => s.status === 'SUBMITTED');
      const averageScore = completedSubmissions.length > 0
        ? completedSubmissions.reduce((sum, submission) => sum + (submission.marks || 0), 0) / completedSubmissions.length
        : 0;

      return {
        ...test,
        totalQuestions: test._count.questions,
        totalSubmissions: test._count.submissions,
        completedSubmissions: completedSubmissions.length,
        averageScore: Number(averageScore.toFixed(2)),
      };
    });

    return NextResponse.json({
      tests: testsWithStats,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching tests:', error);
    return NextResponse.json(
      { error: 'Failed to fetch tests' },
      { status: 500 }
    );
  }
}

// POST /api/tests - Create a new test
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validatedData = createTestSchema.parse(body);

    // Verify course exists
    const course = await db.course.findUnique({
      where: { id: validatedData.courseId },
    });

    if (!course) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 400 }
      );
    }

    // Verify teacher exists and teaches the course
    const teacher = await db.user.findUnique({
      where: { 
        id: validatedData.teacherId,
        role: 'TEACHER',
      },
    });

    if (!teacher) {
      return NextResponse.json(
        { error: 'Invalid teacher ID or user is not a teacher' },
        { status: 400 }
      );
    }

    // Check if teacher is assigned to the course
    if (course.teacherId !== validatedData.teacherId) {
      return NextResponse.json(
        { error: 'Teacher is not assigned to this course' },
        { status: 400 }
      );
    }

    // Validate passing marks
    if (validatedData.passingMarks > validatedData.totalMarks) {
      return NextResponse.json(
        { error: 'Passing marks cannot be greater than total marks' },
        { status: 400 }
      );
    }

    // Create test with questions
    const test = await db.test.create({
      data: {
        title: validatedData.title,
        description: validatedData.description,
        courseId: validatedData.courseId,
        teacherId: validatedData.teacherId,
        duration: validatedData.duration,
        totalMarks: validatedData.totalMarks,
        passingMarks: validatedData.passingMarks,
        startTime: validatedData.startTime ? new Date(validatedData.startTime) : null,
        endTime: validatedData.endTime ? new Date(validatedData.endTime) : null,
        isPublished: validatedData.isPublished,
        questions: validatedData.questions ? {
          create: validatedData.questions.map((q, index) => ({
            question: q.question,
            type: q.type,
            options: q.options ? JSON.stringify(q.options) : null,
            correctAnswer: q.correctAnswer,
            marks: q.marks,
            explanation: q.explanation,
            order: q.order || index,
          })),
        } : undefined,
      },
      include: {
        course: {
          select: {
            id: true,
            title: true,
            code: true,
          },
        },
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        questions: {
          orderBy: {
            order: 'asc',
          },
        },
      },
    });

    // Parse options for response
    const testWithParsedOptions = {
      ...test,
      questions: test.questions.map(q => ({
        ...q,
        options: q.options ? JSON.parse(q.options) : null,
      })),
    };

    return NextResponse.json(testWithParsedOptions, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error creating test:', error);
    return NextResponse.json(
      { error: 'Failed to create test' },
      { status: 500 }
    );
  }
}