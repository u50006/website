import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const test = await db.test.update({
      where: { id: params.id },
      data: { isPublished: true }
    });

    return NextResponse.json({
      message: 'Test published successfully',
      test
    });

  } catch (error) {
    console.error('Error publishing test:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}