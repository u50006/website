import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get('studentId');

    let submissions;

    if (studentId) {
      // Get submissions for a specific student
      submissions = await db.testSubmission.findMany({
        where: { 
          testId: params.id,
          studentId 
        },
        include: {
          student: {
            include: {
              studentProfile: true,
            }
          }
        },
        orderBy: { submittedAt: 'desc' }
      });
    } else {
      // Get all submissions for the test
      submissions = await db.testSubmission.findMany({
        where: { testId: params.id },
        include: {
          student: {
            include: {
              studentProfile: true,
            }
          }
        },
        orderBy: { submittedAt: 'desc' }
      });
    }

    return NextResponse.json(submissions);

  } catch (error) {
    console.error('Error fetching submissions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}