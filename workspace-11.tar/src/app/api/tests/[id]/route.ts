import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const updateTestSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  duration: z.number().min(1).optional(),
  totalMarks: z.number().min(1).optional(),
  passingMarks: z.number().min(0).optional(),
  startTime: z.string().datetime().optional(),
  endTime: z.string().datetime().optional(),
  isPublished: z.boolean().optional(),
});

// GET /api/tests/[id] - Get a specific test with questions
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const test = await db.test.findUnique({
      where: { id: params.id },
      include: {
        course: {
          select: {
            id: true,
            title: true,
            code: true,
            teacherId: true,
          },
        },
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        questions: {
          orderBy: {
            order: 'asc',
          },
        },
        submissions: {
          include: {
            student: {
              select: {
                id: true,
                name: true,
                email: true,
                avatar: true,
              },
            },
          },
          orderBy: {
            submittedAt: 'desc',
          },
        },
        _count: {
          select: {
            questions: true,
            submissions: true,
          },
        },
      },
    });

    if (!test) {
      return NextResponse.json(
        { error: 'Test not found' },
        { status: 404 }
      );
    }

    // Parse options for questions
    const testWithParsedOptions = {
      ...test,
      questions: test.questions.map(q => ({
        ...q,
        options: q.options ? JSON.parse(q.options) : null,
      })),
    };

    return NextResponse.json(testWithParsedOptions);
  } catch (error) {
    console.error('Error fetching test:', error);
    return NextResponse.json(
      { error: 'Failed to fetch test' },
      { status: 500 }
    );
  }
}

// PUT /api/tests/[id] - Update a test
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const validatedData = updateTestSchema.parse(body);

    // Check if test exists
    const existingTest = await db.test.findUnique({
      where: { id: params.id },
    });

    if (!existingTest) {
      return NextResponse.json(
        { error: 'Test not found' },
        { status: 404 }
      );
    }

    // Validate passing marks if both are provided
    if (validatedData.passingMarks !== undefined && validatedData.totalMarks !== undefined) {
      if (validatedData.passingMarks > validatedData.totalMarks) {
        return NextResponse.json(
          { error: 'Passing marks cannot be greater than total marks' },
          { status: 400 }
        );
      }
    } else if (validatedData.passingMarks !== undefined) {
      if (validatedData.passingMarks > existingTest.totalMarks) {
        return NextResponse.json(
          { error: 'Passing marks cannot be greater than total marks' },
          { status: 400 }
        );
      }
    } else if (validatedData.totalMarks !== undefined) {
      if (existingTest.passingMarks > validatedData.totalMarks) {
        return NextResponse.json(
          { error: 'Passing marks cannot be greater than total marks' },
          { status: 400 }
        );
      }
    }

    const test = await db.test.update({
      where: { id: params.id },
      data: {
        ...validatedData,
        startTime: validatedData.startTime ? new Date(validatedData.startTime) : undefined,
        endTime: validatedData.endTime ? new Date(validatedData.endTime) : undefined,
      },
      include: {
        course: {
          select: {
            id: true,
            title: true,
            code: true,
          },
        },
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        questions: {
          orderBy: {
            order: 'asc',
          },
        },
      },
    });

    // Parse options for response
    const testWithParsedOptions = {
      ...test,
      questions: test.questions.map(q => ({
        ...q,
        options: q.options ? JSON.parse(q.options) : null,
      })),
    };

    return NextResponse.json(testWithParsedOptions);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error updating test:', error);
    return NextResponse.json(
      { error: 'Failed to update test' },
      { status: 500 }
    );
  }
}

// DELETE /api/tests/[id] - Delete a test
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check if test exists
    const existingTest = await db.test.findUnique({
      where: { id: params.id },
      include: {
        submissions: true,
      },
    });

    if (!existingTest) {
      return NextResponse.json(
        { error: 'Test not found' },
        { status: 404 }
      );
    }

    // Check if test has submissions
    if (existingTest.submissions.length > 0) {
      return NextResponse.json(
        { error: 'Cannot delete test with existing submissions' },
        { status: 400 }
      );
    }

    await db.test.delete({
      where: { id: params.id },
    });

    return NextResponse.json(
      { message: 'Test deleted successfully' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error deleting test:', error);
    return NextResponse.json(
      { error: 'Failed to delete test' },
      { status: 500 }
    );
  }
}