import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get('studentId');
    const courseId = searchParams.get('courseId');

    let grades;

    if (studentId) {
      // Get grades for a specific student
      grades = await db.grade.findMany({
        where: { studentId },
        include: {
          student: {
            select: {
              id: true,
              name: true,
              email: true,
            }
          }
        },
        orderBy: { gradedAt: 'desc' }
      });

      // Include course information if available
      grades = await Promise.all(grades.map(async (grade) => {
        let course: { id: string; title: string; code: string; } | null = null;
        if (grade.courseId) {
          course = await db.course.findUnique({
            where: { id: grade.courseId },
            select: {
              id: true,
              title: true,
              code: true,
            }
          });
        }
        return {
          ...grade,
          course
        };
      }));
    } else if (courseId) {
      // Get grades for a specific course
      grades = await db.grade.findMany({
        where: { courseId },
        include: {
          student: {
            select: {
              id: true,
              name: true,
              email: true,
            }
          }
        },
        orderBy: { gradedAt: 'desc' }
      });
    } else {
      // Get all grades
      grades = await db.grade.findMany({
        include: {
          student: {
            select: {
              id: true,
              name: true,
              email: true,
            }
          }
        },
        orderBy: { gradedAt: 'desc' }
      });
    }

    return NextResponse.json(grades);

  } catch (error) {
    console.error('Error fetching grades:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { 
      studentId, 
      courseId, 
      testId, 
      submissionId, 
      assignmentName, 
      marks, 
      totalMarks, 
      feedback, 
      gradedBy,
      semester,
      academicYear 
    } = await request.json();

    // Calculate percentage and grade
    const percentage = (marks / totalMarks) * 100;
    let grade = 'F';
    
    if (percentage >= 90) grade = 'A';
    else if (percentage >= 80) grade = 'B';
    else if (percentage >= 70) grade = 'C';
    else if (percentage >= 60) grade = 'D';

    const newGrade = await db.grade.create({
      data: {
        studentId,
        courseId,
        testId,
        submissionId,
        assignmentName,
        marks,
        totalMarks,
        percentage,
        grade,
        feedback,
        gradedBy,
        semester,
        academicYear,
      },
      include: {
        student: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Grade created successfully',
      grade: newGrade
    });

  } catch (error) {
    console.error('Error creating grade:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}