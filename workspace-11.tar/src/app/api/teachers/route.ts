import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';
import { adminOnly, AdminUser } from '@/lib/admin-auth';

const createTeacherProfileSchema = z.object({
  userId: z.string().min(1, 'User ID is required'),
  employeeId: z.string().min(1, 'Employee ID is required'),
  department: z.string().optional(),
  qualification: z.string().optional(),
  experience: z.number().min(0).optional(),
  bio: z.string().optional(),
  specialties: z.array(z.string()).optional(),
  education: z.array(z.object({
    degree: z.string(),
    institution: z.string(),
    year: z.string(),
  })).optional(),
  certifications: z.array(z.object({
    name: z.string(),
    issuer: z.string(),
    year: z.string(),
    url: z.string().optional(),
  })).optional(),
  awards: z.array(z.object({
    title: z.string(),
    organization: z.string(),
    year: z.string(),
  })).optional(),
  research: z.string().optional(),
  socialLinks: z.record(z.string(), z.string()).optional(),
  website: z.string().url().optional(),
  location: z.string().optional(),
});

// GET /api/teachers - Get all teachers with their profiles
export const GET = adminOnly(async (
  request: NextRequest,
  context: any,
  adminUser: AdminUser
) => {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const department = searchParams.get('department');
    const search = searchParams.get('search');
    const isActive = searchParams.get('isActive') !== 'false';

    const skip = (page - 1) * limit;

    const where: any = {
      role: 'TEACHER',
      teacherProfile: {
        isActive,
      },
    };

    if (department) {
      where.teacherProfile.department = {
        contains: department,
        mode: 'insensitive',
      };
    }

    if (search) {
      where.OR = [
        {
          name: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          email: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          teacherProfile: {
            bio: {
              contains: search,
              mode: 'insensitive',
            },
          },
        },
      ];
    }

    const [teachers, total] = await Promise.all([
      db.user.findMany({
        where,
        select: {
          id: true,
          name: true,
          email: true,
          avatar: true,
          phone: true,
          createdAt: true,
          teacherProfile: {
            select: {
              id: true,
              employeeId: true,
              department: true,
              qualification: true,
              experience: true,
              bio: true,
              specialties: true,
              education: true,
              certifications: true,
              awards: true,
              research: true,
              socialLinks: true,
              website: true,
              location: true,
              rating: true,
              totalReviews: true,
              hireDate: true,
            },
          },
          _count: {
            select: {
              createdCourses: {
                where: {
                  isActive: true,
                },
              },
              teacherReviews: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),
      db.user.count({ where }),
    ]);

    return NextResponse.json({
      teachers,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching teachers:', error);
    return NextResponse.json(
      { error: 'Failed to fetch teachers' },
      { status: 500 }
    );
  }
});

// POST /api/teachers - Create a new teacher profile
export const POST = adminOnly(async (
  request: NextRequest,
  context: any,
  adminUser: AdminUser
) => {
  try {
    const body = await request.json();
    const validatedData = createTeacherProfileSchema.parse(body);

    // Check if user exists and is a teacher
    const user = await db.user.findUnique({
      where: { 
        id: validatedData.userId,
        role: 'TEACHER',
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found or is not a teacher' },
        { status: 400 }
      );
    }

    // Check if teacher profile already exists
    const existingProfile = await db.teacherProfile.findUnique({
      where: { userId: validatedData.userId },
    });

    if (existingProfile) {
      return NextResponse.json(
        { error: 'Teacher profile already exists' },
        { status: 400 }
      );
    }

    // Check if employee ID already exists
    const existingEmployeeId = await db.teacherProfile.findUnique({
      where: { employeeId: validatedData.employeeId },
    });

    if (existingEmployeeId) {
      return NextResponse.json(
        { error: 'Employee ID already exists' },
        { status: 400 }
      );
    }

    const teacherProfile = await db.teacherProfile.create({
      data: {
        ...validatedData,
        specialties: validatedData.specialties ? JSON.stringify(validatedData.specialties) : null,
        education: validatedData.education ? JSON.stringify(validatedData.education) : null,
        certifications: validatedData.certifications ? JSON.stringify(validatedData.certifications) : null,
        awards: validatedData.awards ? JSON.stringify(validatedData.awards) : null,
        socialLinks: validatedData.socialLinks ? JSON.stringify(validatedData.socialLinks) : null,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json(teacherProfile, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error creating teacher profile:', error);
    return NextResponse.json(
      { error: 'Failed to create teacher profile' },
      { status: 500 }
    );
  }
});