import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';
import { adminOnly, AdminUser } from '@/lib/admin-auth';

const updateTeacherProfileSchema = z.object({
  employeeId: z.string().min(1).optional(),
  department: z.string().optional(),
  qualification: z.string().optional(),
  experience: z.number().min(0).optional(),
  bio: z.string().optional(),
  specialties: z.array(z.string()).optional(),
  education: z.array(z.object({
    degree: z.string(),
    institution: z.string(),
    year: z.string(),
  })).optional(),
  certifications: z.array(z.object({
    name: z.string(),
    issuer: z.string(),
    year: z.string(),
    url: z.string().optional(),
  })).optional(),
  awards: z.array(z.object({
    title: z.string(),
    organization: z.string(),
    year: z.string(),
  })).optional(),
  research: z.string().optional(),
  socialLinks: z.record(z.string(), z.string()).optional(),
  website: z.string().url().optional(),
  location: z.string().optional(),
  isActive: z.boolean().optional(),
});

// GET /api/teachers/[id] - Get a specific teacher with detailed profile
export const GET = adminOnly(async (
  request: NextRequest,
  { params }: { params: { id: string } },
  adminUser: AdminUser
) => {
  try {
    const teacher = await db.user.findUnique({
      where: { 
        id: params.id,
        role: 'TEACHER',
      },
      select: {
        id: true,
        name: true,
        email: true,
        avatar: true,
        phone: true,
        createdAt: true,
        teacherProfile: true,
        createdCourses: {
          where: {
            isActive: true,
          },
          include: {
            category: true,
            enrollments: {
              select: {
                id: true,
              },
            },
            reviews: {
              select: {
                rating: true,
              },
            },
            _count: {
              select: {
                enrollments: true,
                reviews: true,
                tests: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
        teacherReviews: {
          include: {
            student: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
          take: 10,
        },
        _count: {
          select: {
            createdCourses: {
              where: {
                isActive: true,
              },
            },
            teacherReviews: true,
          },
        },
      },
    });

    if (!teacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      );
    }

    // Parse JSON fields
    const teacherProfile = teacher.teacherProfile;
    if (teacherProfile) {
      teacherProfile.specialties = teacherProfile.specialties ? JSON.parse(teacherProfile.specialties as string) : null;
      teacherProfile.education = teacherProfile.education ? JSON.parse(teacherProfile.education as string) : null;
      teacherProfile.certifications = teacherProfile.certifications ? JSON.parse(teacherProfile.certifications as string) : null;
      teacherProfile.awards = teacherProfile.awards ? JSON.parse(teacherProfile.awards as string) : null;
      teacherProfile.socialLinks = teacherProfile.socialLinks ? JSON.parse(teacherProfile.socialLinks as string) : null;
    }

    // Calculate course statistics
    const coursesWithStats = teacher.createdCourses.map((course) => {
      const avgRating = course.reviews.length > 0
        ? course.reviews.reduce((sum, review) => sum + review.rating, 0) / course.reviews.length
        : 0;

      return {
        ...course,
        averageRating: Number(avgRating.toFixed(1)),
      };
    });

    return NextResponse.json({
      ...teacher,
      createdCourses: coursesWithStats,
    });
  } catch (error) {
    console.error('Error fetching teacher:', error);
    return NextResponse.json(
      { error: 'Failed to fetch teacher' },
      { status: 500 }
    );
  }
});

// PUT /api/teachers/[id] - Update a teacher profile
export const PUT = adminOnly(async (
  request: NextRequest,
  { params }: { params: { id: string } },
  adminUser: AdminUser
) => {
  try {
    const body = await request.json();
    const validatedData = updateTeacherProfileSchema.parse(body);

    // Check if teacher exists
    const existingTeacher = await db.user.findUnique({
      where: { 
        id: params.id,
        role: 'TEACHER',
      },
    });

    if (!existingTeacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      );
    }

    // Check if teacher profile exists
    const existingProfile = await db.teacherProfile.findUnique({
      where: { userId: params.id },
    });

    if (!existingProfile) {
      return NextResponse.json(
        { error: 'Teacher profile not found' },
        { status: 404 }
      );
    }

    // Check if employee ID is being changed and if it already exists
    if (validatedData.employeeId && validatedData.employeeId !== existingProfile.employeeId) {
      const existingEmployeeId = await db.teacherProfile.findUnique({
        where: { employeeId: validatedData.employeeId },
      });

      if (existingEmployeeId) {
        return NextResponse.json(
          { error: 'Employee ID already exists' },
          { status: 400 }
        );
      }
    }

    const teacherProfile = await db.teacherProfile.update({
      where: { userId: params.id },
      data: {
        ...validatedData,
        specialties: validatedData.specialties ? JSON.stringify(validatedData.specialties) : undefined,
        education: validatedData.education ? JSON.stringify(validatedData.education) : undefined,
        certifications: validatedData.certifications ? JSON.stringify(validatedData.certifications) : undefined,
        awards: validatedData.awards ? JSON.stringify(validatedData.awards) : undefined,
        socialLinks: validatedData.socialLinks ? JSON.stringify(validatedData.socialLinks) : undefined,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    // Parse JSON fields for response
    const responseProfile = {
      ...teacherProfile,
      specialties: teacherProfile.specialties ? JSON.parse(teacherProfile.specialties as string) : null,
      education: teacherProfile.education ? JSON.parse(teacherProfile.education as string) : null,
      certifications: teacherProfile.certifications ? JSON.parse(teacherProfile.certifications as string) : null,
      awards: teacherProfile.awards ? JSON.parse(teacherProfile.awards as string) : null,
      socialLinks: teacherProfile.socialLinks ? JSON.parse(teacherProfile.socialLinks as string) : null,
    };

    return NextResponse.json(responseProfile);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error updating teacher profile:', error);
    return NextResponse.json(
      { error: 'Failed to update teacher profile' },
      { status: 500 }
    );
  }
});