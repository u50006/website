import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const role = searchParams.get('role');
    const courseId = searchParams.get('courseId');

    let users;

    if (role === 'STUDENT') {
      // Get all students with their profiles and enrollments
      users = await db.user.findMany({
        where: { role: 'STUDENT' },
        include: {
          studentProfile: true,
          enrollments: {
            include: {
              course: {
                select: {
                  id: true,
                  title: true,
                  code: true,
                }
              }
            }
          }
        },
        orderBy: { name: 'asc' }
      });
    } else if (role === 'TEACHER') {
      // Get all teachers with their profiles
      users = await db.user.findMany({
        where: { role: 'TEACHER' },
        include: {
          teacherProfile: true,
          _count: {
            select: {
              createdCourses: true,
            }
          }
        },
        orderBy: { name: 'asc' }
      });
    } else if (courseId) {
      // Get students enrolled in a specific course
      const enrollments = await db.enrollment.findMany({
        where: { courseId, status: 'ACTIVE' },
        include: {
          student: {
            include: {
              studentProfile: true,
            }
          }
        },
        orderBy: { enrolledAt: 'desc' }
      });
      
      users = enrollments.map(e => ({
        ...e.student,
        enrollment: {
          progress: e.progress,
          enrolledAt: e.enrolledAt,
          status: e.status
        }
      }));
    } else {
      // Get all users
      users = await db.user.findMany({
        include: {
          studentProfile: true,
          teacherProfile: true,
        },
        orderBy: { name: 'asc' }
      });
    }

    // Remove passwords from response
    const sanitizedUsers = users.map(user => {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    });

    return NextResponse.json(sanitizedUsers);

  } catch (error) {
    console.error('Error fetching users:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}