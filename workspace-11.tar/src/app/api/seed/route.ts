import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

export async function POST(request: NextRequest) {
  try {
    // Create sample teacher
    const teacherPassword = await bcrypt.hash('teacher123', 10);
    const teacher = await db.user.upsert({
      where: { email: 'teacher@educonnect.com' },
      update: {},
      create: {
        email: 'teacher@educonnect.com',
        password: teacherPassword,
        name: 'Dr. Sarah Johnson',
        role: 'TEACHER',
      },
    });

    // Create teacher profile
    await db.teacherProfile.upsert({
      where: { userId: teacher.id },
      update: {},
      create: {
        userId: teacher.id,
        employeeId: 'T001',
        department: 'Computer Science',
        qualification: 'PhD in Computer Science',
        experience: 10,
        bio: 'Experienced educator specializing in web development and data structures.',
        hireDate: new Date('2020-08-01'),
      }
    });

    // Create sample student
    const studentPassword = await bcrypt.hash('student123', 10);
    const student = await db.user.upsert({
      where: { email: 'student@educonnect.com' },
      update: {},
      create: {
        email: 'student@educonnect.com',
        password: studentPassword,
        name: 'John Doe',
        role: 'STUDENT',
      },
    });

    // Create student profile
    await db.studentProfile.upsert({
      where: { userId: student.id },
      update: {},
      create: {
        userId: student.id,
        studentId: 'S001',
        grade: '10',
        section: 'A',
        rollNumber: '001',
        parentName: 'Jane Doe',
        parentPhone: '+1234567890',
        parentEmail: 'parent@educonnect.com',
      }
    });

    // Create sample course
    const course = await db.course.upsert({
      where: { code: 'CS101' },
      update: {},
      create: {
        title: 'Introduction to Web Development',
        description: 'Learn the fundamentals of web development including HTML, CSS, and JavaScript.',
        code: 'CS101',
        credits: 3,
        duration: 12,
        level: 'BEGINNER',
        category: 'Web Development',
        teacherId: teacher.id,
      }
    });

    // Enroll student in course
    await db.enrollment.upsert({
      where: {
        studentId_courseId: {
          studentId: student.id,
          courseId: course.id
        }
      },
      update: {},
      create: {
        studentId: student.id,
        courseId: course.id,
        status: 'ACTIVE',
        progress: 25,
      }
    });

    // Create sample test
    const test = await db.test.upsert({
      where: { id: 'test-1' },
      update: {},
      create: {
        id: 'test-1',
        title: 'Web Development Basics Quiz',
        description: 'Test your knowledge of HTML, CSS, and JavaScript fundamentals.',
        courseId: course.id,
        teacherId: teacher.id,
        duration: 30,
        totalMarks: 20,
        passingMarks: 12,
        isPublished: true,
        startTime: new Date(),
        endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      }
    });

    // Create sample questions
    const questions = [
      {
        testId: test.id,
        question: 'What does HTML stand for?',
        type: 'MULTIPLE_CHOICE' as const,
        options: JSON.stringify([
          'Hyper Text Markup Language',
          'High Tech Modern Language',
          'Home Tool Markup Language',
          'Hyperlinks and Text Markup Language'
        ]),
        correctAnswer: 'Hyper Text Markup Language',
        marks: 4,
        order: 1,
      },
      {
        testId: test.id,
        question: 'CSS is used for styling web pages.',
        type: 'TRUE_FALSE' as const,
        correctAnswer: 'true',
        marks: 2,
        order: 2,
      },
      {
        testId: test.id,
        question: 'What is the purpose of JavaScript in web development?',
        type: 'SHORT_ANSWER' as const,
        correctAnswer: 'to add interactivity and dynamic behavior to web pages',
        marks: 4,
        order: 3,
      },
      {
        testId: test.id,
        question: 'Explain the difference between frontend and backend development.',
        type: 'ESSAY' as const,
        marks: 10,
        order: 4,
      }
    ];

    for (const question of questions) {
      await db.question.upsert({
        where: {
          testId_order: {
            testId: question.testId,
            order: question.order
          }
        },
        update: {},
        create: question,
      });
    }

    // Create sample grade
    await db.grade.upsert({
      where: { id: 'grade-1' },
      update: {},
      create: {
        id: 'grade-1',
        studentId: student.id,
        courseId: course.id,
        assignmentName: 'First Assignment',
        marks: 85,
        totalMarks: 100,
        percentage: 85,
        grade: 'B',
        feedback: 'Good work! Keep practicing.',
        gradedBy: teacher.id,
        semester: 'Fall 2024',
        academicYear: '2024-2025',
      }
    });

    return NextResponse.json({
      message: 'Sample data created successfully',
      data: {
        teacher: { email: 'teacher@educonnect.com', password: 'teacher123' },
        student: { email: 'student@educonnect.com', password: 'student123' },
        course: course.code,
        test: test.title,
      }
    });

  } catch (error) {
    console.error('Error seeding data:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}