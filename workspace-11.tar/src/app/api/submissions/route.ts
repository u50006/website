import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { testId, studentId, answers } = await request.json();

    if (!testId || !studentId || !answers) {
      return NextResponse.json(
        { error: 'Test ID, student ID, and answers are required' },
        { status: 400 }
      );
    }

    // Check if submission already exists
    const existingSubmission = await db.testSubmission.findUnique({
      where: {
        testId_studentId: {
          testId,
          studentId
        }
      }
    });

    if (existingSubmission && existingSubmission.status === 'SUBMITTED') {
      return NextResponse.json(
        { error: 'Test already submitted' },
        { status: 400 }
      );
    }

    // Get test details and questions for grading
    const test = await db.test.findUnique({
      where: { id: testId },
      include: {
        questions: {
          orderBy: { order: 'asc' }
        }
      }
    });

    if (!test) {
      return NextResponse.json(
        { error: 'Test not found' },
        { status: 404 }
      );
    }

    // Calculate marks
    let totalMarks = 0;
    const gradedAnswers: any[] = [];

    for (const question of test.questions) {
      const studentAnswer = answers[question.id];
      let isCorrect = false;
      let marks = 0;

      if (question.type === 'MULTIPLE_CHOICE' || question.type === 'TRUE_FALSE') {
        isCorrect = studentAnswer === question.correctAnswer;
        marks = isCorrect ? question.marks : 0;
      } else if (question.type === 'SHORT_ANSWER') {
        // Simple string matching for short answers (case-insensitive)
        isCorrect = studentAnswer?.toLowerCase().trim() === question.correctAnswer?.toLowerCase().trim();
        marks = isCorrect ? question.marks : 0;
      } else if (question.type === 'ESSAY') {
        // Essays need manual grading
        marks = 0; // Will be graded manually
      }

      totalMarks += marks;
      gradedAnswers.push({
        questionId: question.id,
        studentAnswer,
        correctAnswer: question.correctAnswer,
        marks,
        isCorrect
      });
    }

    // Create or update submission
    const submission = await db.testSubmission.upsert({
      where: {
        testId_studentId: {
          testId,
          studentId
        }
      },
      update: {
        answers: JSON.stringify(answers),
        marks: totalMarks,
        status: 'SUBMITTED',
        submittedAt: new Date(),
      },
      create: {
        testId,
        studentId,
        answers: JSON.stringify(answers),
        marks: totalMarks,
        status: 'SUBMITTED',
        submittedAt: new Date(),
      }
    });

    // Create grade record
    const percentage = (totalMarks / test.totalMarks) * 100;
    let grade = 'F';
    
    if (percentage >= 90) grade = 'A';
    else if (percentage >= 80) grade = 'B';
    else if (percentage >= 70) grade = 'C';
    else if (percentage >= 60) grade = 'D';

    await db.grade.create({
      data: {
        studentId,
        testId,
        submissionId: submission.id,
        assignmentName: test.title,
        marks: totalMarks,
        totalMarks: test.totalMarks,
        percentage,
        grade,
        gradedBy: test.teacherId, // Auto-graded by system
      }
    });

    return NextResponse.json({
      message: 'Test submitted successfully',
      submission: {
        ...submission,
        totalMarks,
        percentage,
        grade,
        gradedAnswers
      }
    });

  } catch (error) {
    console.error('Error submitting test:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const testId = searchParams.get('testId');
    const studentId = searchParams.get('studentId');

    let submissions;

    if (testId && studentId) {
      // Get specific submission
      submissions = await db.testSubmission.findUnique({
        where: {
          testId_studentId: {
            testId,
            studentId
          }
        },
        include: {
          test: {
            select: {
              title: true,
              totalMarks: true,
              duration: true,
            }
          },
          student: {
            select: {
              name: true,
              email: true,
            }
          }
        }
      });
    } else if (testId) {
      // Get all submissions for a test
      submissions = await db.testSubmission.findMany({
        where: { testId },
        include: {
          student: {
            select: {
              name: true,
              email: true,
            }
          }
        },
        orderBy: { submittedAt: 'desc' }
      });
    } else if (studentId) {
      // Get all submissions by a student
      submissions = await db.testSubmission.findMany({
        where: { studentId },
        include: {
          test: {
            select: {
              title: true,
              totalMarks: true,
              course: {
                select: {
                  title: true,
                  code: true,
                }
              }
            }
          }
        },
        orderBy: { submittedAt: 'desc' }
      });
    }

    return NextResponse.json(submissions);

  } catch (error) {
    console.error('Error fetching submissions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}