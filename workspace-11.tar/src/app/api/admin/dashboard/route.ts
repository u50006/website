import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { adminOnly, AdminUser } from '@/lib/admin-auth';

// GET /api/admin/dashboard - Get dashboard statistics
export const GET = adminOnly(async (
  request: NextRequest,
  context: any,
  adminUser: AdminUser
) => {
  try {
    const [
      totalUsers,
      totalStudents,
      totalTeachers,
      totalAdmins,
      totalCourses,
      activeCourses,
      totalEnrollments,
      totalTests,
      recentUsers,
      recentCourses,
      topCourses,
      departmentStats
    ] = await Promise.all([
      // Total users
      db.user.count(),
      
      // Total students
      db.user.count({
        where: { role: 'STUDENT' }
      }),
      
      // Total teachers
      db.user.count({
        where: { role: 'TEACHER' }
      }),
      
      // Total admins
      db.user.count({
        where: { role: 'ADMIN' }
      }),
      
      // Total courses
      db.course.count(),
      
      // Active courses
      db.course.count({
        where: { isActive: true }
      }),
      
      // Total enrollments
      db.enrollment.count(),
      
      // Total tests
      db.test.count(),
      
      // Recent users (last 7 days)
      db.user.findMany({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          createdAt: true,
        },
        orderBy: {
          createdAt: 'desc'
        },
        take: 5
      }),
      
      // Recent courses (last 7 days)
      db.course.findMany({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        },
        select: {
          id: true,
          title: true,
          code: true,
          createdAt: true,
          teacher: {
            select: {
              name: true,
            }
          },
          _count: {
            select: {
              enrollments: true,
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        },
        take: 5
      }),
      
      // Top courses by enrollment
      db.course.findMany({
        select: {
          id: true,
          title: true,
          code: true,
          teacher: {
            select: {
              name: true,
            }
          },
          _count: {
            select: {
              enrollments: true,
            }
          }
        },
        orderBy: {
          enrollments: {
            _count: 'desc'
          }
        },
        take: 5
      }),
      
      // Department statistics
      db.teacherProfile.groupBy({
        by: ['department'],
        where: {
          department: {
            not: null
          }
        },
        _count: {
          id: true
        }
      })
    ]);

    // Calculate growth rates (comparing with last month)
    const lastMonth = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const [
      lastMonthUsers,
      lastMonthCourses,
      lastMonthEnrollments
    ] = await Promise.all([
      db.user.count({
        where: {
          createdAt: {
            lt: lastMonth
          }
        }
      }),
      db.course.count({
        where: {
          createdAt: {
            lt: lastMonth
          }
        }
      }),
      db.enrollment.count({
        where: {
          enrolledAt: {
            lt: lastMonth
          }
        }
      })
    ]);

    const userGrowth = totalUsers > 0 ? ((totalUsers - lastMonthUsers) / lastMonthUsers) * 100 : 0;
    const courseGrowth = totalCourses > 0 ? ((totalCourses - lastMonthCourses) / lastMonthCourses) * 100 : 0;
    const enrollmentGrowth = totalEnrollments > 0 ? ((totalEnrollments - lastMonthEnrollments) / lastMonthEnrollments) * 100 : 0;

    return NextResponse.json({
      overview: {
        totalUsers,
        totalStudents,
        totalTeachers,
        totalAdmins,
        totalCourses,
        activeCourses,
        totalEnrollments,
        totalTests,
        userGrowth: Number(userGrowth.toFixed(1)),
        courseGrowth: Number(courseGrowth.toFixed(1)),
        enrollmentGrowth: Number(enrollmentGrowth.toFixed(1)),
      },
      recent: {
        users: recentUsers,
        courses: recentCourses,
      },
      top: {
        courses: topCourses,
      },
      departments: departmentStats.map(dept => ({
        name: dept.department,
        count: dept._count.id,
      })),
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return NextResponse.json(
      { error: 'Failed to fetch dashboard statistics' },
      { status: 500 }
    );
  }
});