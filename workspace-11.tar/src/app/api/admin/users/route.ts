import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';
import { adminOnly, AdminUser } from '@/lib/admin-auth';

const createUserSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Valid email is required'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  role: z.enum(['STUDENT', 'TEACHER', 'ADMIN']),
  phone: z.string().optional(),
  dateOfBirth: z.string().optional(),
  address: z.string().optional(),
});

const updateUserSchema = z.object({
  name: z.string().min(1).optional(),
  email: z.string().email().optional(),
  password: z.string().min(6).optional(),
  role: z.enum(['STUDENT', 'TEACHER', 'ADMIN']).optional(),
  phone: z.string().optional(),
  dateOfBirth: z.string().optional(),
  address: z.string().optional(),
});

// GET /api/admin/users - Get all users with filtering and pagination
export const GET = adminOnly(async (
  request: NextRequest,
  context: any,
  adminUser: AdminUser
) => {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const role = searchParams.get('role');
    const search = searchParams.get('search');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (role) {
      where.role = role;
    }

    if (search) {
      where.OR = [
        {
          name: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          email: {
            contains: search,
            mode: 'insensitive',
          },
        },
      ];
    }

    const [users, total] = await Promise.all([
      db.user.findMany({
        where,
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          avatar: true,
          phone: true,
          dateOfBirth: true,
          address: true,
          createdAt: true,
          updatedAt: true,
          teacherProfile: {
            select: {
              id: true,
              employeeId: true,
              department: true,
              qualification: true,
              experience: true,
              bio: true,
              rating: true,
              totalReviews: true,
              isActive: true,
            },
          },
          studentProfile: {
            select: {
              id: true,
              studentId: true,
              grade: true,
              section: true,
            },
          },
          _count: {
            select: {
              createdCourses: true,
              enrollments: true,
              testSubmissions: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),
      db.user.count({ where }),
    ]);

    return NextResponse.json({
      users,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching users:', error);
    return NextResponse.json(
      { error: 'Failed to fetch users' },
      { status: 500 }
    );
  }
});

// POST /api/admin/users - Create a new user
export const POST = adminOnly(async (
  request: NextRequest,
  context: any,
  adminUser: AdminUser
) => {
  try {
    const body = await request.json();
    const validatedData = createUserSchema.parse(body);

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email: validatedData.email },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 400 }
      );
    }

    // Hash password (in production, use bcrypt)
    const hashedPassword = validatedData.password; // TODO: Implement proper hashing

    const user = await db.user.create({
      data: {
        ...validatedData,
        password: hashedPassword,
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        avatar: true,
        phone: true,
        dateOfBirth: true,
        address: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    // Create profile based on role
    if (validatedData.role === 'TEACHER') {
      await db.teacherProfile.create({
        data: {
          userId: user.id,
          employeeId: `EMP${Date.now()}`,
        },
      });
    } else if (validatedData.role === 'STUDENT') {
      await db.studentProfile.create({
        data: {
          userId: user.id,
          studentId: `STU${Date.now()}`,
        },
      });
    }

    return NextResponse.json(user, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error creating user:', error);
    return NextResponse.json(
      { error: 'Failed to create user' },
      { status: 500 }
    );
  }
});