import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';
import { adminOnly, AdminUser } from '@/lib/admin-auth';

const updateUserSchema = z.object({
  name: z.string().min(1).optional(),
  email: z.string().email().optional(),
  password: z.string().min(6).optional(),
  role: z.enum(['STUDENT', 'TEACHER', 'ADMIN']).optional(),
  phone: z.string().optional(),
  dateOfBirth: z.string().optional(),
  address: z.string().optional(),
});

// GET /api/admin/users/[id] - Get a specific user
export const GET = adminOnly(async (
  request: NextRequest,
  { params }: { params: { id: string } },
  adminUser: AdminUser
) => {
  try {
    const user = await db.user.findUnique({
      where: { id: params.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        avatar: true,
        phone: true,
        dateOfBirth: true,
        address: true,
        createdAt: true,
        updatedAt: true,
        teacherProfile: {
          select: {
            id: true,
            employeeId: true,
            department: true,
            qualification: true,
            experience: true,
            bio: true,
            rating: true,
            totalReviews: true,
            isActive: true,
            hireDate: true,
          },
        },
        studentProfile: {
          select: {
            id: true,
            studentId: true,
            grade: true,
            section: true,
            rollNumber: true,
            parentName: true,
            parentPhone: true,
            parentEmail: true,
          },
        },
        _count: {
          select: {
            createdCourses: true,
            enrollments: true,
            testSubmissions: true,
            grades: true,
            attendance: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(user);
  } catch (error) {
    console.error('Error fetching user:', error);
    return NextResponse.json(
      { error: 'Failed to fetch user' },
      { status: 500 }
    );
  }
});

// PUT /api/admin/users/[id] - Update a user
export const PUT = adminOnly(async (
  request: NextRequest,
  { params }: { params: { id: string } },
  adminUser: AdminUser
) => {
  try {
    const body = await request.json();
    const validatedData = updateUserSchema.parse(body);

    // Check if user exists
    const existingUser = await db.user.findUnique({
      where: { id: params.id },
    });

    if (!existingUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // If updating email, check if it's already taken
    if (validatedData.email && validatedData.email !== existingUser.email) {
      const emailTaken = await db.user.findUnique({
        where: { email: validatedData.email },
      });

      if (emailTaken) {
        return NextResponse.json(
          { error: 'Email is already taken' },
          { status: 400 }
        );
      }
    }

    // Hash password if provided
    const updateData: any = { ...validatedData };
    if (validatedData.password) {
      updateData.password = validatedData.password; // TODO: Implement proper hashing
    }

    const user = await db.user.update({
      where: { id: params.id },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        avatar: true,
        phone: true,
        dateOfBirth: true,
        address: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    return NextResponse.json(user);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error updating user:', error);
    return NextResponse.json(
      { error: 'Failed to update user' },
      { status: 500 }
    );
  }
});

// DELETE /api/admin/users/[id] - Delete a user
export const DELETE = adminOnly(async (
  request: NextRequest,
  { params }: { params: { id: string } },
  adminUser: AdminUser
) => {
  try {
    // Check if user exists
    const existingUser = await db.user.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            createdCourses: true,
            enrollments: true,
            testSubmissions: true,
          },
        },
      },
    });

    if (!existingUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Prevent deletion of admin users
    if (existingUser.role === 'ADMIN') {
      return NextResponse.json(
        { error: 'Cannot delete admin users' },
        { status: 400 }
      );
    }

    // Check if user has associated data
    if (
      existingUser._count.createdCourses > 0 ||
      existingUser._count.enrollments > 0 ||
      existingUser._count.testSubmissions > 0
    ) {
      return NextResponse.json(
        { error: 'Cannot delete user with associated data. Deactivate instead.' },
        { status: 400 }
      );
    }

    await db.user.delete({
      where: { id: params.id },
    });

    return NextResponse.json(
      { message: 'User deleted successfully' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error deleting user:', error);
    return NextResponse.json(
      { error: 'Failed to delete user' },
      { status: 500 }
    );
  }
});