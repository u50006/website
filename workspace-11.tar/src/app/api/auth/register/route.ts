import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';
import { errorResponse, successResponse, internalErrorResponse, tooManyRequestsResponse } from '@/lib/http';
import { tooManyAttempts, getClientIdentifier } from '@/lib/rateLimiter';
import { validateRequestBody, registerSchema } from '@/lib/validation';

export async function POST(request: NextRequest) {
  try {
    const clientIdentifier = getClientIdentifier(request);
    
    // Rate limiting check (more lenient for registration)
    if (tooManyAttempts(clientIdentifier)) {
      return tooManyRequestsResponse();
    }

    const body = await request.json();
    
    // Validate request body
    const validation = validateRequestBody(registerSchema, body);
    if (!validation.success) {
      return errorResponse(`Validation error: ${validation.error}`, 400);
    }
    
    const { email, password, name, role, profileData } = validation.data;

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return errorResponse('User with this email already exists', 409);
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create user
    const user = await db.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        role: role || 'STUDENT',
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        createdAt: true,
      }
    });

    // Create profile based on role
    if (role === 'TEACHER' && profileData && profileData.employeeId) {
      await db.teacherProfile.create({
        data: {
          userId: user.id,
          employeeId: profileData.employeeId,
          department: profileData.department || null,
          qualification: profileData.qualification || null,
          experience: profileData.experience || null,
          bio: profileData.bio || null,
          hireDate: profileData.hireDate ? new Date(profileData.hireDate) : null,
        }
      });
    } else if (role === 'STUDENT' && profileData && profileData.studentId) {
      await db.studentProfile.create({
        data: {
          userId: user.id,
          studentId: profileData.studentId,
          grade: profileData.grade || null,
          section: profileData.section || null,
          rollNumber: profileData.rollNumber || null,
          parentName: profileData.parentName || null,
          parentPhone: profileData.parentPhone || null,
          parentEmail: profileData.parentEmail || null,
        }
      });
    }

    return successResponse({
      message: 'User registered successfully',
      user
    }, 201);

  } catch (error) {
    console.error('Registration error:', error);
    return internalErrorResponse('Registration failed');
  }
}