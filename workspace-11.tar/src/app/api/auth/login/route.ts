import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';
import { signToken } from '@/lib/auth';
import { errorResponse, successResponse, unauthorizedResponse, internalErrorResponse, tooManyRequestsResponse } from '@/lib/http';
import { tooManyAttempts, getClientIdentifier } from '@/lib/rateLimiter';
import { validateRequestBody, loginSchema } from '@/lib/validation';

export async function POST(request: NextRequest) {
  try {
    const clientIdentifier = getClientIdentifier(request);
    
    // Rate limiting check
    if (tooManyAttempts(clientIdentifier)) {
      return tooManyRequestsResponse();
    }

    const body = await request.json();
    
    // Validate request body
    const validation = validateRequestBody(loginSchema, body);
    if (!validation.success) {
      return errorResponse(`Validation error: ${validation.error}`, 400);
    }
    
    const { email, password } = validation.data;

    // Find user with profile
    const user = await db.user.findUnique({
      where: { email },
      include: {
        teacherProfile: true,
        studentProfile: true,
      }
    });

    if (!user) {
      return unauthorizedResponse('Invalid credentials');
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return unauthorizedResponse('Invalid credentials');
    }

    // Create JWT token with proper claims
    const token = signToken({ 
      sub: user.id, 
      role: user.role 
    });

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user;

    return successResponse({
      message: 'Login successful',
      token,
      user: userWithoutPassword
    });

  } catch (error) {
    console.error('Login error:', error);
    return internalErrorResponse('Login failed');
  }
}