import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST() {
  try {
    // First, let's check if there are any teachers
    const teachers = await db.user.findMany({
      where: { role: 'TEACHER' },
      select: { id: true, name: true }
    });

    if (teachers.length === 0) {
      return NextResponse.json({ error: 'No teachers found' }, { status: 400 });
    }

    const teacherId = teachers[0].id;

    // Sample courses
    const sampleCourses = [
      {
        title: 'Introduction to Web Development',
        description: 'Learn the fundamentals of HTML, CSS, and JavaScript to build modern websites.',
        code: 'WEB101',
        credits: 3,
        duration: 12,
        level: 'BEGINNER',
        category: 'Web Development',
        teacherId
      },
      {
        title: 'Advanced React and Next.js',
        description: 'Master React hooks, context, and Next.js for building production-ready applications.',
        code: 'REACT201',
        credits: 4,
        duration: 8,
        level: 'ADVANCED',
        category: 'Web Development',
        teacherId
      },
      {
        title: 'Database Design and SQL',
        description: 'Learn database design principles and SQL for managing relational databases.',
        code: 'DB101',
        credits: 3,
        duration: 10,
        level: 'INTERMEDIATE',
        category: 'Database',
        teacherId
      },
      {
        title: 'Machine Learning Basics',
        description: 'Introduction to machine learning concepts, algorithms, and practical applications.',
        code: 'ML101',
        credits: 4,
        duration: 14,
        level: 'INTERMEDIATE',
        category: 'Artificial Intelligence',
        teacherId
      },
      {
        title: 'Mobile App Development',
        description: 'Build cross-platform mobile applications using React Native.',
        code: 'MOBILE201',
        credits: 3,
        duration: 12,
        level: 'ADVANCED',
        category: 'Mobile Development',
        teacherId
      }
    ];

    // Create courses
    const createdCourses = [];
    for (const course of sampleCourses) {
      const existingCourse = await db.course.findUnique({
        where: { code: course.code }
      });

      if (!existingCourse) {
        const createdCourse = await db.course.create({
          data: course,
          include: {
            teacher: {
              select: {
                id: true,
                name: true,
                email: true,
              }
            }
          }
        });
        createdCourses.push(createdCourse);
      }
    }

    return NextResponse.json({
      message: 'Sample courses created successfully',
      courses: createdCourses
    });

  } catch (error) {
    console.error('Error seeding courses:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}