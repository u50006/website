import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const updateCourseSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  credits: z.number().min(1).max(10).optional(),
  duration: z.number().min(1).max(52).optional(),
  level: z.enum(['beginner', 'intermediate', 'advanced']).optional(),
  categoryId: z.string().optional(),
  thumbnail: z.string().url().optional(),
  price: z.number().min(0).optional(),
  language: z.string().optional(),
  isActive: z.boolean().optional(),
  teacherId: z.string().min(1, 'Teacher ID is required').optional(),
});

// GET /api/courses/[id] - Get a specific course
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const course = await db.course.findUnique({
      where: { id },
      include: {
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            teacherProfile: {
              select: {
                department: true,
                qualification: true,
                experience: true,
                bio: true,
                specialties: true,
                rating: true,
                totalReviews: true,
              },
            },
          },
        },
        category: true,
        enrollments: {
          include: {
            student: {
              select: {
                id: true,
                name: true,
                email: true,
                avatar: true,
              },
            },
          },
        },
        materials: {
          orderBy: {
            order: 'asc',
          },
        },
        tests: {
          include: {
            _count: {
              select: {
                questions: true,
                submissions: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
        reviews: {
          include: {
            student: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
          take: 10,
        },
        _count: {
          select: {
            enrollments: true,
            tests: true,
            reviews: true,
            materials: true,
          },
        },
      },
    });

    if (!course) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      );
    }

    // Calculate average rating
    const avgRating = course.reviews.length > 0
      ? course.reviews.reduce((sum, review) => sum + review.rating, 0) / course.reviews.length
      : 0;

    const courseWithStats = {
      ...course,
      averageRating: Number(avgRating.toFixed(1)),
      totalStudents: course._count.enrollments,
      totalTests: course._count.tests,
      totalReviews: course._count.reviews,
    };

    return NextResponse.json(courseWithStats);
  } catch (error) {
    console.error('Error fetching course:', error);
    return NextResponse.json(
      { error: 'Failed to fetch course' },
      { status: 500 }
    );
  }
}

// PUT /api/courses/[id] - Update a course
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const validatedData = updateCourseSchema.parse(body);

    // Check if course exists
    const existingCourse = await db.course.findUnique({
      where: { id },
    });

    if (!existingCourse) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      );
    }

    // If teacherId is being updated, validate the teacher
    if (validatedData.teacherId) {
      const teacher = await db.user.findUnique({
        where: { 
          id: validatedData.teacherId,
          role: 'TEACHER',
        },
      });

      if (!teacher) {
        return NextResponse.json(
          { error: 'Invalid teacher ID or user is not a teacher' },
          { status: 400 }
        );
      }
    }

    const course = await db.course.update({
      where: { id },
      data: validatedData,
      include: {
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
            teacherProfile: {
              select: {
                department: true,
                qualification: true,
                experience: true,
                bio: true,
                specialties: true,
                rating: true,
                totalReviews: true,
              },
            },
          },
        },
        category: true,
      },
    });

    return NextResponse.json(course);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error updating course:', error);
    return NextResponse.json(
      { error: 'Failed to update course' },
      { status: 500 }
    );
  }
}

// DELETE /api/courses/[id] - Delete a course
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    // Check if course exists
    const existingCourse = await db.course.findUnique({
      where: { id },
      include: {
        enrollments: true,
        tests: true,
      },
    });

    if (!existingCourse) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      );
    }

    // Check if course has enrollments or tests
    if (existingCourse.enrollments.length > 0 || existingCourse.tests.length > 0) {
      return NextResponse.json(
        { error: 'Cannot delete course with existing enrollments or tests' },
        { status: 400 }
      );
    }

    await db.course.delete({
      where: { id },
    });

    return NextResponse.json(
      { message: 'Course deleted successfully' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error deleting course:', error);
    return NextResponse.json(
      { error: 'Failed to delete course' },
      { status: 500 }
    );
  }
}