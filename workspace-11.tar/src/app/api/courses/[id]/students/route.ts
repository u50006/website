import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const enrollments = await db.enrollment.findMany({
      where: { courseId: params.id, status: 'ACTIVE' },
      include: {
        student: {
          include: {
            studentProfile: true,
          }
        }
      },
      orderBy: { enrolledAt: 'desc' }
    });

    const students = enrollments.map(enrollment => ({
      id: enrollment.student.id,
      name: enrollment.student.name,
      email: enrollment.student.email,
      studentProfile: enrollment.student.studentProfile,
      enrollment: {
        progress: enrollment.progress,
        enrolledAt: enrollment.enrolledAt,
        status: enrollment.status
      }
    }));

    return NextResponse.json(students);

  } catch (error) {
    console.error('Error fetching students:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}