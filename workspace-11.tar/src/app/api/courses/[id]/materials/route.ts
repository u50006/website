import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const materials = await db.courseMaterial.findMany({
      where: { courseId: params.id },
      orderBy: { order: 'asc' }
    });

    return NextResponse.json(materials);

  } catch (error) {
    console.error('Error fetching materials:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { title, type, content, order, isRequired } = await request.json();

    const material = await db.courseMaterial.create({
      data: {
        courseId: params.id,
        title,
        type,
        content,
        order: order || 0,
        isRequired: isRequired || false,
      }
    });

    return NextResponse.json({
      message: 'Material created successfully',
      material
    });

  } catch (error) {
    console.error('Error creating material:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}