import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const createCourseSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  code: z.string().min(1, 'Course code is required'),
  credits: z.number().min(1).max(10).default(3),
  duration: z.number().min(1).max(52).default(12),
  level: z.enum(['beginner', 'intermediate', 'advanced']).optional(),
  categoryId: z.string().optional(),
  thumbnail: z.string().url().optional(),
  price: z.number().min(0).default(0),
  language: z.string().default('English'),
  teacherId: z.string().min(1, 'Teacher ID is required'),
});

// GET /api/courses - Get all courses with filtering and pagination
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category');
    const level = searchParams.get('level');
    const teacherId = searchParams.get('teacherId');
    const search = searchParams.get('search');
    const isActive = searchParams.get('isActive') !== 'false';

    const skip = (page - 1) * limit;

    const where: any = {
      isActive,
    };

    if (category) {
      where.category = {
        name: {
          contains: category,
          mode: 'insensitive',
        },
      };
    }

    if (level) {
      where.level = level;
    }

    if (teacherId) {
      where.teacherId = teacherId;
    }

    if (search) {
      where.OR = [
        {
          title: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          description: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          code: {
            contains: search,
            mode: 'insensitive',
          },
        },
      ];
    }

    const [courses, total] = await Promise.all([
      db.course.findMany({
        where,
        include: {
          teacher: {
            select: {
              id: true,
              name: true,
              email: true,
              teacherProfile: {
                select: {
                  department: true,
                  experience: true,
                  rating: true,
                },
              },
            },
          },
          category: true,
          enrollments: {
            select: {
              id: true,
            },
          },
          tests: {
            select: {
              id: true,
              title: true,
              isPublished: true,
            },
          },
          reviews: {
            select: {
              rating: true,
            },
            take: 1,
          },
          _count: {
            select: {
              enrollments: true,
              tests: true,
              reviews: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),
      db.course.count({ where }),
    ]);

    // Calculate average rating for each course
    const coursesWithStats = courses.map((course) => {
      const avgRating = course.reviews.length > 0
        ? course.reviews.reduce((sum, review) => sum + review.rating, 0) / course.reviews.length
        : 0;

      return {
        ...course,
        averageRating: Number(avgRating.toFixed(1)),
        totalStudents: course._count.enrollments,
        totalTests: course._count.tests,
        totalReviews: course._count.reviews,
      };
    });

    return NextResponse.json({
      courses: coursesWithStats,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching courses:', error);
    return NextResponse.json(
      { error: 'Failed to fetch courses' },
      { status: 500 }
    );
  }
}

// POST /api/courses - Create a new course
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validatedData = createCourseSchema.parse(body);

    // Check if course code already exists
    const existingCourse = await db.course.findUnique({
      where: { code: validatedData.code },
    });

    if (existingCourse) {
      return NextResponse.json(
        { error: 'Course code already exists' },
        { status: 400 }
      );
    }

    // Verify teacher exists and is a teacher
    const teacher = await db.user.findUnique({
      where: { 
        id: validatedData.teacherId,
        role: 'TEACHER',
      },
    });

    if (!teacher) {
      return NextResponse.json(
        { error: 'Invalid teacher ID or user is not a teacher' },
        { status: 400 }
      );
    }

    const course = await db.course.create({
      data: validatedData,
      include: {
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
            teacherProfile: true,
          },
        },
        category: true,
      },
    });

    return NextResponse.json(course, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      );
    }

    console.error('Error creating course:', error);
    return NextResponse.json(
      { error: 'Failed to create course' },
      { status: 500 }
    );
  }
}