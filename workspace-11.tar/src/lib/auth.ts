import jwt from 'jsonwebtoken';

export interface JWTPayload {
  sub: string;
  role?: string;
  iat?: number;
  exp?: number;
}

export function requireJwtFromHeader(authorization?: string): JWTPayload {
  if (!authorization) {
    throw new Error('Missing Authorization header');
  }
  
  const parts = authorization.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    throw new Error('Malformed Authorization header. Expected: Bearer <token>');
  }
  
  const token = parts[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET!, { algorithms: ['HS256'] });
    return payload as JWTPayload;
  } catch (err) {
    throw new Error('Invalid or expired token');
  }
}

export function signToken(payload: { sub: string; role?: string }): string {
  return jwt.sign(payload, process.env.JWT_SECRET!, { 
    algorithm: 'HS256', 
    expiresIn: '1h' 
  });
}

export function verifyToken(token: string): JWTPayload {
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET!, { algorithms: ['HS256'] });
    return payload as JWTPayload;
  } catch (err) {
    throw new Error('Invalid or expired token');
  }
}