import { Server } from 'socket.io';
import { verifyToken } from './auth';

export const setupSocket = (io: Server) => {
  // CRITICAL: Add authentication middleware for all socket connections
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || 
                  socket.handshake.headers['authorization']?.split(' ')[1];
    
    if (!token) {
      return next(new Error('Authentication error: token missing'));
    }
    
    try {
      const payload = verifyToken(token);
      (socket as any).user = payload;
      console.log(`Socket authenticated: user ${payload.sub} (${payload.role})`);
      next();
    } catch (err) {
      console.error('Socket authentication failed:', err);
      next(new Error('Authentication error: invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const user = (socket as any).user;
    console.log(`Client connected: ${socket.id}, User: ${user.sub} (${user.role})`);
    
    // Handle messages
    socket.on('message', (msg: { text: string; senderId: string }) => {
      // Echo: broadcast message only the client who send the message
      socket.emit('message', {
        text: `Echo: ${msg.text}`,
        senderId: 'system',
        timestamp: new Date().toISOString(),
      });
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log(`Client disconnected: ${socket.id}, User: ${user.sub}`);
    });

    // Send welcome message
    socket.emit('message', {
      text: `Welcome to WebSocket Echo Server! Authenticated as ${user.role}`,
      senderId: 'system',
      timestamp: new Date().toISOString(),
    });
  });
};