import { NextResponse } from 'next/server';

export function errorResponse(message: string, status = 400) {
  return new NextResponse(JSON.stringify({ error: message }), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}

export function successResponse(data: any, status = 200) {
  return NextResponse.json(data, { status });
}

export function unauthorizedResponse(message = 'Unauthorized') {
  return errorResponse(message, 401);
}

export function forbiddenResponse(message = 'Forbidden') {
  return errorResponse(message, 403);
}

export function notFoundResponse(message = 'Not found') {
  return errorResponse(message, 404);
}

export function tooManyRequestsResponse(message = 'Too many requests, try again later') {
  return errorResponse(message, 429);
}

export function internalErrorResponse(message = 'Internal server error') {
  return errorResponse(message, 500);
}