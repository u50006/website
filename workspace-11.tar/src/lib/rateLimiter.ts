// Simple in-memory rate limiter for development/single-instance
// For production, use Redis-backed rate limiting

interface RateLimitEntry {
  count: number;
  firstAttempt: number;
}

const attempts = new Map<string, RateLimitEntry>();
const WINDOW = 15 * 60 * 1000; // 15 minutes
const MAX_ATTEMPTS = 5; // Maximum attempts per window

export function tooManyAttempts(key: string): boolean {
  const now = Date.now();
  const entry = attempts.get(key) || { count: 0, firstAttempt: now };
  
  // Reset window if expired
  if (now - entry.firstAttempt > WINDOW) {
    attempts.set(key, { count: 1, firstAttempt: now });
    return false;
  }
  
  // Increment count
  entry.count += 1;
  attempts.set(key, entry);
  
  // Check if exceeded
  return entry.count > MAX_ATTEMPTS;
}

export function getRemainingAttempts(key: string): { remaining: number; resetTime: number } {
  const entry = attempts.get(key);
  if (!entry) {
    return { remaining: MAX_ATTEMPTS, resetTime: Date.now() + WINDOW };
  }
  
  const now = Date.now();
  if (now - entry.firstAttempt > WINDOW) {
    return { remaining: MAX_ATTEMPTS, resetTime: now + WINDOW };
  }
  
  const remaining = Math.max(0, MAX_ATTEMPTS - entry.count);
  const resetTime = entry.firstAttempt + WINDOW;
  
  return { remaining, resetTime };
}

export function getClientIdentifier(request: Request): string {
  // Try to get real IP, fallback to user agent
  const forwarded = request.headers.get('x-forwarded-for');
  const realIp = forwarded?.split(',')[0]?.trim();
  const userAgent = request.headers.get('user-agent') || 'unknown';
  
  return realIp || userAgent;
}

// Clean up old entries periodically (call this from time to time)
export function cleanupRateLimit() {
  const now = Date.now();
  for (const [key, entry] of attempts.entries()) {
    if (now - entry.firstAttempt > WINDOW) {
      attempts.delete(key);
    }
  }
}