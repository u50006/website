import { z } from 'zod';

// User validation schemas
export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required')
});

export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters long'),
  name: z.string().min(1, 'Name is required').max(100, 'Name must be less than 100 characters'),
  role: z.enum(['STUDENT', 'TEACHER', 'ADMIN']).optional().default('STUDENT'),
  profileData: z.object({
    employeeId: z.string().optional(),
    studentId: z.string().optional(),
    department: z.string().optional(),
    qualification: z.string().optional(),
    experience: z.number().min(0).max(100).optional(),
    bio: z.string().max(1000).optional(),
    grade: z.string().optional(),
    section: z.string().optional(),
    rollNumber: z.string().optional(),
    parentName: z.string().optional(),
    parentPhone: z.string().optional(),
    parentEmail: z.string().email().optional(),
    hireDate: z.string().optional()
  }).optional()
});

// Course validation schemas
export const courseCreateSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200, 'Title must be less than 200 characters'),
  description: z.string().max(2000, 'Description must be less than 2000 characters').optional(),
  code: z.string().min(1, 'Course code is required').max(20, 'Course code must be less than 20 characters'),
  credits: z.number().min(1).max(10).default(3),
  duration: z.number().min(1).max(52).default(12), // weeks
  level: z.enum(['beginner', 'intermediate', 'advanced']).optional(),
  categoryId: z.string().optional(),
  price: z.number().min(0).default(0),
  language: z.string().max(50).default('English')
});

export const courseUpdateSchema = courseCreateSchema.partial();

// Test validation schemas
export const testCreateSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200),
  description: z.string().max(2000).optional(),
  courseId: z.string().min(1, 'Course ID is required'),
  duration: z.number().min(1).max(480), // max 8 hours
  totalMarks: z.number().min(1),
  passingMarks: z.number().min(0),
  startTime: z.string().datetime().optional(),
  endTime: z.string().datetime().optional()
}).refine((data) => !data.passingMarks || data.passingMarks <= data.totalMarks, {
  message: "Passing marks cannot be greater than total marks",
  path: ["passingMarks"]
});

// Question validation schemas
export const questionCreateSchema = z.object({
  testId: z.string().min(1, 'Test ID is required'),
  question: z.string().min(1, 'Question is required').max(2000),
  type: z.enum(['MULTIPLE_CHOICE', 'TRUE_FALSE', 'SHORT_ANSWER', 'ESSAY']),
  options: z.string().optional(), // JSON string for multiple choice
  correctAnswer: z.string().optional(),
  marks: z.number().min(1).max(100).default(1),
  explanation: z.string().max(1000).optional(),
  order: z.number().min(0).default(0)
});

// Enrollment validation schemas
export const enrollmentSchema = z.object({
  courseId: z.string().min(1, 'Course ID is required')
});

// Helper function to validate request body
export function validateRequestBody<T>(schema: z.ZodSchema<T>, body: unknown): { success: true; data: T } | { success: false; error: string } {
  const result = schema.safeParse(body);
  if (!result.success) {
    const errorMessages = result.error.issues.map(err => `${err.path.join('.')}: ${err.message}`).join(', ');
    return { success: false, error: errorMessages };
  }
  return { success: true, data: result.data };
}