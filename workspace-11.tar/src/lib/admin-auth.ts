import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'ADMIN';
}

export async function verifyAdminToken(request: NextRequest): Promise<{ user: AdminUser } | null> {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      console.log('No token provided in authorization header');
      return null;
    }

    // Check if token looks like a JWT (basic format validation)
    if (!token.includes('.') || token.split('.').length !== 3) {
      console.log('Invalid token format - not a proper JWT');
      return null;
    }

    // Verify JWT token
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    
    // Fetch user from database to verify admin role
    const user = await db.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
      }
    });

    if (!user || user.role !== 'ADMIN') {
      console.log('User not found or not admin:', decoded.userId);
      return null;
    }

    return { user: user as AdminUser };
  } catch (error) {
    console.error('Admin token verification failed:', error);
    if (error instanceof jwt.JsonWebTokenError) {
      console.log('JWT Error:', error.message);
    }
    return null;
  }
}

export function adminOnly(handler: (request: NextRequest, context: any, user: AdminUser) => Promise<NextResponse>) {
  return async (request: NextRequest, context: any) => {
    const adminAuth = await verifyAdminToken(request);
    
    if (!adminAuth) {
      return NextResponse.json(
        { error: 'Unauthorized. Admin access required.' },
        { status: 401 }
      );
    }

    return handler(request, context, adminAuth.user);
  };
}

export function createAdminToken(user: AdminUser): string {
  return jwt.sign(
    { 
      userId: user.id,
      email: user.email,
      role: user.role 
    },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
}