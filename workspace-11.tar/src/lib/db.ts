import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Conditional logging: only in development, not in production
const logQueries = process.env.NODE_ENV === 'development';

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: logQueries ? ['query', 'warn', 'error'] : ['warn', 'error'],
  })

// Export prisma instance for direct access
export const prisma = db;

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db