'use client';

import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Globe, 
  Award,
  BookOpen,
  Users,
  Star,
  Calendar,
  ExternalLink,
  Linkedin,
  Twitter,
  Github
} from 'lucide-react';
import Link from 'next/link';

interface TeacherCardProps {
  teacher: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
    phone?: string;
    createdAt: string;
    teacherProfile: {
      id: string;
      employeeId: string;
      department: string;
      qualification: string;
      experience: number;
      bio: string;
      specialties: string[];
      education: Array<{
        degree: string;
        institution: string;
        year: string;
      }>;
      certifications: Array<{
        name: string;
        issuer: string;
        year: string;
        url?: string;
      }>;
      awards: Array<{
        title: string;
        organization: string;
        year: string;
      }>;
      research: string;
      socialLinks: Record<string, string>;
      website?: string;
      location?: string;
      rating: number;
      totalReviews: number;
      hireDate: string;
    };
    _count: {
      createdCourses: number;
      teacherReviews: number;
    };
    createdCourses: Array<{
      id: string;
      title: string;
      code: string;
      averageRating: number;
      totalStudents: number;
      category?: {
        name: string;
        color?: string;
      };
    }>;
  };
  showContactInfo?: boolean;
  showCourses?: boolean;
}

export function TeacherCard({ 
  teacher, 
  showContactInfo = false,
  showCourses = false 
}: TeacherCardProps) {
  const getSocialIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'linkedin':
        return <Linkedin className="w-4 h-4" />;
      case 'twitter':
        return <Twitter className="w-4 h-4" />;
      case 'github':
        return <Github className="w-4 h-4" />;
      default:
        return <Globe className="w-4 h-4" />;
    }
  };

  const formatExperience = (years: number) => {
    return years === 1 ? '1 year' : `${years} years`;
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <Avatar className="w-20 h-20">
            <AvatarImage src={teacher.avatar} />
            <AvatarFallback className="text-lg">
              {teacher.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 space-y-2">
            <div>
              <h3 className="text-xl font-semibold">{teacher.name}</h3>
              <p className="text-muted-foreground">{teacher.teacherProfile.department}</p>
            </div>
            
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span className="font-medium">{teacher.teacherProfile.rating.toFixed(1)}</span>
                <span className="text-sm text-muted-foreground">
                  ({teacher.teacherProfile.totalReviews} reviews)
                </span>
              </div>
              
              <Badge variant="secondary">
                {formatExperience(teacher.teacherProfile.experience)} experience
              </Badge>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Bio */}
        {teacher.teacherProfile.bio && (
          <div>
            <h4 className="font-medium mb-2">About</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {teacher.teacherProfile.bio}
            </p>
          </div>
        )}

        {/* Specialties */}
        {teacher.teacherProfile.specialties.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Specialties</h4>
            <div className="flex flex-wrap gap-2">
              {teacher.teacherProfile.specialties.map((specialty, index) => (
                <Badge key={index} variant="outline">
                  {specialty}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Education */}
        {teacher.teacherProfile.education.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Education</h4>
            <div className="space-y-2">
              {teacher.teacherProfile.education.map((edu, index) => (
                <div key={index} className="flex items-start gap-2 text-sm">
                  <Award className="w-4 h-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">{edu.degree}</p>
                    <p className="text-muted-foreground">{edu.institution} • {edu.year}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Contact Info */}
        {showContactInfo && (
          <div>
            <h4 className="font-medium mb-2">Contact Information</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Mail className="w-4 h-4 text-muted-foreground" />
                <a href={`mailto:${teacher.email}`} className="text-blue-600 hover:underline">
                  {teacher.email}
                </a>
              </div>
              
              {teacher.phone && (
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <a href={`tel:${teacher.phone}`} className="text-blue-600 hover:underline">
                    {teacher.phone}
                  </a>
                </div>
              )}
              
              {teacher.teacherProfile.location && (
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span>{teacher.teacherProfile.location}</span>
                </div>
              )}
              
              {teacher.teacherProfile.website && (
                <div className="flex items-center gap-2 text-sm">
                  <Globe className="w-4 h-4 text-muted-foreground" />
                  <a 
                    href={teacher.teacherProfile.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline flex items-center gap-1"
                  >
                    Website
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Social Links */}
        {Object.keys(teacher.teacherProfile.socialLinks).length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Connect</h4>
            <div className="flex gap-2">
              {Object.entries(teacher.teacherProfile.socialLinks).map(([platform, url]) => (
                <a
                  key={platform}
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 border rounded-md hover:bg-muted transition-colors"
                >
                  {getSocialIcon(platform)}
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Courses */}
        {showCourses && teacher.createdCourses.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium">Courses ({teacher._count.createdCourses})</h4>
              <Link href={`/teachers/${teacher.id}/courses`}>
                <Button variant="ghost" size="sm">
                  View All
                </Button>
              </Link>
            </div>
            <div className="space-y-2">
              {teacher.createdCourses.slice(0, 3).map((course) => (
                <Link
                  key={course.id}
                  href={`/courses/${course.id}`}
                  className="block p-3 border rounded-lg hover:bg-muted transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h5 className="font-medium text-sm">{course.title}</h5>
                      <p className="text-xs text-muted-foreground">{course.code}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs font-medium">{course.averageRating}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {course.totalStudents} students
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 pt-4 border-t">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">
              {teacher._count.createdCourses}
            </div>
            <p className="text-xs text-muted-foreground">Courses</p>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              {teacher.createdCourses.reduce((sum, course) => sum + course.totalStudents, 0)}
            </div>
            <p className="text-xs text-muted-foreground">Students</p>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">
              {teacher.teacherProfile.rating.toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">Rating</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-4 border-t">
          <Link href={`/teachers/${teacher.id}`} className="flex-1">
            <Button variant="outline" className="w-full">
              View Profile
            </Button>
          </Link>
          <Link href={`/teachers/${teacher.id}/contact`} className="flex-1">
            <Button className="w-full">
              Contact
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}