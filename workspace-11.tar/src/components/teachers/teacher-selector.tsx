'use client';

import { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, User, Star, BookOpen, Award } from 'lucide-react';

interface Teacher {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  teacherProfile?: {
    id: string;
    employeeId: string;
    department: string;
    qualification?: string;
    experience?: number;
    bio?: string;
    specialties?: string;
    rating?: number;
    totalReviews?: number;
    hireDate?: string;
  };
  _count: {
    createdCourses: number;
    teacherReviews: number;
  };
}

interface TeacherSelectorProps {
  selectedTeacherId?: string;
  onTeacherSelect: (teacher: Teacher) => void;
  trigger?: React.ReactNode;
  disabled?: boolean;
}

export function TeacherSelector({ 
  selectedTeacherId, 
  onTeacherSelect, 
  trigger,
  disabled = false 
}: TeacherSelectorProps) {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [filteredTeachers, setFilteredTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [open, setOpen] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

  useEffect(() => {
    fetchTeachers();
  }, []);

  useEffect(() => {
    filterTeachers();
  }, [teachers, searchTerm]);

  const fetchTeachers = async () => {
    try {
      const response = await fetch('/api/teachers?limit=100');
      if (response.ok) {
        const data = await response.json();
        setTeachers(data.teachers || []);
        
        // Set selected teacher if ID is provided
        if (selectedTeacherId) {
          const teacher = data.teachers?.find((t: Teacher) => t.id === selectedTeacherId);
          if (teacher) {
            setSelectedTeacher(teacher);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching teachers:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterTeachers = () => {
    let filtered = teachers;

    if (searchTerm) {
      filtered = filtered.filter(teacher =>
        teacher.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        teacher.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        teacher.teacherProfile?.department?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredTeachers(filtered);
  };

  const handleTeacherSelect = (teacher: Teacher) => {
    setSelectedTeacher(teacher);
    onTeacherSelect(teacher);
    setOpen(false);
  };

  const getInitials = (name: string) => {
    if (!name) return 'NA';
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const parseSpecialties = (specialties: string | undefined) => {
    if (!specialties) return [];
    try {
      return JSON.parse(specialties);
    } catch {
      return specialties.split(',').map(s => s.trim()).filter(Boolean);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center space-x-2">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
        <span className="text-sm text-gray-600">Loading teachers...</span>
      </div>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button 
            variant="outline" 
            className="w-full justify-start"
            disabled={disabled}
          >
            {selectedTeacher ? (
              <div className="flex items-center space-x-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={selectedTeacher.avatar} />
                  <AvatarFallback className="text-xs">
                    {getInitials(selectedTeacher.name)}
                  </AvatarFallback>
                </Avatar>
                <span className="truncate">{selectedTeacher.name}</span>
              </div>
            ) : (
              <span>Select Teacher</span>
            )}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Select Teacher</DialogTitle>
          <DialogDescription>
            Choose a teacher to assign to this course
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <Label htmlFor="search">Search Teachers</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="search"
                  placeholder="Search by name, email, or department..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="w-full sm:w-48">
              <Label>Quick Filters</Label>
              <div className="flex flex-wrap gap-1">
                <Button
                  variant={searchTerm === '' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSearchTerm('')}
                >
                  All
                </Button>
                {teachers
                  .filter(t => t.teacherProfile?.department)
                  .map((teacher, index) => (
                    <Button
                      key={`filter-${index}`}
                      variant={searchTerm === teacher.teacherProfile?.department ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSearchTerm(teacher.teacherProfile?.department || '')}
                    >
                      {teacher.teacherProfile?.department}
                    </Button>
                  ))
                  .slice(0, 3)}
              </div>
            </div>
          </div>

          {/* Teachers List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTeachers.map((teacher) => (
              <Card 
                key={teacher.id} 
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedTeacher?.id === teacher.id 
                    ? 'ring-2 ring-primary bg-primary/5' 
                    : ''
                }`}
                onClick={() => handleTeacherSelect(teacher)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start space-x-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={teacher.avatar} />
                      <AvatarFallback>
                        {getInitials(teacher.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg truncate">{teacher.name}</CardTitle>
                      <CardDescription className="truncate">{teacher.email}</CardDescription>
                      {teacher.teacherProfile?.department && (
                        <Badge variant="secondary" className="mt-1">
                          {teacher.teacherProfile.department}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    {/* Rating */}
                    {teacher.teacherProfile?.rating && (
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium ml-1">
                            {teacher.teacherProfile.rating.toFixed(1)}
                          </span>
                        </div>
                        <span className="text-sm text-gray-500">
                          ({teacher.teacherProfile.totalReviews} reviews)
                        </span>
                      </div>
                    )}

                    {/* Experience */}
                    {teacher.teacherProfile?.experience && (
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <BookOpen className="h-4 w-4" />
                        <span>{teacher.teacherProfile.experience} years experience</span>
                      </div>
                    )}

                    {/* Courses */}
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Award className="h-4 w-4" />
                      <span>{teacher._count.createdCourses} active courses</span>
                    </div>

                    {/* Specialties */}
                    {teacher.teacherProfile?.specialties && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {parseSpecialties(teacher.teacherProfile.specialties)
                          .slice(0, 3)
                          .map((specialty: string, index: number) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {specialty}
                            </Badge>
                          ))}
                        {parseSpecialties(teacher.teacherProfile.specialties).length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{parseSpecialties(teacher.teacherProfile.specialties).length - 3} more
                          </Badge>
                        )}
                      </div>
                    )}

                    {/* Bio */}
                    {teacher.teacherProfile?.bio && (
                      <p className="text-sm text-gray-600 line-clamp-2 mt-2">
                        {teacher.teacherProfile.bio}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredTeachers.length === 0 && (
            <div className="text-center py-8">
              <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No teachers found</h3>
              <p className="text-gray-500">
                Try adjusting your search or filters to find available teachers.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}