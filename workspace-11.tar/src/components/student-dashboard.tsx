'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, BrainCircuit, Award, Clock, Users, Calendar, TrendingUp, Video } from 'lucide-react';
import { StudentCourseView } from './student-course-view';
import { StudentOnlineClasses } from './student-online-classes';
import { ClassNotifications } from './class-notifications';

interface Course {
  id: string;
  title: string;
  description: string;
  code: string;
  credits: number;
  duration: number;
  level: string;
  category: string;
  teacher: {
    id: string;
    name: string;
    email: string;
  };
  enrollment?: {
    id: string;
    progress: number;
    enrolledAt: string;
    status: string;
  };
  _count: {
    tests: number;
  };
}

interface Test {
  id: string;
  title: string;
  description: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  startTime: string;
  endTime: string;
  course: {
    title: string;
    code: string;
  };
  submission?: {
    id: string;
    status: string;
    marks: number;
    submittedAt: string;
  };
}

interface Grade {
  id: string;
  assignmentName: string;
  marks: number;
  totalMarks: number;
  percentage: number;
  grade: string;
  feedback: string;
  gradedAt: string;
  course?: {
    title: string;
    code: string;
  };
}

export function StudentDashboard() {
  const { user, token, logout } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [availableCourses, setAvailableCourses] = useState<Course[]>([]);
  const [tests, setTests] = useState<Test[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCourseView, setShowCourseView] = useState(false);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);

  useEffect(() => {
    if (user?.id) {
      fetchStudentData();
    }
  }, [user]);

  const fetchStudentData = async () => {
    if (!user?.id) return;
    
    try {
      setLoading(true);
      const headers = {
        'Authorization': `Bearer ${token}`,
      };

      // Fetch all data in parallel
      const [coursesResponse, availableResponse, testsResponse, gradesResponse] = await Promise.all([
        fetch(`/api/courses?studentId=${user.id}`, { headers }),
        fetch('/api/courses', { headers }),
        fetch(`/api/tests?studentId=${user.id}`, { headers }),
        fetch(`/api/grades?studentId=${user.id}`, { headers })
      ]);

      // Process enrolled courses
      let enrolledCourses: Course[] = [];
      if (coursesResponse.ok) {
        try {
          const coursesData = await coursesResponse.json();
          console.log('Enrolled courses response:', coursesData);
          enrolledCourses = Array.isArray(coursesData) ? coursesData : coursesData.courses || [];
          console.log('Setting enrolled courses:', enrolledCourses);
          setCourses(enrolledCourses);
        } catch (error) {
          console.error('Error processing enrolled courses:', error);
          enrolledCourses = [];
          setCourses([]);
        }
      }

      // Process available courses
      if (availableResponse.ok) {
        try {
          const availableData = await availableResponse.json();
          console.log('Available courses response:', availableData);
          const availableCoursesArray = Array.isArray(availableData) ? availableData : availableData.courses || [];
          const enrolledCoursesIds = enrolledCourses.map((course: Course) => course.id);
          const filteredCourses = availableCoursesArray.filter((course: Course) => 
            course && course.id && !enrolledCoursesIds.includes(course.id)
          );
          console.log('Setting available courses:', filteredCourses);
          setAvailableCourses(filteredCourses);
        } catch (error) {
          console.error('Error processing available courses:', error);
          setAvailableCourses([]);
        }
      }

      // Process tests
      if (testsResponse.ok) {
        try {
          const testsData = await testsResponse.json();
          const testsArray = Array.isArray(testsData) ? testsData : testsData.tests || [];
          console.log('Setting tests:', testsArray);
          setTests(testsArray);
        } catch (error) {
          console.error('Error processing tests:', error);
          setTests([]);
        }
      }

      // Process grades
      if (gradesResponse.ok) {
        try {
          const gradesData = await gradesResponse.json();
          const gradesArray = Array.isArray(gradesData) ? gradesData : gradesData.grades || [];
          console.log('Setting grades:', gradesArray);
          setGrades(gradesArray);
        } catch (error) {
          console.error('Error processing grades:', error);
          setGrades([]);
        }
      }
    } catch (error) {
      console.error('Error fetching student data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEnroll = async (courseId: string) => {
    if (!user?.id) return;
    
    try {
      const response = await fetch('/api/courses/enroll', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          studentId: user.id,
          courseId,
        }),
      });

      if (response.ok) {
        fetchStudentData(); // Refresh data
      }
    } catch (error) {
      console.error('Error enrolling in course:', error);
    }
  };

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'bg-green-100 text-green-800';
      case 'B': return 'bg-blue-100 text-blue-800';
      case 'C': return 'bg-yellow-100 text-yellow-800';
      case 'D': return 'bg-orange-100 text-orange-800';
      case 'F': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (showCourseView && selectedCourseId) {
    return (
      <StudentCourseView 
        courseId={selectedCourseId}
        onBack={() => {
          setShowCourseView(false);
          setSelectedCourseId(null);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Navigation Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={() => window.location.href = '/'}>
              <BookOpen className="w-4 h-4 mr-2" />
              Home
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Welcome back, {user?.name}!
              </h1>
              <p className="text-gray-600">
                Track your learning progress and manage your courses
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ClassNotifications />
            <Button variant="outline" onClick={logout}>
              Logout
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Enrolled Courses</p>
                  <p className="text-2xl font-bold text-gray-900">{courses.length}</p>
                </div>
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Tests</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {tests.filter(t => !t.submission).length}
                  </p>
                </div>
                <BrainCircuit className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Completed Tests</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {tests.filter(t => t.submission).length}
                  </p>
                </div>
                <Award className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Average Grade</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {grades.length > 0 
                      ? (grades.reduce((acc, g) => acc + g.percentage, 0) / grades.length).toFixed(1) + '%'
                      : 'N/A'
                    }
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="courses">My Courses</TabsTrigger>
            <TabsTrigger value="available">Available Courses</TabsTrigger>
            <TabsTrigger value="online-classes">Online Classes</TabsTrigger>
            <TabsTrigger value="tests">Tests</TabsTrigger>
            <TabsTrigger value="grades">Grades</TabsTrigger>
          </TabsList>

          {/* My Courses */}
          <TabsContent value="courses">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : courses.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">You haven't enrolled in any courses yet.</p>
                <Button 
                  className="mt-4" 
                  onClick={() => window.location.hash = 'available'}
                >
                  Browse Available Courses
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {courses.map((course) => (
                <Card key={course.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        <CardDescription>{course.code}</CardDescription>
                      </div>
                      <Badge variant="secondary">{course.level}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{course.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Instructor:</span>
                        <span className="font-medium">{course.teacher.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Credits:</span>
                        <span className="font-medium">{course.credits}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Tests:</span>
                        <span className="font-medium">{course._count.tests}</span>
                      </div>
                    </div>
                    {course.enrollment && (
                      <div className="mt-4">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span>{course.enrollment.progress}%</span>
                        </div>
                        <Progress value={course.enrollment.progress} className="h-2" />
                      </div>
                    )}
                    <Button className="w-full mt-4" variant="outline"
                            onClick={() => {
                              setSelectedCourseId(course.id);
                              setShowCourseView(true);
                            }}>
                      View Course
                    </Button>
                  </CardContent>
                </Card>
              ))}
              </div>
            )}
          </TabsContent>

          {/* Available Courses */}
          <TabsContent value="available">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : availableCourses.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">No available courses at the moment.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {availableCourses.map((course) => (
                <Card key={course.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        <CardDescription>{course.code}</CardDescription>
                      </div>
                      <Badge variant="secondary">{course.level}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{course.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Instructor:</span>
                        <span className="font-medium">{course.teacher.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Credits:</span>
                        <span className="font-medium">{course.credits}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">{course.duration} weeks</span>
                      </div>
                    </div>
                    <Button 
                      className="w-full mt-4" 
                      onClick={() => handleEnroll(course.id)}
                    >
                      Enroll Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
              </div>
            )}
          </TabsContent>

          {/* Online Classes */}
          <TabsContent value="online-classes">
            <StudentOnlineClasses />
          </TabsContent>

          {/* Tests */}
          <TabsContent value="tests">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : tests.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">No tests available.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tests.map((test) => (
                <Card key={test.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{test.title}</CardTitle>
                        <CardDescription>{test.course.title}</CardDescription>
                      </div>
                      <Badge variant={test.submission ? "secondary" : "default"}>
                        {test.submission ? "Completed" : "Pending"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{test.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">{test.duration} minutes</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Marks:</span>
                        <span className="font-medium">{test.totalMarks}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Passing Marks:</span>
                        <span className="font-medium">{test.passingMarks}</span>
                      </div>
                      {test.submission && (
                        <>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Your Score:</span>
                            <span className="font-medium">{test.submission.marks}/{test.totalMarks}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Submitted:</span>
                            <span className="font-medium">
                              {new Date(test.submission.submittedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </>
                      )}
                    </div>
                    <Button 
                      className="w-full mt-4" 
                      variant={test.submission ? "outline" : "default"}
                      disabled={test.submission !== undefined}
                    >
                      {test.submission ? "View Results" : "Start Test"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
              </div>
            )}
          </TabsContent>

          {/* Grades */}
          <TabsContent value="grades">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : grades.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">No grades available yet.</p>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Assignment/Test
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Course
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Score
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Grade
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {grades.map((grade) => (
                      <tr key={grade.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {grade.assignmentName}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {grade.course?.title || 'N/A'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {grade.marks}/{grade.totalMarks}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge className={getGradeColor(grade.grade || '')}>
                            {grade.grade || 'N/A'}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(grade.gradedAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}