'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackButton } from '@/components/ui/back-button';
import { 
  Users, 
  Search, 
  Mail, 
  Phone, 
  Calendar, 
  Award, 
  BookOpen,
  Building,
  Star,
  UserCheck,
  UserPlus,
  Filter
} from 'lucide-react';

interface TeacherProfile {
  id: string;
  userId: string;
  employeeId?: string;
  department?: string;
  qualification?: string;
  experience?: number;
  bio?: string;
  rating?: number;
  user: {
    id: string;
    name: string | null;
    email: string;
    avatar?: string | null;
    phone?: string | null;
    createdAt: string;
  };
  _count: {
    courses: number;
  };
}

interface TeacherManagementProps {
  onBack: () => void;
}

export function TeacherManagement({ onBack }: TeacherManagementProps) {
  const [teachers, setTeachers] = useState<TeacherProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTeacher, setSelectedTeacher] = useState<TeacherProfile | null>(null);
  const [filterDepartment, setFilterDepartment] = useState('');

  useEffect(() => {
    fetchTeachers();
  }, []);

  const fetchTeachers = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/admin/users?role=TEACHER', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setTeachers(data.users || []);
      }
    } catch (error) {
      console.error('Error fetching teachers:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredTeachers = teachers.filter(teacher => {
    const matchesSearch = !searchTerm || 
      teacher.user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.employeeId?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = !filterDepartment || 
      teacher.department === filterDepartment;
    
    return matchesSearch && matchesDepartment;
  });

  const departments = [...new Set(teachers.map(t => t.department).filter(Boolean))];

  const getInitials = (name: string | null) => {
    if (!name) return 'NA';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getRatingStars = (rating?: number) => {
    if (!rating) return 'Not rated';
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating) 
            ? 'text-yellow-400 fill-current' 
            : 'text-gray-300'
        }`}
      />
    ));
  };

  if (selectedTeacher) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
        <div className="max-w-6xl mx-auto">
          <BackButton onClick={() => setSelectedTeacher(null)} />
          
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center space-x-6">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={selectedTeacher.user.avatar || ''} />
                  <AvatarFallback className="text-2xl">
                    {getInitials(selectedTeacher.user.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <CardTitle className="text-3xl mb-2">
                    {selectedTeacher.user.name || 'Unknown Teacher'}
                  </CardTitle>
                  <CardDescription className="text-lg">
                    {selectedTeacher.department || 'No department assigned'}
                  </CardDescription>
                  <div className="flex items-center space-x-4 mt-3">
                    <Badge variant="secondary" className="text-sm">
                      {selectedTeacher.employeeId || 'No Employee ID'}
                    </Badge>
                    <div className="flex items-center space-x-1">
                      {getRatingStars(selectedTeacher.rating)}
                      {selectedTeacher.rating && (
                        <span className="text-sm text-gray-600 ml-2">
                          ({selectedTeacher.rating.toFixed(1)})
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="courses">Courses</TabsTrigger>
                  <TabsTrigger value="performance">Performance</TabsTrigger>
                  <TabsTrigger value="contact">Contact</TabsTrigger>
                </TabsList>
                
                <TabsContent value="overview" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <UserCheck className="h-5 w-5 mr-2" />
                          Professional Information
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <label className="text-sm font-medium text-gray-500">Qualification</label>
                          <p className="text-lg">
                            {selectedTeacher.qualification || 'Not specified'}
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-500">Experience</label>
                          <p className="text-lg">
                            {selectedTeacher.experience 
                              ? `${selectedTeacher.experience} years` 
                              : 'Not specified'}
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-500">Department</label>
                          <p className="text-lg">
                            {selectedTeacher.department || 'Not assigned'}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <BookOpen className="h-5 w-5 mr-2" />
                          Teaching Statistics
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <label className="text-sm font-medium text-gray-500">Active Courses</label>
                          <p className="text-2xl font-bold text-blue-600">
                            {selectedTeacher._count.courses}
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-500">Teacher Since</label>
                          <p className="text-lg">
                            {new Date(selectedTeacher.user.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {selectedTeacher.bio && (
                    <Card>
                      <CardHeader>
                        <CardTitle>About</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-700 leading-relaxed">
                          {selectedTeacher.bio}
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
                
                <TabsContent value="courses">
                  <Card>
                    <CardHeader>
                      <CardTitle>Assigned Courses</CardTitle>
                      <CardDescription>
                        Courses currently taught by this teacher
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-500">
                        Course details will be available when course management is implemented.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="performance">
                  <Card>
                    <CardHeader>
                      <CardTitle>Performance Metrics</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-500">
                        Performance analytics will be available in the next update.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="contact">
                  <Card>
                    <CardHeader>
                      <CardTitle>Contact Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <Mail className="h-5 w-5 text-gray-400" />
                        <div>
                          <label className="text-sm font-medium text-gray-500">Email</label>
                          <p className="text-lg">{selectedTeacher.user.email}</p>
                        </div>
                      </div>
                      {selectedTeacher.user.phone && (
                        <div className="flex items-center space-x-3">
                          <Phone className="h-5 w-5 text-gray-400" />
                          <div>
                            <label className="text-sm font-medium text-gray-500">Phone</label>
                            <p className="text-lg">{selectedTeacher.user.phone}</p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <BackButton onClick={onBack} />
        
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Teacher Management</h1>
            <p className="text-gray-600 mt-1">View and manage teacher profiles</p>
          </div>
          <Button>
            <UserPlus className="h-4 w-4 mr-2" />
            Add Teacher
          </Button>
        </div>

        {/* Search and Filter */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search by name, email, or employee ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <select
                  value={filterDepartment}
                  onChange={(e) => setFilterDepartment(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Departments</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Teachers Grid */}
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTeachers.map((teacher) => (
              <Card 
                key={teacher.id} 
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedTeacher(teacher)}
              >
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={teacher.user.avatar || ''} />
                      <AvatarFallback className="text-lg">
                        {getInitials(teacher.user.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <CardTitle className="text-lg">
                        {teacher.user.name || 'Unknown Teacher'}
                      </CardTitle>
                      <CardDescription>
                        {teacher.department || 'No department'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Employee ID</span>
                      <Badge variant="secondary" className="text-xs">
                        {teacher.employeeId || 'N/A'}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Courses</span>
                      <span className="font-medium">{teacher._count.courses}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Rating</span>
                      <div className="flex items-center space-x-1">
                        {teacher.rating ? (
                          <>
                            <div className="flex">
                              {getRatingStars(teacher.rating)}
                            </div>
                            <span className="text-xs text-gray-600">
                              ({teacher.rating.toFixed(1)})
                            </span>
                          </>
                        ) : (
                          <span className="text-xs text-gray-500">Not rated</span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Experience</span>
                      <span className="text-sm">
                        {teacher.experience 
                          ? `${teacher.experience} years` 
                          : 'Not specified'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t">
                    <div className="flex items-center text-sm text-gray-500">
                      <Mail className="h-4 w-4 mr-2" />
                      {teacher.user.email}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && filteredTeachers.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No teachers found
              </h3>
              <p className="text-gray-500">
                {searchTerm || filterDepartment 
                  ? 'Try adjusting your search or filters' 
                  : 'No teachers have been added yet'}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}