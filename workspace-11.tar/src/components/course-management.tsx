'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BookOpen, Plus, Edit, Trash2, Users, FileText, Settings, ArrowLeft, User, Star } from 'lucide-react';
import { TeacherSelector } from '@/components/teachers/teacher-selector';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { CourseCreation } from '@/components/courses/course-creation';

interface Course {
  id: string;
  title: string;
  description: string;
  code: string;
  credits: number;
  duration: number;
  level: string;
  price: number;
  language: string;
  thumbnail?: string;
  averageRating: number;
  totalStudents: number;
  totalTests: number;
  totalReviews: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  teacher: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
    teacherProfile?: {
      department: string;
      experience: number;
      rating: number;
    };
  };
  category?: {
    id: string;
    name: string;
    color?: string;
  };
}

interface CourseMaterial {
  id: string;
  title: string;
  type: string;
  content: string;
  order: number;
  isRequired: boolean;
  createdAt: string;
}

interface Student {
  id: string;
  name: string;
  email: string;
  studentProfile: {
    studentId: string;
    grade: string;
    section: string;
  };
  enrollment: {
    progress: number;
    enrolledAt: string;
    status: string;
  };
}

interface CourseManagementProps {
  courseId?: string;
  onBack: () => void;
}

export function CourseManagement({ courseId, onBack }: CourseManagementProps) {
  const { user, token, logout } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [materials, setMaterials] = useState<CourseMaterial[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAddMaterial, setShowAddMaterial] = useState(false);

  const [editForm, setEditForm] = useState({
    title: '',
    description: '',
    code: '',
    credits: 3,
    duration: 12,
    level: 'BEGINNER',
    category: '',
    teacherId: ''
  });

  const [newMaterial, setNewMaterial] = useState({
    title: '',
    type: 'DOCUMENT',
    content: '',
    order: 0,
    isRequired: false
  });

  useEffect(() => {
    fetchCourses();
    if (courseId) {
      fetchCourseDetails(courseId);
    }
  }, [courseId]);

  const fetchCourses = async () => {
    try {
      const response = await fetch(`/api/courses?teacherId=${user.id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setCourses(data.courses || []);
      }
    } catch (error) {
      console.error('Error fetching courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCourseDetails = async (id: string) => {
    try {
      // Fetch course details
      const courseResponse = await fetch(`/api/courses/${id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (courseResponse.ok) {
        const courseData = await courseResponse.json();
        setSelectedCourse(courseData);
        setEditForm({
          title: courseData.title,
          description: courseData.description,
          code: courseData.code,
          credits: courseData.credits,
          duration: courseData.duration,
          level: courseData.level,
          category: courseData.category?.name || '',
          teacherId: courseData.teacherId
        });
      }

      // Fetch materials
      const materialsResponse = await fetch(`/api/courses/${id}/materials`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (materialsResponse.ok) {
        const materialsData = await materialsResponse.json();
        setMaterials(materialsData);
      }

      // Fetch students
      const studentsResponse = await fetch(`/api/courses/${id}/students`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (studentsResponse.ok) {
        const studentsData = await studentsResponse.json();
        setStudents(studentsData);
      }
    } catch (error) {
      console.error('Error fetching course details:', error);
    }
  };

  const handleUpdateCourse = async () => {
    if (!selectedCourse) return;
    
    try {
      const response = await fetch(`/api/courses/${selectedCourse.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(editForm)
      });

      if (response.ok) {
        setShowEditDialog(false);
        fetchCourses();
        fetchCourseDetails(selectedCourse.id);
      }
    } catch (error) {
      console.error('Error updating course:', error);
    }
  };

  const handleAddMaterial = async () => {
    if (!selectedCourse) return;
    
    try {
      const response = await fetch(`/api/courses/${selectedCourse.id}/materials`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newMaterial)
      });

      if (response.ok) {
        setShowAddMaterial(false);
        setNewMaterial({
          title: '',
          type: 'DOCUMENT',
          content: '',
          order: 0,
          isRequired: false
        });
        fetchCourseDetails(selectedCourse.id);
      }
    } catch (error) {
      console.error('Error adding material:', error);
    }
  };

  const handleDeleteMaterial = async (materialId: string) => {
    if (!selectedCourse) return;
    
    try {
      const response = await fetch(`/api/courses/${selectedCourse.id}/materials/${materialId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (response.ok) {
        fetchCourseDetails(selectedCourse.id);
      }
    } catch (error) {
      console.error('Error deleting material:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!selectedCourse) {
    // Course list view
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Button variant="outline" onClick={onBack} className="mr-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-3xl font-bold">Course Management</h1>
            </div>
            <div className="flex gap-2">
              <CourseCreation onCourseCreated={fetchCourses} />
              <Button variant="outline" onClick={logout}>
                Logout
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <Card key={course.id} className="hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => setSelectedCourse(course)}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{course.title}</CardTitle>
                      <CardDescription>{course.code}</CardDescription>
                    </div>
                    <Badge variant={course.isActive ? "default" : "secondary"}>
                      {course.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  
                  {/* Teacher Information */}
                  <div className="flex items-center space-x-3 mt-3 p-2 bg-gray-50 rounded-lg">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={course.teacher.avatar} />
                      <AvatarFallback>
                        {course.teacher.name ? 
                          course.teacher.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 
                          'NA'
                        }
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <p className="text-sm font-medium truncate">{course.teacher.name}</p>
                        {course.teacher.teacherProfile?.rating && (
                          <div className="flex items-center">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs ml-1">
                              {course.teacher.teacherProfile.rating.toFixed(1)}
                            </span>
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 truncate">
                        {course.teacher.teacherProfile?.department || 'No department'}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">{course.description}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Students:</span>
                      <span className="font-medium">{course.totalStudents}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tests:</span>
                      <span className="font-medium">{course.totalTests}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Credits:</span>
                      <span className="font-medium">{course.credits}</span>
                    </div>
                  </div>
                  <Button className="w-full mt-4">
                    Manage Course
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Single course management view
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button variant="outline" onClick={() => setSelectedCourse(null)} className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Courses
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{selectedCourse.title}</h1>
              <p className="text-gray-600">{selectedCourse.code}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Course
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Edit Course</DialogTitle>
                  <DialogDescription>
                    Update course information
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Course Title</Label>
                    <Input
                      id="title"
                      value={editForm.title}
                      onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={editForm.description}
                      onChange={(e) => setEditForm({...editForm, description: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="credits">Credits</Label>
                      <Input
                        id="credits"
                        type="number"
                        value={editForm.credits}
                        onChange={(e) => setEditForm({...editForm, credits: parseInt(e.target.value)})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="duration">Duration (weeks)</Label>
                      <Input
                        id="duration"
                        type="number"
                        value={editForm.duration}
                        onChange={(e) => setEditForm({...editForm, duration: parseInt(e.target.value)})}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="teacher">Course Instructor</Label>
                    <TeacherSelector
                      selectedTeacherId={editForm.teacherId}
                      onTeacherSelect={(teacher) => setEditForm({...editForm, teacherId: teacher.id})}
                      trigger={
                        <Button variant="outline" className="w-full justify-start">
                          {editForm.teacherId ? (
                            <div className="flex items-center space-x-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={selectedCourse?.teacher.avatar} />
                                <AvatarFallback className="text-xs">
                                  {selectedCourse?.teacher.name ? 
                                    selectedCourse.teacher.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 
                                    'NA'
                                  }
                                </AvatarFallback>
                              </Avatar>
                              <span className="truncate">{selectedCourse?.teacher.name}</span>
                            </div>
                          ) : (
                            <span>Select Teacher</span>
                          )}
                        </Button>
                      }
                    />
                  </div>
                  <Button onClick={handleUpdateCourse} className="w-full">
                    Update Course
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="students">Students</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Students
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{selectedCourse.totalStudents}</div>
                  <p className="text-gray-600">Enrolled students</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    Materials
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{materials.length}</div>
                  <p className="text-gray-600">Course materials</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="w-5 h-5 mr-2" />
                    Tests
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{selectedCourse.totalTests}</div>
                  <p className="text-gray-600">Created tests</p>
                </CardContent>
              </Card>
            </div>

            {/* Teacher Information Card */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="w-5 h-5 mr-2" />
                  Course Instructor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start space-x-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={selectedCourse.teacher.avatar} />
                    <AvatarFallback className="text-lg">
                      {selectedCourse.teacher.name ? 
                        selectedCourse.teacher.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 
                        'NA'
                      }
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold">{selectedCourse.teacher.name}</h3>
                      {selectedCourse.teacher.teacherProfile?.rating && (
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium ml-1">
                            {selectedCourse.teacher.teacherProfile.rating.toFixed(1)}
                          </span>
                          <span className="text-sm text-gray-500 ml-1">
                            ({selectedCourse.teacher.teacherProfile.totalReviews} reviews)
                          </span>
                        </div>
                      )}
                    </div>
                    <p className="text-gray-600 mb-3">{selectedCourse.teacher.email}</p>
                    
                    {selectedCourse.teacher.teacherProfile && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        {selectedCourse.teacher.teacherProfile.department && (
                          <div>
                            <Label>Department</Label>
                            <p className="font-medium">{selectedCourse.teacher.teacherProfile.department}</p>
                          </div>
                        )}
                        {selectedCourse.teacher.teacherProfile.qualification && (
                          <div>
                            <Label>Qualification</Label>
                            <p className="font-medium">{selectedCourse.teacher.teacherProfile.qualification}</p>
                          </div>
                        )}
                        {selectedCourse.teacher.teacherProfile.experience && (
                          <div>
                            <Label>Experience</Label>
                            <p className="font-medium">{selectedCourse.teacher.teacherProfile.experience} years</p>
                          </div>
                        )}
                        {selectedCourse.teacher.teacherProfile.employeeId && (
                          <div>
                            <Label>Employee ID</Label>
                            <p className="font-medium">{selectedCourse.teacher.teacherProfile.employeeId}</p>
                          </div>
                        )}
                      </div>
                    )}
                    
                    {selectedCourse.teacher.teacherProfile?.bio && (
                      <div className="mt-4">
                        <Label>About</Label>
                        <p className="text-gray-600 text-sm mt-1">{selectedCourse.teacher.teacherProfile.bio}</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Course Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Level</Label>
                    <p className="font-medium">{selectedCourse.level}</p>
                  </div>
                  <div>
                    <Label>Category</Label>
                    <p className="font-medium">{selectedCourse.category?.name || 'Uncategorized'}</p>
                  </div>
                  <div>
                    <Label>Credits</Label>
                    <p className="font-medium">{selectedCourse.credits}</p>
                  </div>
                  <div>
                    <Label>Duration</Label>
                    <p className="font-medium">{selectedCourse.duration} weeks</p>
                  </div>
                </div>
                <div className="mt-4">
                  <Label>Description</Label>
                  <p className="text-gray-600">{selectedCourse.description}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="materials">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Course Materials</h2>
              <Dialog open={showAddMaterial} onOpenChange={setShowAddMaterial}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Material
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Course Material</DialogTitle>
                    <DialogDescription>
                      Add new material to your course
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="material-title">Title</Label>
                      <Input
                        id="material-title"
                        value={newMaterial.title}
                        onChange={(e) => setNewMaterial({...newMaterial, title: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="material-type">Type</Label>
                      <Select value={newMaterial.type} onValueChange={(value) => setNewMaterial({...newMaterial, type: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="VIDEO">Video</SelectItem>
                          <SelectItem value="DOCUMENT">Document</SelectItem>
                          <SelectItem value="LINK">Link</SelectItem>
                          <SelectItem value="ASSIGNMENT">Assignment</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="material-content">Content/URL</Label>
                      <Textarea
                        id="material-content"
                        value={newMaterial.content}
                        onChange={(e) => setNewMaterial({...newMaterial, content: e.target.value})}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="material-order">Order</Label>
                        <Input
                          id="material-order"
                          type="number"
                          value={newMaterial.order}
                          onChange={(e) => setNewMaterial({...newMaterial, order: parseInt(e.target.value)})}
                        />
                      </div>
                      <div className="flex items-center space-x-2 mt-6">
                        <input
                          type="checkbox"
                          id="material-required"
                          checked={newMaterial.isRequired}
                          onChange={(e) => setNewMaterial({...newMaterial, isRequired: e.target.checked})}
                        />
                        <Label htmlFor="material-required">Required</Label>
                      </div>
                    </div>
                    <Button onClick={handleAddMaterial} className="w-full">
                      Add Material
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="space-y-4">
              {materials.map((material) => (
                <Card key={material.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{material.title}</h3>
                        <p className="text-sm text-gray-600">{material.type}</p>
                        {material.isRequired && (
                          <Badge variant="destructive" className="mt-1">Required</Badge>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="destructive" 
                                onClick={() => handleDeleteMaterial(material.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="students">
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Student ID</TableHead>
                    <TableHead>Grade/Section</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Enrolled</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{student.name}</div>
                          <div className="text-sm text-gray-500">{student.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>{student.studentProfile?.studentId}</TableCell>
                      <TableCell>
                        {student.studentProfile?.grade}/{student.studentProfile?.section}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{width: `${student.enrollment.progress}%`}}
                            ></div>
                          </div>
                          <span className="text-sm">{student.enrollment.progress}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(student.enrollment.enrolledAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Course Settings</CardTitle>
                <CardDescription>
                  Manage course settings and preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Course Status</h3>
                      <p className="text-sm text-gray-600">
                        {selectedCourse.isActive ? 'Course is active and visible to students' : 'Course is inactive'}
                      </p>
                    </div>
                    <Button variant={selectedCourse.isActive ? "destructive" : "default"}>
                      {selectedCourse.isActive ? 'Deactivate' : 'Activate'}
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Enrollment</h3>
                      <p className="text-sm text-gray-600">Allow students to enroll in this course</p>
                    </div>
                    <Button variant="outline">Manage Enrollment</Button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Delete Course</h3>
                      <p className="text-sm text-gray-600">Permanently delete this course and all its data</p>
                    </div>
                    <Button variant="destructive">Delete Course</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}