'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Users, Video, ExternalLink, User } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';

interface OnlineClass {
  id: string;
  title: string;
  description?: string;
  courseId: string;
  teacherId: string;
  startTime: string;
  endTime: string;
  meetingLink?: string;
  meetingId?: string;
  meetingPassword?: string;
  platform?: string;
  status: string;
  course: {
    id: string;
    title: string;
    code: string;
  };
  teacher: {
    id: string;
    name: string;
    email: string;
  };
  participants: Array<{
    id: string;
    studentId: string;
    joinedAt?: string;
    leftAt?: string;
    duration?: number;
    status: string;
    student: {
      id: string;
      name: string;
      email: string;
    };
  }>;
  _count: {
    participants: number;
  };
}

export function StudentOnlineClasses() {
  const { user } = useAuth();
  const [classes, setClasses] = useState<OnlineClass[]>([]);
  const [loading, setLoading] = useState(true);
  const [joiningClass, setJoiningClass] = useState<string | null>(null);

  useEffect(() => {
    if (user?.id) {
      fetchClasses();
    }
  }, [user]);

  const fetchClasses = async () => {
    try {
      const response = await fetch(`/api/online-classes?studentId=${user?.id}`);
      if (response.ok) {
        const data = await response.json();
        setClasses(data);
      }
    } catch (error) {
      console.error('Error fetching classes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinClass = async (classId: string) => {
    setJoiningClass(classId);
    
    try {
      const response = await fetch(`/api/online-classes/${classId}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: user?.id })
      });

      if (response.ok) {
        const data = await response.json();
        
        // Open meeting link in new window
        if (data.class.meetingLink) {
          window.open(data.class.meetingLink, '_blank');
        }
        
        // Refresh classes to update participant status
        fetchClasses();
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'Failed to join class');
      }
    } catch (error) {
      console.error('Error joining class:', error);
      alert('Failed to join class. Please try again.');
    } finally {
      setJoiningClass(null);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'SCHEDULED': return 'bg-blue-100 text-blue-800';
      case 'LIVE': return 'bg-green-100 text-green-800';
      case 'ENDED': return 'bg-gray-100 text-gray-800';
      case 'CANCELLED': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPlatformIcon = (platform?: string) => {
    switch (platform) {
      case 'ZOOM': return '🎥';
      case 'GOOGLE_MEET': return '📹';
      case 'TEAMS': return '💼';
      default: return '📺';
    }
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const canJoinClass = (startTime: string, endTime: string, status: string) => {
    const now = new Date();
    const start = new Date(startTime);
    const end = new Date(endTime);
    const timeDiff = start.getTime() - now.getTime();
    const minutesDiff = timeDiff / (1000 * 60);
    
    // Can join if class is live or starts within 15 minutes
    return (status === 'LIVE' || minutesDiff <= 15) && now <= end;
  };

  const isUserJoined = (participants: any[], userId: string) => {
    return participants.some(p => p.studentId === userId && p.status === 'JOINED');
  };

  const getTimeUntilClass = (startTime: string) => {
    const now = new Date();
    const start = new Date(startTime);
    const timeDiff = start.getTime() - now.getTime();
    
    if (timeDiff < 0) return 'Started';
    
    const hours = Math.floor(timeDiff / (1000 * 60 * 60));
    const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 24) {
      const days = Math.floor(hours / 24);
      return `${days} day${days > 1 ? 's' : ''}`;
    } else if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes} min`;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Separate classes into upcoming, live, and past
  const upcomingClasses = classes.filter(c => 
    new Date(c.startTime) > new Date() && c.status !== 'CANCELLED'
  );
  const liveClasses = classes.filter(c => 
    c.status === 'LIVE' || (new Date(c.startTime) <= new Date() && new Date(c.endTime) > new Date())
  );
  const pastClasses = classes.filter(c => 
    new Date(c.endTime) < new Date() || c.status === 'ENDED'
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Online Classes</h2>
        <p className="text-gray-600">Join your scheduled virtual classes</p>
      </div>

      {/* Live Classes */}
      {liveClasses.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-green-600 mb-4 flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            Live Now
          </h3>
          <div className="grid gap-4">
            {liveClasses.map((classItem) => (
              <Card key={classItem.id} className="border-green-200 bg-green-50">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getPlatformIcon(classItem.platform)}</span>
                        <CardTitle className="text-lg">{classItem.title}</CardTitle>
                        <Badge className="bg-green-100 text-green-800">
                          🔴 LIVE NOW
                        </Badge>
                      </div>
                      <CardDescription>
                        {classItem.course.title} ({classItem.course.code})
                      </CardDescription>
                    </div>
                    <Button
                      onClick={() => handleJoinClass(classItem.id)}
                      disabled={joiningClass === classItem.id || isUserJoined(classItem.participants, user?.id || '')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {joiningClass === classItem.id ? 'Joining...' : 
                       isUserJoined(classItem.participants, user?.id || '') ? 'Already Joined' : 
                       'Join Now'}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {classItem.description && (
                    <p className="text-sm text-gray-600">{classItem.description}</p>
                  )}
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4 text-gray-500" />
                      <span>{classItem.teacher.name}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span>{formatDateTime(classItem.startTime)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>Ends {formatDateTime(classItem.endTime)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4 text-gray-500" />
                      <span>{classItem._count.participants} joined</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Upcoming Classes */}
      {upcomingClasses.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-blue-600 mb-4">Upcoming Classes</h3>
          <div className="grid gap-4">
            {upcomingClasses.map((classItem) => (
              <Card key={classItem.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getPlatformIcon(classItem.platform)}</span>
                        <CardTitle className="text-lg">{classItem.title}</CardTitle>
                        <Badge className={getStatusColor(classItem.status)}>
                          {classItem.status}
                        </Badge>
                      </div>
                      <CardDescription>
                        {classItem.course.title} ({classItem.course.code})
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500 mb-2">
                        Starts in {getTimeUntilClass(classItem.startTime)}
                      </p>
                      <Button
                        onClick={() => handleJoinClass(classItem.id)}
                        disabled={!canJoinClass(classItem.startTime, classItem.endTime, classItem.status) || 
                                   joiningClass === classItem.id || 
                                   isUserJoined(classItem.participants, user?.id || '')}
                        variant={canJoinClass(classItem.startTime, classItem.endTime, classItem.status) ? "default" : "outline"}
                      >
                        {joiningClass === classItem.id ? 'Joining...' : 
                         isUserJoined(classItem.participants, user?.id || '') ? 'Joined' : 
                         canJoinClass(classItem.startTime, classItem.endTime, classItem.status) ? 'Join' : 
                         'Not Available'}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {classItem.description && (
                    <p className="text-sm text-gray-600">{classItem.description}</p>
                  )}
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4 text-gray-500" />
                      <span>{classItem.teacher.name}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span>{formatDateTime(classItem.startTime)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>{formatDateTime(classItem.endTime)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Video className="w-4 h-4 text-gray-500" />
                      <span>{classItem.platform}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Past Classes */}
      {pastClasses.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-600 mb-4">Past Classes</h3>
          <div className="grid gap-4">
            {pastClasses.map((classItem) => (
              <Card key={classItem.id} className="opacity-75">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-lg grayscale">{getPlatformIcon(classItem.platform)}</span>
                        <CardTitle className="text-lg">{classItem.title}</CardTitle>
                        <Badge className={getStatusColor(classItem.status)}>
                          {classItem.status}
                        </Badge>
                      </div>
                      <CardDescription>
                        {classItem.course.title} ({classItem.course.code})
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className="mb-2">
                        {isUserJoined(classItem.participants, user?.id || '') ? 'Attended' : 'Missed'}
                      </Badge>
                      {classItem.recordingUrl && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(classItem.recordingUrl, '_blank')}
                        >
                          <Video className="w-4 h-4 mr-1" />
                          Watch Recording
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4 text-gray-500" />
                      <span>{classItem.teacher.name}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span>{formatDateTime(classItem.startTime)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>{formatDateTime(classItem.endTime)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4 text-gray-500" />
                      <span>{classItem._count.participants} attended</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {classes.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Video className="w-16 h-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No online classes</h3>
            <p className="text-gray-500 text-center">
              You don't have any online classes scheduled yet.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}