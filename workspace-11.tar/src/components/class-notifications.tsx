'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, X, Clock, Video, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';

interface OnlineClass {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  meetingLink?: string;
  platform?: string;
  status: string;
  course: {
    title: string;
    code: string;
  };
  teacher: {
    name: string;
  };
}

interface ClassNotification {
  id: string;
  type: 'STARTING_SOON' | 'REMINDER' | 'CANCELLED' | 'RESCHEDULED';
  class: OnlineClass;
  message: string;
  timestamp: string;
  read: boolean;
}

export function ClassNotifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<ClassNotification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      fetchNotifications();
      // Check for upcoming classes every minute
      const interval = setInterval(() => {
        checkUpcomingClasses();
      }, 60000);
      
      return () => clearInterval(interval);
    }
  }, [user]);

  const fetchNotifications = async () => {
    try {
      // For now, we'll generate notifications client-side
      // In a real app, this would come from an API
      const response = await fetch(`/api/online-classes?studentId=${user?.id}`);
      if (response.ok) {
        const classes: OnlineClass[] = await response.json();
        const generatedNotifications = generateNotifications(classes);
        setNotifications(generatedNotifications);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkUpcomingClasses = async () => {
    try {
      const response = await fetch(`/api/online-classes?studentId=${user?.id}`);
      if (response.ok) {
        const classes: OnlineClass[] = await response.json();
        const newNotifications = generateNotifications(classes);
        
        // Check for new notifications
        const existingIds = notifications.map(n => n.id);
        const trulyNew = newNotifications.filter(n => !existingIds.includes(n.id));
        
        if (trulyNew.length > 0) {
          setNotifications(prev => [...trulyNew, ...prev]);
        }
      }
    } catch (error) {
      console.error('Error checking upcoming classes:', error);
    }
  };

  const generateNotifications = (classes: OnlineClass[]): ClassNotification[] => {
    const notifications: ClassNotification[] = [];
    const now = new Date();

    classes.forEach(classItem => {
      const startTime = new Date(classItem.startTime);
      const timeDiff = startTime.getTime() - now.getTime();
      const minutesDiff = timeDiff / (1000 * 60);

      // Class starting soon (within 15 minutes)
      if (minutesDiff > 0 && minutesDiff <= 15 && classItem.status === 'SCHEDULED') {
        notifications.push({
          id: `${classItem.id}-starting-soon`,
          type: 'STARTING_SOON',
          class: classItem,
          message: `Class "${classItem.title}" is starting in ${Math.ceil(minutesDiff)} minutes`,
          timestamp: new Date().toISOString(),
          read: false
        });
      }

      // Class reminder (1 hour before)
      if (minutesDiff > 15 && minutesDiff <= 60 && classItem.status === 'SCHEDULED') {
        notifications.push({
          id: `${classItem.id}-reminder`,
          type: 'REMINDER',
          class: classItem,
          message: `Reminder: Class "${classItem.title}" starts at ${startTime.toLocaleTimeString()}`,
          timestamp: new Date().toISOString(),
          read: false
        });
      }

      // Class cancelled
      if (classItem.status === 'CANCELLED') {
        notifications.push({
          id: `${classItem.id}-cancelled`,
          type: 'CANCELLED',
          class: classItem,
          message: `Class "${classItem.title}" has been cancelled`,
          timestamp: new Date().toISOString(),
          read: false
        });
      }
    });

    return notifications.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  };

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const deleteNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'STARTING_SOON': return <Video className="w-4 h-4 text-red-500" />;
      case 'REMINDER': return <Clock className="w-4 h-4 text-blue-500" />;
      case 'CANCELLED': return <X className="w-4 h-4 text-gray-500" />;
      default: return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'STARTING_SOON': return 'border-red-200 bg-red-50';
      case 'REMINDER': return 'border-blue-200 bg-blue-50';
      case 'CANCELLED': return 'border-gray-200 bg-gray-50';
      default: return 'border-gray-200 bg-white';
    }
  };

  if (loading) {
    return null;
  }

  return (
    <div className="relative">
      {/* Notification Bell */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => setShowNotifications(!showNotifications)}
        className="relative"
      >
        <Bell className="w-4 h-4" />
        {unreadCount > 0 && (
          <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </Button>

      {/* Notifications Dropdown */}
      {showNotifications && (
        <div className="absolute right-0 top-12 w-96 bg-white rounded-lg shadow-lg border z-50 max-h-96 overflow-hidden">
          <div className="p-4 border-b bg-gray-50">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Class Notifications</h3>
              <div className="flex gap-2">
                {unreadCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                    Mark all read
                  </Button>
                )}
                {notifications.length > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearAllNotifications}>
                    Clear all
                  </Button>
                )}
              </div>
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>No notifications</p>
              </div>
            ) : (
              <div className="divide-y">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 cursor-pointer transition-colors ${getNotificationColor(notification.type)} ${
                      !notification.read ? 'font-semibold' : ''
                    }`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        {getNotificationIcon(notification.type)}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">{notification.message}</p>
                          <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                            <Calendar className="w-3 h-3" />
                            <span>{notification.class.course.title}</span>
                            <span>•</span>
                            <span>{new Date(notification.timestamp).toLocaleTimeString()}</span>
                          </div>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteNotification(notification.id);
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}