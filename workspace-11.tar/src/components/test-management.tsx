'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BrainCircuit, Plus, Edit, Trash2, Users, Clock, ArrowLeft, Play, Eye, Award } from 'lucide-react';

interface Test {
  id: string;
  title: string;
  description: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  isPublished: boolean;
  startTime: string;
  endTime: string;
  course: {
    id: string;
    title: string;
    code: string;
  };
  _count: {
    questions: number;
    submissions: number;
  };
}

interface Question {
  id: string;
  question: string;
  type: 'MULTIPLE_CHOICE' | 'TRUE_FALSE' | 'SHORT_ANSWER' | 'ESSAY';
  options?: string[];
  correctAnswer?: string;
  marks: number;
  explanation?: string;
  order: number;
}

interface TestSubmission {
  id: string;
  student: {
    name: string;
    email: string;
    studentProfile?: {
      studentId: string;
    };
  };
  marks?: number;
  status: string;
  submittedAt?: string;
  gradedAt?: string;
}

interface TestManagementProps {
  testId?: string;
  onBack: () => void;
}

export function TestManagement({ testId, onBack }: TestManagementProps) {
  const { user, token, logout } = useAuth();
  const [tests, setTests] = useState<Test[]>([]);
  const [selectedTest, setSelectedTest] = useState<Test | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [submissions, setSubmissions] = useState<TestSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAddQuestion, setShowAddQuestion] = useState(false);

  const [editForm, setEditForm] = useState({
    title: '',
    description: '',
    duration: 60,
    totalMarks: 100,
    passingMarks: 60,
    startTime: '',
    endTime: ''
  });

  const [newQuestion, setNewQuestion] = useState({
    question: '',
    type: 'MULTIPLE_CHOICE' as const,
    options: [''],
    correctAnswer: '',
    marks: 1,
    explanation: '',
    order: 0
  });

  useEffect(() => {
    fetchTests();
    if (testId) {
      fetchTestDetails(testId);
    }
  }, [testId]);

  const fetchTests = async () => {
    try {
      const response = await fetch(`/api/tests?teacherId=${user.id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setTests(data);
      }
    } catch (error) {
      console.error('Error fetching tests:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTestDetails = async (id: string) => {
    try {
      // Fetch test details
      const testResponse = await fetch(`/api/tests/${id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (testResponse.ok) {
        const testData = await testResponse.json();
        setSelectedTest(testData);
        setEditForm({
          title: testData.title,
          description: testData.description,
          duration: testData.duration,
          totalMarks: testData.totalMarks,
          passingMarks: testData.passingMarks,
          startTime: testData.startTime ? new Date(testData.startTime).toISOString().slice(0, 16) : '',
          endTime: testData.endTime ? new Date(testData.endTime).toISOString().slice(0, 16) : ''
        });
      }

      // Fetch questions
      const questionsResponse = await fetch(`/api/questions?testId=${id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (questionsResponse.ok) {
        const questionsData = await questionsResponse.json();
        setQuestions(questionsData);
      }

      // Fetch submissions
      const submissionsResponse = await fetch(`/api/tests/${id}/submissions`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (submissionsResponse.ok) {
        const submissionsData = await submissionsResponse.json();
        setSubmissions(submissionsData);
      }
    } catch (error) {
      console.error('Error fetching test details:', error);
    }
  };

  const handleUpdateTest = async () => {
    if (!selectedTest) return;
    
    try {
      const response = await fetch(`/api/tests/${selectedTest.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(editForm)
      });

      if (response.ok) {
        setShowEditDialog(false);
        fetchTests();
        fetchTestDetails(selectedTest.id);
      }
    } catch (error) {
      console.error('Error updating test:', error);
    }
  };

  const handleAddQuestion = async () => {
    if (!selectedTest) return;
    
    try {
      const questionData = {
        ...newQuestion,
        options: newQuestion.type === 'MULTIPLE_CHOICE' ? newQuestion.options.filter(o => o.trim()) : null
      };

      const response = await fetch(`/api/questions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          testId: selectedTest.id,
          questions: [questionData]
        })
      });

      if (response.ok) {
        setShowAddQuestion(false);
        setNewQuestion({
          question: '',
          type: 'MULTIPLE_CHOICE',
          options: [''],
          correctAnswer: '',
          marks: 1,
          explanation: '',
          order: questions.length
        });
        fetchTestDetails(selectedTest.id);
      }
    } catch (error) {
      console.error('Error adding question:', error);
    }
  };

  const handleDeleteQuestion = async (questionId: string) => {
    if (!selectedTest) return;
    
    try {
      const response = await fetch(`/api/questions/${questionId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (response.ok) {
        fetchTestDetails(selectedTest.id);
      }
    } catch (error) {
      console.error('Error deleting question:', error);
    }
  };

  const handlePublishTest = async () => {
    if (!selectedTest) return;
    
    try {
      const response = await fetch(`/api/tests/${selectedTest.id}/publish`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (response.ok) {
        fetchTestDetails(selectedTest.id);
      }
    } catch (error) {
      console.error('Error publishing test:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!selectedTest) {
    // Test list view
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Button variant="outline" onClick={onBack} className="mr-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <h1 className="text-3xl font-bold">Test Management</h1>
            </div>
            <Button variant="outline" onClick={logout}>
              Logout
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {tests.map((test) => (
              <Card key={test.id} className="hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => setSelectedTest(test)}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{test.title}</CardTitle>
                      <CardDescription>{test.course.title} - {test.course.code}</CardDescription>
                    </div>
                    <Badge variant={test.isPublished ? "default" : "secondary"}>
                      {test.isPublished ? "Published" : "Draft"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">{test.description}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Duration:</span>
                      <span className="font-medium">{test.duration} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Questions:</span>
                      <span className="font-medium">{test._count.questions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Submissions:</span>
                      <span className="font-medium">{test._count.submissions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Marks:</span>
                      <span className="font-medium">{test.totalMarks}</span>
                    </div>
                  </div>
                  <Button className="w-full mt-4">
                    Manage Test
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Single test management view
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button variant="outline" onClick={() => setSelectedTest(null)} className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Tests
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{selectedTest.title}</h1>
              <p className="text-gray-600">{selectedTest.course.title} - {selectedTest.course.code}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Test
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Edit Test</DialogTitle>
                  <DialogDescription>
                    Update test information
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="test-title">Test Title</Label>
                    <Input
                      id="test-title"
                      value={editForm.title}
                      onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="test-description">Description</Label>
                    <Textarea
                      id="test-description"
                      value={editForm.description}
                      onChange={(e) => setEditForm({...editForm, description: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="duration">Duration (minutes)</Label>
                      <Input
                        id="duration"
                        type="number"
                        value={editForm.duration}
                        onChange={(e) => setEditForm({...editForm, duration: parseInt(e.target.value)})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="total-marks">Total Marks</Label>
                      <Input
                        id="total-marks"
                        type="number"
                        value={editForm.totalMarks}
                        onChange={(e) => setEditForm({...editForm, totalMarks: parseInt(e.target.value)})}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="passing-marks">Passing Marks</Label>
                    <Input
                      id="passing-marks"
                      type="number"
                      value={editForm.passingMarks}
                      onChange={(e) => setEditForm({...editForm, passingMarks: parseInt(e.target.value)})}
                    />
                  </div>
                  <Button onClick={handleUpdateTest} className="w-full">
                    Update Test
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            {!selectedTest.isPublished && (
              <Button onClick={handlePublishTest}>
                <Play className="w-4 h-4 mr-2" />
                Publish Test
              </Button>
            )}
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="questions">Questions</TabsTrigger>
            <TabsTrigger value="submissions">Submissions</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BrainCircuit className="w-5 h-5 mr-2" />
                    Questions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{selectedTest._count.questions}</div>
                  <p className="text-gray-600">Total questions</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Submissions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{selectedTest._count.submissions}</div>
                  <p className="text-gray-600">Student submissions</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="w-5 h-5 mr-2" />
                    Duration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{selectedTest.duration}</div>
                  <p className="text-gray-600">Minutes</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="w-5 h-5 mr-2" />
                    Total Marks
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{selectedTest.totalMarks}</div>
                  <p className="text-gray-600">Maximum score</p>
                </CardContent>
              </Card>
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Test Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Status</Label>
                    <p className="font-medium">
                      <Badge variant={selectedTest.isPublished ? "default" : "secondary"}>
                        {selectedTest.isPublished ? "Published" : "Draft"}
                      </Badge>
                    </p>
                  </div>
                  <div>
                    <Label>Passing Marks</Label>
                    <p className="font-medium">{selectedTest.passingMarks}</p>
                  </div>
                  {selectedTest.startTime && (
                    <div>
                      <Label>Start Time</Label>
                      <p className="font-medium">
                        {new Date(selectedTest.startTime).toLocaleString()}
                      </p>
                    </div>
                  )}
                  {selectedTest.endTime && (
                    <div>
                      <Label>End Time</Label>
                      <p className="font-medium">
                        {new Date(selectedTest.endTime).toLocaleString()}
                      </p>
                    </div>
                  )}
                </div>
                <div className="mt-4">
                  <Label>Description</Label>
                  <p className="text-gray-600">{selectedTest.description}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="questions">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Test Questions</h2>
              <Dialog open={showAddQuestion} onOpenChange={setShowAddQuestion}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Question
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add Question</DialogTitle>
                    <DialogDescription>
                      Add a new question to your test
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="question">Question</Label>
                      <Textarea
                        id="question"
                        value={newQuestion.question}
                        onChange={(e) => setNewQuestion({...newQuestion, question: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="question-type">Type</Label>
                      <Select value={newQuestion.type} onValueChange={(value: any) => setNewQuestion({...newQuestion, type: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="MULTIPLE_CHOICE">Multiple Choice</SelectItem>
                          <SelectItem value="TRUE_FALSE">True/False</SelectItem>
                          <SelectItem value="SHORT_ANSWER">Short Answer</SelectItem>
                          <SelectItem value="ESSAY">Essay</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {newQuestion.type === 'MULTIPLE_CHOICE' && (
                      <div>
                        <Label>Options</Label>
                        {newQuestion.options.map((option, index) => (
                          <div key={index} className="flex gap-2 mt-2">
                            <Input
                              value={option}
                              onChange={(e) => {
                                const newOptions = [...newQuestion.options];
                                newOptions[index] = e.target.value;
                                setNewQuestion({...newQuestion, options: newOptions});
                              }}
                              placeholder={`Option ${index + 1}`}
                            />
                            {index === newQuestion.options.length - 1 && (
                              <Button
                                type="button"
                                variant="outline"
                                onClick={() => setNewQuestion({...newQuestion, options: [...newQuestion.options, '']})}
                              >
                                +
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="marks">Marks</Label>
                        <Input
                          id="marks"
                          type="number"
                          value={newQuestion.marks}
                          onChange={(e) => setNewQuestion({...newQuestion, marks: parseInt(e.target.value)})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="order">Order</Label>
                        <Input
                          id="order"
                          type="number"
                          value={newQuestion.order}
                          onChange={(e) => setNewQuestion({...newQuestion, order: parseInt(e.target.value)})}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="correct-answer">Correct Answer</Label>
                      <Input
                        id="correct-answer"
                        value={newQuestion.correctAnswer}
                        onChange={(e) => setNewQuestion({...newQuestion, correctAnswer: e.target.value})}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="explanation">Explanation (Optional)</Label>
                      <Textarea
                        id="explanation"
                        value={newQuestion.explanation}
                        onChange={(e) => setNewQuestion({...newQuestion, explanation: e.target.value})}
                      />
                    </div>
                    
                    <Button onClick={handleAddQuestion} className="w-full">
                      Add Question
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="space-y-4">
              {questions.map((question, index) => (
                <Card key={question.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-semibold">Q{index + 1}</span>
                          <Badge variant="outline">{question.type}</Badge>
                          <Badge variant="secondary">{question.marks} marks</Badge>
                        </div>
                        <p className="mb-2">{question.question}</p>
                        {question.options && (
                          <div className="ml-4 space-y-1">
                            {JSON.parse(question.options).map((option: string, optIndex: number) => (
                              <div key={optIndex} className="text-sm text-gray-600">
                                {String.fromCharCode(65 + optIndex)}. {option}
                              </div>
                            ))}
                          </div>
                        )}
                        {question.correctAnswer && (
                          <p className="text-sm text-green-600 mt-2">
                            Correct Answer: {question.correctAnswer}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="destructive" 
                                onClick={() => handleDeleteQuestion(question.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="submissions">
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Student ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {submissions.map((submission) => (
                    <TableRow key={submission.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{submission.student.name}</div>
                          <div className="text-sm text-gray-500">{submission.student.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>{submission.student.studentProfile?.studentId || 'N/A'}</TableCell>
                      <TableCell>
                        <Badge variant={submission.status === 'GRADED' ? 'default' : 'secondary'}>
                          {submission.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {submission.marks ? `${submission.marks}/${selectedTest.totalMarks}` : 'Not graded'}
                      </TableCell>
                      <TableCell>
                        {submission.submittedAt ? new Date(submission.submittedAt).toLocaleDateString() : 'N/A'}
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {submissions.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No submissions yet.
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="results">
            <Card>
              <CardHeader>
                <CardTitle>Test Results Analytics</CardTitle>
                <CardDescription>
                  Overview of student performance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {submissions.filter(s => s.status === 'GRADED').length}
                    </div>
                    <p className="text-gray-600">Graded Submissions</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {submissions.filter(s => s.marks && s.marks >= selectedTest.passingMarks).length}
                    </div>
                    <p className="text-gray-600">Passed</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-red-600">
                      {submissions.filter(s => s.marks && s.marks < selectedTest.passingMarks).length}
                    </div>
                    <p className="text-gray-600">Failed</p>
                  </div>
                </div>
                
                {submissions.filter(s => s.marks).length > 0 && (
                  <div className="mt-6">
                    <h3 className="font-semibold mb-4">Average Score</h3>
                    <div className="text-2xl font-bold">
                      {(submissions.reduce((acc, s) => acc + (s.marks || 0), 0) / 
                        submissions.filter(s => s.marks).length).toFixed(1)} / {selectedTest.totalMarks}
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-4 mt-2">
                      <div 
                        className="bg-blue-600 h-4 rounded-full" 
                        style={{
                          width: `${(submissions.reduce((acc, s) => acc + (s.marks || 0), 0) / 
                            submissions.filter(s => s.marks).length / selectedTest.totalMarks) * 100}%`
                        }}
                      ></div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}