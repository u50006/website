'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BookOpen, BrainCircuit, Users, Award, Plus, Calendar, TrendingUp, UserCheck, Video } from 'lucide-react';
import { CourseManagement } from './course-management';
import { TestManagement } from './test-management';
import { OnlineClassManagement } from './online-class-management';
import { ClassNotifications } from './class-notifications';

interface Course {
  id: string;
  title: string;
  description: string;
  code: string;
  credits: number;
  duration: number;
  level: string;
  price: number;
  language: string;
  thumbnail?: string;
  averageRating: number;
  totalStudents: number;
  totalTests: number;
  totalReviews: number;
  isActive: boolean;
  createdAt: string;
  teacher: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
    teacherProfile?: {
      department: string;
      experience: number;
      rating: number;
    };
  };
  category?: {
    id: string;
    name: string;
    color?: string;
  };
}

interface Test {
  id: string;
  title: string;
  description: string;
  courseId: string;
  teacherId: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  startTime?: string;
  endTime?: string;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
  totalQuestions: number;
  totalSubmissions: number;
  course?: {
    id: string;
    title: string;
    code: string;
  };
}

interface Student {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  phone?: string;
  dateOfBirth?: string;
  address?: string;
  role: string;
  createdAt: string;
  updatedAt: string;
  studentProfile?: {
    id: string;
    userId: string;
    studentId: string;
    grade: string;
    section: string;
    rollNumber: string;
    parentName: string;
    parentPhone: string;
    parentEmail: string;
  };
  enrollments?: Array<{
    id: string;
    studentId: string;
    courseId: string;
    enrolledAt: string;
    status: string;
    progress: number;
    course?: {
      id: string;
      title: string;
      code: string;
    };
  }>;
}

export function TeacherDashboard() {
  const { user, token, logout } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [tests, setTests] = useState<Test[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateCourse, setShowCreateCourse] = useState(false);
  const [showCreateTest, setShowCreateTest] = useState(false);
  const [showCourseManagement, setShowCourseManagement] = useState(false);
  const [showTestManagement, setShowTestManagement] = useState(false);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [selectedTestId, setSelectedTestId] = useState<string | null>(null);
  
  const [newCourse, setNewCourse] = useState({
    title: '',
    description: '',
    code: '',
    credits: 3,
    duration: 12,
    level: 'BEGINNER',
    categoryId: ''
  });

  const [newTest, setNewTest] = useState({
    title: '',
    description: '',
    courseId: '',
    duration: 60,
    totalMarks: 100,
    passingMarks: 60,
    startTime: '',
    endTime: ''
  });

  useEffect(() => {
    if (user?.id) {
      fetchTeacherData();
    }
  }, [user]);

  const fetchTeacherData = async () => {
    try {
      const headers = {
        'Authorization': `Bearer ${token}`,
      };

      // Fetch courses taught by this teacher
      const coursesResponse = await fetch(`/api/courses?teacherId=${user.id}`, { headers });
      if (coursesResponse.ok) {
        const coursesData = await coursesResponse.json();
        setCourses(coursesData.courses || []);
      }

      // Fetch tests created by this teacher
      const testsResponse = await fetch(`/api/tests?teacherId=${user.id}`, { headers });
      if (testsResponse.ok) {
        const testsData = await testsResponse.json();
        setTests(testsData.tests || []);
      }

      // Fetch students enrolled in teacher's courses
      const studentsResponse = await fetch(`/api/users?role=STUDENT`, { headers });
      if (studentsResponse.ok) {
        const studentsData = await studentsResponse.json();
        setStudents(studentsData || []);
      }
    } catch (error) {
      console.error('Error fetching teacher data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCourse = async () => {
    try {
      const response = await fetch('/api/courses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...newCourse,
          teacherId: user.id,
        }),
      });

      if (response.ok) {
        setShowCreateCourse(false);
        setNewCourse({
          title: '',
          description: '',
          code: '',
          credits: 3,
          duration: 12,
          level: 'BEGINNER',
          categoryId: ''
        });
        fetchTeacherData();
      }
    } catch (error) {
      console.error('Error creating course:', error);
    }
  };

  const handleCreateTest = async () => {
    try {
      const response = await fetch('/api/tests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...newTest,
          teacherId: user.id,
        }),
      });

      if (response.ok) {
        setShowCreateTest(false);
        setNewTest({
          title: '',
          description: '',
          courseId: '',
          duration: 60,
          totalMarks: 100,
          passingMarks: 60,
          startTime: '',
          endTime: ''
        });
        fetchTeacherData();
      }
    } catch (error) {
      console.error('Error creating test:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (showCourseManagement) {
    return (
      <CourseManagement 
        courseId={selectedCourseId || undefined}
        onBack={() => {
          setShowCourseManagement(false);
          setSelectedCourseId(null);
        }}
      />
    );
  }

  if (showTestManagement) {
    return (
      <TestManagement 
        testId={selectedTestId || undefined}
        onBack={() => {
          setShowTestManagement(false);
          setSelectedTestId(null);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Navigation Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={() => window.location.href = '/'}>
              <BookOpen className="w-4 h-4 mr-2" />
              Home
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Welcome back, {user?.name}!
              </h1>
              <p className="text-gray-600">
                Manage your courses, create tests, and track student progress
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ClassNotifications />
            <Button variant="outline" onClick={logout}>
              Logout
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">My Courses</p>
                  <p className="text-2xl font-bold text-gray-900">{courses.length}</p>
                </div>
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Students</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {courses.reduce((acc, course) => acc + course.totalStudents, 0)}
                  </p>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Tests</p>
                  <p className="text-2xl font-bold text-gray-900">{tests.length}</p>
                </div>
                <BrainCircuit className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg. Progress</p>
                  <p className="text-2xl font-bold text-gray-900">72%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="courses">My Courses</TabsTrigger>
            <TabsTrigger value="tests">Tests</TabsTrigger>
            <TabsTrigger value="online-classes">Online Classes</TabsTrigger>
            <TabsTrigger value="students">Students</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* My Courses */}
          <TabsContent value="courses">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">My Courses</h2>
              <Dialog open={showCreateCourse} onOpenChange={setShowCreateCourse}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Course
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Course</DialogTitle>
                    <DialogDescription>
                      Add a new course to your teaching portfolio
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Course Title</Label>
                      <Input
                        id="title"
                        value={newCourse.title}
                        onChange={(e) => setNewCourse({...newCourse, title: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="code">Course Code</Label>
                      <Input
                        id="code"
                        value={newCourse.code}
                        onChange={(e) => setNewCourse({...newCourse, code: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newCourse.description}
                        onChange={(e) => setNewCourse({...newCourse, description: e.target.value})}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="credits">Credits</Label>
                        <Input
                          id="credits"
                          type="number"
                          value={newCourse.credits}
                          onChange={(e) => setNewCourse({...newCourse, credits: parseInt(e.target.value)})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="duration">Duration (weeks)</Label>
                        <Input
                          id="duration"
                          type="number"
                          value={newCourse.duration}
                          onChange={(e) => setNewCourse({...newCourse, duration: parseInt(e.target.value)})}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="level">Level</Label>
                        <Select value={newCourse.level} onValueChange={(value) => setNewCourse({...newCourse, level: value})}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="BEGINNER">Beginner</SelectItem>
                            <SelectItem value="INTERMEDIATE">Intermediate</SelectItem>
                            <SelectItem value="ADVANCED">Advanced</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="category">Category ID</Label>
                        <Input
                          id="category"
                          value={newCourse.categoryId}
                          onChange={(e) => setNewCourse({...newCourse, categoryId: e.target.value})}
                          placeholder="Enter category ID"
                        />
                      </div>
                    </div>
                    <Button onClick={handleCreateCourse} className="w-full">
                      Create Course
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <Card key={course.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        <CardDescription>{course.code}</CardDescription>
                      </div>
                      <Badge variant={course.isActive ? "default" : "secondary"}>
                        {course.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{course.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Students:</span>
                        <span className="font-medium">{course.totalStudents}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Tests:</span>
                        <span className="font-medium">{course.totalTests}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Credits:</span>
                        <span className="font-medium">{course.credits}</span>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button size="sm" variant="outline" className="flex-1"
                              onClick={() => {
                                setSelectedCourseId(course.id);
                                setShowCourseManagement(true);
                              }}>
                        Manage
                      </Button>
                      <Button size="sm" className="flex-1">
                        View Students
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Tests */}
          <TabsContent value="tests">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Tests</h2>
              <Dialog open={showCreateTest} onOpenChange={setShowCreateTest}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Test
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Test</DialogTitle>
                    <DialogDescription>
                      Create a new test for one of your courses
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="test-title">Test Title</Label>
                      <Input
                        id="test-title"
                        value={newTest.title}
                        onChange={(e) => setNewTest({...newTest, title: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="test-description">Description</Label>
                      <Textarea
                        id="test-description"
                        value={newTest.description}
                        onChange={(e) => setNewTest({...newTest, description: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="course">Course</Label>
                      <Select value={newTest.courseId} onValueChange={(value) => setNewTest({...newTest, courseId: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a course" />
                        </SelectTrigger>
                        <SelectContent>
                          {courses.filter(course => course.id).map((course) => (
                            <SelectItem key={course.id} value={course.id}>
                              {course.title} ({course.code})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="duration">Duration (minutes)</Label>
                        <Input
                          id="duration"
                          type="number"
                          value={newTest.duration}
                          onChange={(e) => setNewTest({...newTest, duration: parseInt(e.target.value)})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="total-marks">Total Marks</Label>
                        <Input
                          id="total-marks"
                          type="number"
                          value={newTest.totalMarks}
                          onChange={(e) => setNewTest({...newTest, totalMarks: parseInt(e.target.value)})}
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="passing-marks">Passing Marks</Label>
                      <Input
                        id="passing-marks"
                        type="number"
                        value={newTest.passingMarks}
                        onChange={(e) => setNewTest({...newTest, passingMarks: parseInt(e.target.value)})}
                      />
                    </div>
                    <Button onClick={handleCreateTest} className="w-full">
                      Create Test
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {tests.map((test) => (
                <Card key={test.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{test.title}</CardTitle>
                        <CardDescription>{test.course.title}</CardDescription>
                      </div>
                      <Badge variant={test.isPublished ? "default" : "secondary"}>
                        {test.isPublished ? "Published" : "Draft"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{test.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">{test.duration} minutes</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Marks:</span>
                        <span className="font-medium">{test.totalMarks}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Questions:</span>
                        <span className="font-medium">{test.totalQuestions}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Submissions:</span>
                        <span className="font-medium">{test.totalSubmissions}</span>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button size="sm" variant="outline" className="flex-1"
                              onClick={() => {
                                setSelectedTestId(test.id);
                                setShowTestManagement(true);
                              }}>
                        Edit
                      </Button>
                      <Button size="sm" className="flex-1">
                        View Results
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Online Classes */}
          <TabsContent value="online-classes">
            <OnlineClassManagement />
          </TabsContent>

          {/* Students */}
          <TabsContent value="students">
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Student
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Student ID
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Grade/Section
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Enrolled Courses
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {students.map((student) => (
                      <tr key={student.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                                <span className="text-sm font-medium text-gray-700">
                                  {student.name?.charAt(0).toUpperCase()}
                                </span>
                              </div>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{student.name}</div>
                              <div className="text-sm text-gray-500">{student.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {student.studentProfile?.studentId || 'N/A'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {student.studentProfile?.grade}/{student.studentProfile?.section || 'N/A'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {student.enrollments.length} courses
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <Button size="sm" variant="outline">
                            View Profile
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {students.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No students found.
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Course Performance</CardTitle>
                  <CardDescription>Student performance across your courses</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {courses.map((course) => (
                      <div key={course.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{course.title}</p>
                          <p className="text-sm text-gray-500">{course.totalStudents} students</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">85%</p>
                          <p className="text-sm text-gray-500">avg. score</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest student activities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <UserCheck className="w-5 h-5 text-green-600" />
                      <div>
                        <p className="text-sm font-medium">John Doe completed Math 101 test</p>
                        <p className="text-xs text-gray-500">2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <BookOpen className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="text-sm font-medium">Jane Smith enrolled in Physics 201</p>
                        <p className="text-xs text-gray-500">5 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Award className="w-5 h-5 text-yellow-600" />
                      <div>
                        <p className="text-sm font-medium">Mike Johnson scored 95% on Chemistry test</p>
                        <p className="text-xs text-gray-500">1 day ago</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}