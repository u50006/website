'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Calendar, Clock, Users, Video, Plus, Edit, Trash2, ExternalLink, Copy } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';

interface OnlineClass {
  id: string;
  title: string;
  description?: string;
  courseId: string;
  teacherId: string;
  startTime: string;
  endTime: string;
  meetingLink?: string;
  meetingId?: string;
  meetingPassword?: string;
  platform?: string;
  isRecurring: boolean;
  recurringPattern?: string;
  maxParticipants: number;
  isRecorded: boolean;
  status: string;
  createdAt: string;
  updatedAt: string;
  course: {
    id: string;
    title: string;
    code: string;
  };
  teacher: {
    id: string;
    name: string;
    email: string;
  };
  participants: Array<{
    id: string;
    studentId: string;
    joinedAt?: string;
    leftAt?: string;
    duration?: number;
    status: string;
    notes?: string;
    student: {
      id: string;
      name: string;
      email: string;
    };
  }>;
  _count: {
    participants: number;
  };
}

interface Course {
  id: string;
  title: string;
  code: string;
}

export function OnlineClassManagement() {
  const { user } = useAuth();
  const [classes, setClasses] = useState<OnlineClass[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    courseId: '',
    startTime: '',
    endTime: '',
    platform: 'ZOOM',
    isRecurring: false,
    recurringPattern: '',
    maxParticipants: 100,
    isRecorded: false
  });

  useEffect(() => {
    if (user?.id) {
      fetchClasses();
      fetchCourses();
    }
  }, [user]);

  const fetchClasses = async () => {
    try {
      const response = await fetch(`/api/online-classes?teacherId=${user?.id}`);
      if (response.ok) {
        const data = await response.json();
        setClasses(data || []);
      }
    } catch (error) {
      console.error('Error fetching classes:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCourses = async () => {
    try {
      const response = await fetch(`/api/courses?teacherId=${user?.id}`);
      if (response.ok) {
        const data = await response.json();
        setCourses(data.courses || []);
      }
    } catch (error) {
      console.error('Error fetching courses:', error);
    }
  };

  const handleCreateClass = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/online-classes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          teacherId: user?.id
        })
      });

      if (response.ok) {
        setShowCreateDialog(false);
        setFormData({
          title: '',
          description: '',
          courseId: '',
          startTime: '',
          endTime: '',
          platform: 'ZOOM',
          isRecurring: false,
          recurringPattern: '',
          maxParticipants: 100,
          isRecorded: false
        });
        fetchClasses();
      }
    } catch (error) {
      console.error('Error creating class:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'SCHEDULED': return 'bg-blue-100 text-blue-800';
      case 'LIVE': return 'bg-green-100 text-green-800';
      case 'ENDED': return 'bg-gray-100 text-gray-800';
      case 'CANCELLED': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPlatformIcon = (platform?: string) => {
    switch (platform) {
      case 'ZOOM': return '🎥';
      case 'GOOGLE_MEET': return '📹';
      case 'TEAMS': return '💼';
      default: return '📺';
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const isClassLive = (startTime: string, endTime: string, status: string) => {
    if (status === 'LIVE') return true;
    const now = new Date();
    const start = new Date(startTime);
    const end = new Date(endTime);
    return now >= start && now <= end;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Online Classes</h2>
          <p className="text-gray-600">Manage and schedule your virtual classes</p>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Schedule Class
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Schedule New Online Class</DialogTitle>
              <DialogDescription>
                Create a new virtual class with video conferencing
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateClass} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Class Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="course">Course</Label>
                  <Select value={formData.courseId} onValueChange={(value) => setFormData({...formData, courseId: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select course" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.filter(course => course.id).map(course => (
                        <SelectItem key={course.id} value={course.id}>
                          {course.title} ({course.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startTime">Start Time</Label>
                  <Input
                    id="startTime"
                    type="datetime-local"
                    value={formData.startTime}
                    onChange={(e) => setFormData({...formData, startTime: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="endTime">End Time</Label>
                  <Input
                    id="endTime"
                    type="datetime-local"
                    value={formData.endTime}
                    onChange={(e) => setFormData({...formData, endTime: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="platform">Platform</Label>
                  <Select value={formData.platform} onValueChange={(value) => setFormData({...formData, platform: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ZOOM">Zoom</SelectItem>
                      <SelectItem value="GOOGLE_MEET">Google Meet</SelectItem>
                      <SelectItem value="TEAMS">Microsoft Teams</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="maxParticipants">Max Participants</Label>
                  <Input
                    id="maxParticipants"
                    type="number"
                    value={formData.maxParticipants}
                    onChange={(e) => setFormData({...formData, maxParticipants: parseInt(e.target.value)})}
                    min="1"
                    max="1000"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isRecorded"
                  checked={formData.isRecorded}
                  onChange={(e) => setFormData({...formData, isRecorded: e.target.checked})}
                />
                <Label htmlFor="isRecorded">Record this class</Label>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Schedule Class
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {classes.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Video className="w-16 h-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No classes scheduled</h3>
            <p className="text-gray-500 text-center mb-4">
              Create your first online class to start teaching virtually
            </p>
            <Button onClick={() => setShowCreateDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Schedule Your First Class
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {classes.map((classItem) => (
            <Card key={classItem.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{getPlatformIcon(classItem.platform)}</span>
                      <CardTitle className="text-lg">{classItem.title}</CardTitle>
                      <Badge className={getStatusColor(classItem.status)}>
                        {classItem.status}
                      </Badge>
                      {isClassLive(classItem.startTime, classItem.endTime, classItem.status) && (
                        <Badge className="bg-red-100 text-red-800 animate-pulse">
                          🔴 LIVE NOW
                        </Badge>
                      )}
                    </div>
                    <CardDescription>
                      {classItem.course.title} ({classItem.course.code})
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    {classItem.meetingLink && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(classItem.meetingLink, '_blank')}
                      >
                        <ExternalLink className="w-4 h-4 mr-1" />
                        Join
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {classItem.description && (
                  <p className="text-sm text-gray-600">{classItem.description}</p>
                )}
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span>{formatDateTime(classItem.startTime)}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span>{formatDateTime(classItem.endTime)}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4 text-gray-500" />
                    <span>{classItem._count.participants} participants</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Video className="w-4 h-4 text-gray-500" />
                    <span>{classItem.platform}</span>
                  </div>
                </div>

                {classItem.meetingLink && (
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm">
                      <p className="font-medium">Meeting Link</p>
                      <p className="text-gray-600 truncate max-w-xs">{classItem.meetingLink}</p>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(classItem.meetingLink!)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                )}

                {classItem.meetingId && (
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm">
                      <p className="font-medium">Meeting ID</p>
                      <p className="text-gray-600">{classItem.meetingId}</p>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(classItem.meetingId!)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                )}

                {classItem.participants.length > 0 && (
                  <div>
                    <p className="font-medium text-sm mb-2">Participants ({classItem.participants.length})</p>
                    <div className="space-y-1">
                      {classItem.participants.map(participant => (
                        <div key={participant.id} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                          <span>{participant.student.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {participant.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}