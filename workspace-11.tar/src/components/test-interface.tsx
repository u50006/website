'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, BrainCircuit, CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react';

interface Question {
  id: string;
  question: string;
  type: 'MULTIPLE_CHOICE' | 'TRUE_FALSE' | 'SHORT_ANSWER' | 'ESSAY';
  options?: string[];
  marks: number;
  order: number;
}

interface Test {
  id: string;
  title: string;
  description: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  startTime: string;
  endTime: string;
  course: {
    title: string;
    code: string;
  };
}

interface TestInterfaceProps {
  test: Test;
  questions: Question[];
  onSubmit: (answers: Record<string, string>) => void;
}

export function TestInterface({ test, questions, onSubmit }: TestInterfaceProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeRemaining, setTimeRemaining] = useState(test.duration * 60); // Convert to seconds
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  // Sort questions by order
  const sortedQuestions = [...questions].sort((a, b) => a.order - b.order);

  useEffect(() => {
    if (timeRemaining > 0 && !isSubmitted) {
      const timer = setTimeout(() => {
        setTimeRemaining(timeRemaining - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (timeRemaining === 0 && !isSubmitted) {
      handleSubmit();
    }
  }, [timeRemaining, isSubmitted]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleNext = () => {
    if (currentQuestion < sortedQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = () => {
    setIsSubmitted(true);
    onSubmit(answers);
  };

  const getProgress = () => {
    const answeredQuestions = Object.keys(answers).length;
    return (answeredQuestions / sortedQuestions.length) * 100;
  };

  const getCurrentQuestion = () => {
    return sortedQuestions[currentQuestion];
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4 flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <CardTitle className="text-2xl">Test Submitted!</CardTitle>
            <CardDescription>
              Your responses have been recorded successfully.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-gray-600 mb-4">
              You answered {Object.keys(answers).length} out of {sortedQuestions.length} questions.
            </p>
            <Button onClick={() => window.history.back()}>
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQ = getCurrentQuestion();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl">{test.title}</CardTitle>
                <CardDescription>{test.course.title} - {test.course.code}</CardDescription>
              </div>
              <div className="text-right">
                <Badge variant={timeRemaining < 300 ? "destructive" : "default"} className="mb-2">
                  <Clock className="w-4 h-4 mr-1" />
                  {formatTime(timeRemaining)}
                </Badge>
                <p className="text-sm text-gray-600">
                  Question {currentQuestion + 1} of {sortedQuestions.length}
                </p>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-2">
                <span>Progress</span>
                <span>{Math.round(getProgress())}%</span>
              </div>
              <Progress value={getProgress()} className="h-2" />
            </div>
          </CardHeader>
        </Card>

        {/* Question */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">
                Question {currentQuestion + 1}
              </CardTitle>
              <Badge variant="secondary">
                {currentQ.marks} marks
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-lg mb-6">{currentQ.question}</p>
            
            {currentQ.type === 'MULTIPLE_CHOICE' && currentQ.options && (
              <RadioGroup
                value={answers[currentQ.id] || ''}
                onValueChange={(value) => handleAnswerChange(currentQ.id, value)}
              >
                {JSON.parse(currentQ.options).map((option: string, index: number) => (
                  <div key={index} className="flex items-center space-x-2">
                    <RadioGroupItem value={option} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="text-base">
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            )}

            {currentQ.type === 'TRUE_FALSE' && (
              <RadioGroup
                value={answers[currentQ.id] || ''}
                onValueChange={(value) => handleAnswerChange(currentQ.id, value)}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="true" id="true" />
                  <Label htmlFor="true" className="text-base">True</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="false" id="false" />
                  <Label htmlFor="false" className="text-base">False</Label>
                </div>
              </RadioGroup>
            )}

            {currentQ.type === 'SHORT_ANSWER' && (
              <Textarea
                placeholder="Enter your answer here..."
                value={answers[currentQ.id] || ''}
                onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                className="min-h-[100px]"
              />
            )}

            {currentQ.type === 'ESSAY' && (
              <Textarea
                placeholder="Write your essay here..."
                value={answers[currentQ.id] || ''}
                onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                className="min-h-[200px]"
              />
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>

          <div className="flex gap-2">
            {sortedQuestions.map((q, index) => (
              <Button
                key={q.id}
                variant={index === currentQuestion ? "default" : answers[q.id] ? "secondary" : "outline"}
                size="sm"
                onClick={() => setCurrentQuestion(index)}
                className="w-10 h-10"
              >
                {index + 1}
              </Button>
            ))}
          </div>

          {currentQuestion === sortedQuestions.length - 1 ? (
            <Button onClick={() => setShowConfirmDialog(true)}>
              Submit Test
            </Button>
          ) : (
            <Button onClick={handleNext}>
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>

        {/* Submit Confirmation Dialog */}
        {showConfirmDialog && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-md w-full">
              <CardHeader>
                <CardTitle>Submit Test?</CardTitle>
                <CardDescription>
                  You have answered {Object.keys(answers).length} out of {sortedQuestions.length} questions.
                  {Object.keys(answers).length < sortedQuestions.length && (
                    <span className="text-red-600 block mt-1">
                      You have unanswered questions. Are you sure you want to submit?
                    </span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex gap-2">
                <Button variant="outline" onClick={() => setShowConfirmDialog(false)} className="flex-1">
                  Continue Test
                </Button>
                <Button onClick={() => {
                  setShowConfirmDialog(false);
                  handleSubmit();
                }} className="flex-1">
                  Submit
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}