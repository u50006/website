'use client';

import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { 
  BookOpen, 
  Users, 
  Clock, 
  Star, 
  DollarSign,
  PlayCircle,
  Award,
  Calendar
} from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';

interface CourseCardProps {
  course: {
    id: string;
    title: string;
    description: string;
    code: string;
    credits: number;
    duration: number;
    level: string;
    price: number;
    language: string;
    thumbnail?: string;
    averageRating: number;
    totalStudents: number;
    totalTests: number;
    totalReviews: number;
    teacher: {
      id: string;
      name: string;
      email: string;
      avatar?: string;
      teacherProfile?: {
        department: string;
        experience: number;
        rating: number;
      };
    };
    category?: {
      id: string;
      name: string;
      color?: string;
    };
  };
  enrolled?: boolean;
  progress?: number;
  showEnrollButton?: boolean;
}

export function CourseCard({ 
  course, 
  enrolled = false, 
  progress = 0,
  showEnrollButton = true 
}: CourseCardProps) {
  const formatPrice = (price: number) => {
    return price === 0 ? 'Free' : `$${price}`;
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'beginner':
        return 'bg-green-100 text-green-800';
      case 'intermediate':
        return 'bg-yellow-100 text-yellow-800';
      case 'advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
      {/* Course Thumbnail */}
      <div className="relative h-48 overflow-hidden">
        {course.thumbnail ? (
          <Image
            src={course.thumbnail}
            alt={course.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
            <BookOpen className="w-16 h-16 text-blue-500" />
          </div>
        )}
        
        {/* Category Badge */}
        {course.category && (
          <div className="absolute top-3 left-3">
            <Badge 
              variant="secondary" 
              className="bg-white/90 backdrop-blur-sm"
              style={{ 
                backgroundColor: course.category.color ? `${course.category.color}20` : undefined,
                color: course.category.color || undefined
              }}
            >
              {course.category.name}
            </Badge>
          </div>
        )}

        {/* Price Badge */}
        <div className="absolute top-3 right-3">
          <Badge 
            variant={course.price === 0 ? "secondary" : "default"}
            className="bg-white/90 backdrop-blur-sm"
          >
            {formatPrice(course.price)}
          </Badge>
        </div>

        {/* Play Button Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button variant="secondary" size="lg" className="bg-white/90">
            <PlayCircle className="w-5 h-5 mr-2" />
            Preview
          </Button>
        </div>
      </div>

      <CardHeader className="pb-3">
        <div className="space-y-2">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="font-semibold text-lg line-clamp-2 group-hover:text-blue-600 transition-colors">
                {course.title}
              </h3>
              <p className="text-sm text-muted-foreground">{course.code}</p>
            </div>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2">
            {course.description}
          </p>

          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className={getLevelColor(course.level)}>
              {course.level}
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {course.duration} weeks
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              <Award className="w-3 h-3" />
              {course.credits} credits
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pb-3">
        <div className="space-y-3">
          {/* Teacher Info */}
          <div className="flex items-center gap-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src={course.teacher.avatar} />
              <AvatarFallback>
                {course.teacher.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{course.teacher.name}</p>
              <p className="text-xs text-muted-foreground">
                {course.teacher.teacherProfile?.department}
              </p>
            </div>
            {course.teacher.teacherProfile?.rating && (
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm font-medium">
                  {course.teacher.teacherProfile.rating.toFixed(1)}
                </span>
              </div>
            )}
          </div>

          {/* Course Stats */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-muted/50 rounded-lg p-2">
              <div className="flex items-center justify-center gap-1 text-blue-600">
                <Users className="w-4 h-4" />
                <span className="text-sm font-semibold">{course.totalStudents}</span>
              </div>
              <p className="text-xs text-muted-foreground">Students</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-2">
              <div className="flex items-center justify-center gap-1 text-green-600">
                <Calendar className="w-4 h-4" />
                <span className="text-sm font-semibold">{course.totalTests}</span>
              </div>
              <p className="text-xs text-muted-foreground">Tests</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-2">
              <div className="flex items-center justify-center gap-1 text-yellow-600">
                <Star className="w-4 h-4" />
                <span className="text-sm font-semibold">{course.averageRating}</span>
              </div>
              <p className="text-xs text-muted-foreground">Rating</p>
            </div>
          </div>

          {/* Progress Bar (for enrolled courses) */}
          {enrolled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="pt-0">
        <div className="flex gap-2 w-full">
          <Link href={`/courses/${course.id}`} className="flex-1">
            <Button variant="outline" className="w-full">
              View Details
            </Button>
          </Link>
          {showEnrollButton && !enrolled && (
            <Link href={`/courses/${course.id}/enroll`} className="flex-1">
              <Button className="w-full">
                Enroll Now
              </Button>
            </Link>
          )}
          {enrolled && (
            <Link href={`/courses/${course.id}/learn`} className="flex-1">
              <Button className="w-full">
                Continue Learning
              </Button>
            </Link>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}