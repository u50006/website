'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  FileText, 
  Video, 
  Link, 
  CheckSquare,
  Plus,
  Edit,
  Trash2,
  Download,
  Play,
  ExternalLink,
  CheckCircle,
  Circle,
  Lock,
  Unlock
} from 'lucide-react';

interface CourseMaterial {
  id: string;
  title: string;
  type: 'VIDEO' | 'DOCUMENT' | 'LINK' | 'ASSIGNMENT';
  content: string;
  order: number;
  isRequired: boolean;
  createdAt: string;
  isCompleted?: boolean;
  duration?: number;
}

interface CourseMaterialsProps {
  courseId: string;
  materials: CourseMaterial[];
  isTeacher?: boolean;
  onMaterialUpdate?: (material: CourseMaterial) => void;
  onMaterialDelete?: (materialId: string) => void;
  onMaterialCreate?: (material: Omit<CourseMaterial, 'id' | 'createdAt'>) => void;
  onProgressUpdate?: (materialId: string, completed: boolean) => void;
}

export function CourseMaterials({ 
  courseId,
  materials, 
  isTeacher = false,
  onMaterialUpdate,
  onMaterialDelete,
  onMaterialCreate,
  onProgressUpdate
}: CourseMaterialsProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<CourseMaterial | null>(null);
  const [newMaterial, setNewMaterial] = useState({
    title: '',
    type: 'DOCUMENT' as const,
    content: '',
    order: materials.length,
    isRequired: false,
  });

  const materialTypes = [
    { value: 'VIDEO', label: 'Video', icon: Video, color: 'text-red-600' },
    { value: 'DOCUMENT', label: 'Document', icon: FileText, color: 'text-blue-600' },
    { value: 'LINK', label: 'External Link', icon: Link, color: 'text-green-600' },
    { value: 'ASSIGNMENT', label: 'Assignment', icon: CheckSquare, color: 'text-purple-600' },
  ];

  const getMaterialIcon = (type: string) => {
    const materialType = materialTypes.find(t => t.value === type);
    return materialType ? materialType.icon : FileText;
  };

  const getMaterialColor = (type: string) => {
    const materialType = materialTypes.find(t => t.value === type);
    return materialType ? materialType.color : 'text-gray-600';
  };

  const handleCreateMaterial = () => {
    if (onMaterialCreate) {
      onMaterialCreate(newMaterial);
      setNewMaterial({
        title: '',
        type: 'DOCUMENT',
        content: '',
        order: materials.length,
        isRequired: false,
      });
      setShowAddForm(false);
    }
  };

  const handleUpdateMaterial = () => {
    if (editingMaterial && onMaterialUpdate) {
      onMaterialUpdate(editingMaterial);
      setEditingMaterial(null);
    }
  };

  const handleDeleteMaterial = (materialId: string) => {
    if (onMaterialDelete && confirm('Are you sure you want to delete this material?')) {
      onMaterialDelete(materialId);
    }
  };

  const toggleMaterialCompletion = (materialId: string, completed: boolean) => {
    if (onProgressUpdate) {
      onProgressUpdate(materialId, completed);
    }
  };

  const completedCount = materials.filter(m => m.isCompleted).length;
  const progressPercentage = materials.length > 0 ? (completedCount / materials.length) * 100 : 0;

  const sortedMaterials = [...materials].sort((a, b) => a.order - b.order);

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      {!isTeacher && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Course Progress</span>
              <span className="text-sm font-normal text-muted-foreground">
                {completedCount} of {materials.length} completed
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={progressPercentage} className="h-2" />
            <p className="text-sm text-muted-foreground mt-2">
              {progressPercentage.toFixed(0)}% complete
            </p>
          </CardContent>
        </Card>
      )}

      {/* Materials List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Course Materials</CardTitle>
            {isTeacher && (
              <Button onClick={() => setShowAddForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Material
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {sortedMaterials.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No materials yet</h3>
              <p className="text-muted-foreground mb-4">
                {isTeacher ? 'Start by adding your first course material' : 'Materials will appear here once added by the instructor'}
              </p>
              {isTeacher && (
                <Button onClick={() => setShowAddForm(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Material
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {sortedMaterials.map((material) => {
                const Icon = getMaterialIcon(material.type);
                const color = getMaterialColor(material.type);
                const isEditing = editingMaterial?.id === material.id;

                return (
                  <div
                    key={material.id}
                    className="border rounded-lg p-4 hover:bg-muted/50 transition-colors"
                  >
                    {isEditing ? (
                      <div className="space-y-4">
                        <Input
                          value={editingMaterial.title}
                          onChange={(e) => setEditingMaterial({
                            ...editingMaterial,
                            title: e.target.value
                          })}
                          placeholder="Material title"
                        />
                        <Select
                          value={editingMaterial.type}
                          onValueChange={(value: any) => setEditingMaterial({
                            ...editingMaterial,
                            type: value
                          })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {materialTypes.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                <div className="flex items-center gap-2">
                                  <type.icon className="w-4 h-4" />
                                  {type.label}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Textarea
                          value={editingMaterial.content}
                          onChange={(e) => setEditingMaterial({
                            ...editingMaterial,
                            content: e.target.value
                          })}
                          placeholder={
                            material.type === 'LINK' ? 'Enter URL...' :
                            material.type === 'VIDEO' ? 'Enter video URL or embed code...' :
                            material.type === 'ASSIGNMENT' ? 'Enter assignment instructions...' :
                            'Enter content or description...'
                          }
                          rows={3}
                        />
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id={`required-${material.id}`}
                            checked={editingMaterial.isRequired}
                            onChange={(e) => setEditingMaterial({
                              ...editingMaterial,
                              isRequired: e.target.checked
                            })}
                            className="rounded"
                          />
                          <label htmlFor={`required-${material.id}`} className="text-sm">
                            Required material
                          </label>
                        </div>
                        <div className="flex gap-2">
                          <Button onClick={handleUpdateMaterial}>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Save
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => setEditingMaterial(null)}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0">
                          <Icon className={`w-6 h-6 ${color}`} />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <h4 className="font-semibold">{material.title}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {materialTypes.find(t => t.value === material.type)?.label}
                                </Badge>
                                {material.isRequired && (
                                  <Badge variant="secondary" className="text-xs">
                                    Required
                                  </Badge>
                                )}
                                {material.isCompleted !== undefined && (
                                  <div className="flex items-center gap-1">
                                    {material.isCompleted ? (
                                      <CheckCircle className="w-4 h-4 text-green-600" />
                                    ) : (
                                      <Circle className="w-4 h-4 text-gray-400" />
                                    )}
                                    <span className="text-xs text-muted-foreground">
                                      {material.isCompleted ? 'Completed' : 'Not completed'}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-1">
                              {!isTeacher && material.type !== 'ASSIGNMENT' && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => toggleMaterialCompletion(material.id, !material.isCompleted)}
                                >
                                  {material.isCompleted ? (
                                    <Unlock className="w-4 h-4" />
                                  ) : (
                                    <Lock className="w-4 h-4" />
                                  )}
                                </Button>
                              )}
                              
                              {material.type === 'LINK' && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  asChild
                                >
                                  <a
                                    href={material.content}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                  >
                                    <ExternalLink className="w-4 h-4" />
                                  </a>
                                </Button>
                              )}
                              
                              {material.type === 'VIDEO' && (
                                <Button variant="ghost" size="sm">
                                  <Play className="w-4 h-4" />
                                </Button>
                              )}
                              
                              {material.type === 'DOCUMENT' && (
                                <Button variant="ghost" size="sm">
                                  <Download className="w-4 h-4" />
                                </Button>
                              )}
                              
                              {isTeacher && (
                                <>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setEditingMaterial(material)}
                                  >
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleDeleteMaterial(material.id)}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </div>
                          
                          {material.content && (
                            <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                              {material.content}
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Material Form */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Material</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              value={newMaterial.title}
              onChange={(e) => setNewMaterial({ ...newMaterial, title: e.target.value })}
              placeholder="Material title"
            />
            
            <Select
              value={newMaterial.type}
              onValueChange={(value: any) => setNewMaterial({ ...newMaterial, type: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {materialTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    <div className="flex items-center gap-2">
                      <type.icon className="w-4 h-4" />
                      {type.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Textarea
              value={newMaterial.content}
              onChange={(e) => setNewMaterial({ ...newMaterial, content: e.target.value })}
              placeholder={
                newMaterial.type === 'LINK' ? 'Enter URL...' :
                newMaterial.type === 'VIDEO' ? 'Enter video URL or embed code...' :
                newMaterial.type === 'ASSIGNMENT' ? 'Enter assignment instructions...' :
                'Enter content or description...'
              }
              rows={3}
            />
            
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="required-new"
                checked={newMaterial.isRequired}
                onChange={(e) => setNewMaterial({ ...newMaterial, isRequired: e.target.checked })}
                className="rounded"
              />
              <label htmlFor="required-new" className="text-sm">
                Required material
              </label>
            </div>
            
            <div className="flex gap-2">
              <Button onClick={handleCreateMaterial}>
                <Plus className="w-4 h-4 mr-2" />
                Add Material
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddForm(false);
                  setNewMaterial({
                    title: '',
                    type: 'DOCUMENT',
                    content: '',
                    order: materials.length,
                    isRequired: false,
                  });
                }}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}