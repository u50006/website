'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Play, Users, Clock, ArrowLeft, FileText, Award, BrainCircuit } from 'lucide-react';
import { TestInterface } from './test-interface';

interface Course {
  id: string;
  title: string;
  description: string;
  code: string;
  credits: number;
  level: string;
  category: string;
  teacher: {
    id: string;
    name: string;
    email: string;
  };
  enrollment?: {
    id: string;
    progress: number;
    enrolledAt: string;
    status: string;
  };
  materials: CourseMaterial[];
  tests: Test[];
}

interface CourseMaterial {
  id: string;
  title: string;
  type: string;
  content: string;
  order: number;
  isRequired: boolean;
  createdAt: string;
}

interface Test {
  id: string;
  title: string;
  description: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  startTime: string;
  endTime: string;
  isPublished: boolean;
  submission?: {
    id: string;
    status: string;
    marks: number;
    submittedAt: string;
  };
}

interface StudentCourseViewProps {
  courseId: string;
  onBack: () => void;
}

export function StudentCourseView({ courseId, onBack }: StudentCourseViewProps) {
  const { user, token, logout } = useAuth();
  const [course, setCourse] = useState<Course | null>(null);
  const [materials, setMaterials] = useState<CourseMaterial[]>([]);
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedTest, setSelectedTest] = useState<Test | null>(null);

  useEffect(() => {
    fetchCourseDetails();
  }, [courseId]);

  const fetchCourseDetails = async () => {
    try {
      // Fetch course details
      const courseResponse = await fetch(`/api/courses/${courseId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (courseResponse.ok) {
        const courseData = await courseResponse.json();
        setCourse(courseData);
      }

      // Fetch materials
      const materialsResponse = await fetch(`/api/courses/${courseId}/materials`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (materialsResponse.ok) {
        const materialsData = await materialsResponse.json();
        setMaterials(materialsData);
      }

      // Fetch tests for this course
      const testsResponse = await fetch(`/api/tests?courseId=${courseId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (testsResponse.ok) {
        const testsData = await testsResponse.json();
        
        // Check for submissions for each test
        const testsWithSubmissions = await Promise.all(
          testsData.map(async (test: Test) => {
            const submissionResponse = await fetch(`/api/tests/${test.id}/submissions?studentId=${user.id}`, {
              headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (submissionResponse.ok) {
              const submissions = await submissionResponse.json();
              return {
                ...test,
                submission: submissions[0] || null
              };
            }
            return test;
          })
        );
        
        setTests(testsWithSubmissions);
      }
    } catch (error) {
      console.error('Error fetching course details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStartTest = (test: Test) => {
    setSelectedTest(test);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (selectedTest) {
    return (
      <TestInterface 
        test={selectedTest}
        questions={[]} // Will be fetched in the component
        onSubmit={(answers) => {
          // Handle test submission
          console.log('Test submitted:', answers);
          setSelectedTest(null);
          fetchCourseDetails();
        }}
      />
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4 flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Course Not Found</CardTitle>
            <CardDescription>
              The course you're looking for doesn't exist or you don't have access to it.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Courses
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button variant="outline" onClick={onBack} className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{course.title}</h1>
              <p className="text-gray-600">{course.code}</p>
            </div>
          </div>
          <Button variant="outline" onClick={logout}>
            Logout
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="tests">Tests</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Course Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-6">{course.description}</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-semibold mb-2">Course Details</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Instructor:</span>
                            <span className="font-medium">{course.teacher.name}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Level:</span>
                            <span className="font-medium">{course.level}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Category:</span>
                            <span className="font-medium">{course.category}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Credits:</span>
                            <span className="font-medium">{course.credits}</span>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">Your Progress</h3>
                        {course.enrollment && (
                          <div>
                            <div className="flex justify-between text-sm mb-2">
                              <span>Completion</span>
                              <span>{course.enrollment.progress}%</span>
                            </div>
                            <Progress value={course.enrollment.progress} className="h-2 mb-4" />
                            <p className="text-sm text-gray-600">
                              Enrolled on {new Date(course.enrollment.enrolledAt).toLocaleDateString()}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <FileText className="w-5 h-5 mr-2" />
                      Materials
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{materials.length}</div>
                    <p className="text-gray-600">Course materials</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <BrainCircuit className="w-5 h-5 mr-2" />
                      Tests
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{tests.length}</div>
                    <p className="text-gray-600">Available tests</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Award className="w-5 h-5 mr-2" />
                      Completed
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {tests.filter(t => t.submission).length}
                    </div>
                    <p className="text-gray-600">Tests completed</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="materials">
            <div className="space-y-4">
              {materials.map((material) => (
                <Card key={material.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{material.title}</h3>
                        <p className="text-sm text-gray-600">{material.type}</p>
                        {material.isRequired && (
                          <Badge variant="destructive" className="mt-1">Required</Badge>
                        )}
                      </div>
                      <Button size="sm">
                        {material.type === 'LINK' ? 'Open Link' : 'View'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {materials.length === 0 && (
                <Card>
                  <CardContent className="text-center py-8">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No materials available yet.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="tests">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {tests.map((test) => (
                <Card key={test.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{test.title}</CardTitle>
                        <CardDescription>{test.description}</CardDescription>
                      </div>
                      <Badge variant={test.submission ? "secondary" : "default"}>
                        {test.submission ? "Completed" : "Available"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm mb-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">{test.duration} minutes</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Marks:</span>
                        <span className="font-medium">{test.totalMarks}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Passing Marks:</span>
                        <span className="font-medium">{test.passingMarks}</span>
                      </div>
                      {test.submission && (
                        <>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Your Score:</span>
                            <span className="font-medium">{test.submission.marks}/{test.totalMarks}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Submitted:</span>
                            <span className="font-medium">
                              {new Date(test.submission.submittedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </>
                      )}
                    </div>
                    <Button 
                      className="w-full" 
                      variant={test.submission ? "outline" : "default"}
                      onClick={() => test.submission ? null : handleStartTest(test)}
                      disabled={test.submission !== undefined}
                    >
                      {test.submission ? "View Results" : "Start Test"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
            {tests.length === 0 && (
              <Card>
                <CardContent className="text-center py-8">
                  <BrainCircuit className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No tests available yet.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="progress">
            <Card>
              <CardHeader>
                <CardTitle>Your Learning Progress</CardTitle>
                <CardDescription>
                  Track your progress through the course
                </CardDescription>
              </CardHeader>
              <CardContent>
                {course.enrollment && (
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between text-lg mb-2">
                        <span>Overall Progress</span>
                        <span className="font-bold">{course.enrollment.progress}%</span>
                      </div>
                      <Progress value={course.enrollment.progress} className="h-4" />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {materials.filter(m => !m.isRequired).length}
                        </div>
                        <p className="text-gray-600">Optional Materials</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {materials.filter(m => m.isRequired).length}
                        </div>
                        <p className="text-gray-600">Required Materials</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">
                          {tests.filter(t => t.submission).length}
                        </div>
                        <p className="text-gray-600">Tests Completed</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}