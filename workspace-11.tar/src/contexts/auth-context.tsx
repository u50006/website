'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';

interface User {
  id: string;
  email: string;
  name: string | null;
  role: 'STUDENT' | 'TEACHER' | 'ADMIN';
  teacherProfile?: {
    id: string;
    employeeId: string;
    department: string | null;
    qualification: string | null;
    experience: number | null;
    bio: string | null;
  };
  studentProfile?: {
    id: string;
    studentId: string;
    grade: string | null;
    section: string | null;
    rollNumber: string | null;
  };
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (userData: any) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false); // Start with false to avoid infinite loading

  useEffect(() => {
    // Set loading to true when starting auth check
    setIsLoading(true);
    
    // Check for existing token on mount (client-side only)
    const checkAuth = () => {
      console.log('Checking authentication...');
      try {
        const savedToken = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null;
        const savedUser = typeof window !== 'undefined' ? localStorage.getItem('auth_user') : null;
        
        console.log('Saved token:', savedToken ? 'exists' : 'none');
        console.log('Saved user:', savedUser ? 'exists' : 'none');
        
        if (savedToken && savedUser) {
          setToken(savedToken);
          setUser(JSON.parse(savedUser));
          console.log('User restored from storage');
        }
      } catch (error) {
        console.error('Error checking authentication:', error);
      } finally {
        console.log('Setting loading to false');
        setIsLoading(false);
      }
    };

    // Small delay to ensure client-side hydration is complete
    const timer = setTimeout(checkAuth, 100);

    // Fallback timeout to prevent infinite loading
    const fallbackTimer = setTimeout(() => {
      console.log('Fallback: Force loading to false');
      setIsLoading(false);
    }, 2000);

    return () => {
      clearTimeout(timer);
      clearTimeout(fallbackTimer);
    };
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (response.ok) {
        setUser(data.user);
        setToken(data.token);
        if (typeof window !== 'undefined') {
          try {
            localStorage.setItem('auth_token', data.token);
            localStorage.setItem('auth_user', JSON.stringify(data.user));
          } catch (error) {
            console.error('Error saving auth data:', error);
          }
        }
        return { success: true };
      } else {
        return { success: false, error: data.error };
      }
    } catch (error) {
      return { success: false, error: 'Network error' };
    }
  };

  const register = async (userData: any) => {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      const data = await response.json();

      if (response.ok) {
        return { success: true };
      } else {
        return { success: false, error: data.error };
      }
    } catch (error) {
      return { success: false, error: 'Network error' };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('auth_user');
      } catch (error) {
        console.error('Error clearing auth data:', error);
      }
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      login,
      register,
      logout,
      isLoading
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}